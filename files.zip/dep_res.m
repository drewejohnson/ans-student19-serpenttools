
% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 19:28:43 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  1.01634E+00  9.80266E-01  9.68641E-01  9.79869E-01  1.02225E+00  9.81532E-01  1.02113E+00  1.02791E+00  9.78726E-01  9.83077E-01  1.01770E+00  9.79474E-01  1.02147E+00  9.80474E-01  1.01997E+00  9.83925E-01  1.01993E+00  9.70068E-01  1.02088E+00  1.02002E+00  9.78999E-01  1.02137E+00  9.88075E-01  1.02401E+00  9.81716E-01  1.02422E+00  9.75002E-01  1.01297E+00  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 1.6E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.57512E-02 0.00028  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84249E-01 4.5E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.88361E-01 2.5E-05  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.89356E-01 2.5E-05  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.95953E+00 7.8E-05  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.15570E+01 9.1E-05  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.15570E+01 9.1E-05  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.87269E+01 0.00013  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.69228E-01 0.00031  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 50000028 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  1.00000E+05 0.00018 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  1.00000E+05 0.00018 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  2.04909E+02 ;
RUNNING_TIME              (idx, 1)        =  1.30224E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  2.18333E-03  2.18333E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  7.31878E+00  7.31878E+00  0.00000E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  1.30222E+01  0.00000E+00 ];
CPU_USAGE                 (idx, 1)        = 15.73512 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  2.79384E+01 0.00028 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  4.89530E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.32680E+06 ;
TOT_DECAY_HEAT            (idx, 1)        =  7.09528E-06 ;
TOT_SF_RATE               (idx, 1)        =  8.56119E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  9.32680E+06 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  7.09528E-06 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  0.00000E+00 ;
INHALATION_TOXICITY       (idx, 1)        =  8.51863E+01 ;
INGESTION_TOXICITY        (idx, 1)        =  4.50096E-01 ;
ACTINIDE_INH_TOX          (idx, 1)        =  8.51863E+01 ;
ACTINIDE_ING_TOX          (idx, 1)        =  4.50096E-01 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  0.00000E+00 ;
SR90_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
TE132_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
I131_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
I132_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
CS134_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
CS137_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.24909E+06 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  9.32204E+06 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  3.88066E+06 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  2.95153E+09 0.00014  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 0 ;
BURNUP                     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
BURN_DAYS                 (idx, 1)        =  0.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.50394E-01 0.00034 ];
U235_FISS                 (idx, [1:   4]) = [  1.55161E+14 0.00016  9.66302E-01 3.5E-05 ];
U238_FISS                 (idx, [1:   4]) = [  5.40393E+12 0.00104  3.36539E-02 0.00100 ];
U235_CAPT                 (idx, [1:   4]) = [  3.12821E+13 0.00043  2.31872E-01 0.00037 ];
U238_CAPT                 (idx, [1:   4]) = [  6.48927E+13 0.00033  4.81003E-01 0.00022 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50000028 5.00000E+07 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.60218E+04 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50000028 5.00560E+07 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 22828825 2.28544E+07 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 27171203 2.72016E+07 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50000028 5.00560E+07 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 1.49012E-08 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  5.20612E+03 2.9E-09  5.20612E+03 2.9E-09  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  4.00000E-02 8.1E-09  4.00000E-02 8.1E-09  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  3.93166E+14 2.2E-06  3.93166E+14 2.2E-06  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  1.60520E+14 2.4E-07  1.60520E+14 2.4E-07  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.34912E+14 0.00011  9.69072E+13 0.00014  3.80044E+13 0.00014 ];
TOT_ABSRATE               (idx, [1:   6]) = [  2.95432E+14 5.2E-05  2.57428E+14 5.3E-05  3.80044E+13 0.00014 ];
TOT_SRCRATE               (idx, [1:   6]) = [  2.95153E+14 0.00014  2.95153E+14 0.00014  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  1.72530E+16 0.00012  2.84596E+15 0.00013  1.44070E+16 0.00012 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  2.95432E+14 5.2E-05 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.22790E+16 0.00010 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.30153E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.82686E+00 9.7E-05 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.59916E-01 6.6E-05 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.43088E-01 8.7E-05 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14149E+00 7.2E-05 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.33252E+00 0.00013 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.33252E+00 0.00013 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.44932E+00 2.4E-06 ];
FISSE                     (idx, [1:   2]) = [  2.02430E+02 2.4E-07 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.33261E+00 0.00013  1.32359E+00 0.00013  8.93747E-03 0.00233 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.33230E+00 5.1E-05 ];
COL_KEFF                  (idx, [1:   2]) = [  1.33209E+00 0.00014 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.33230E+00 5.1E-05 ];
ABS_KINF                  (idx, [1:   2]) = [  1.33230E+00 5.1E-05 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83559E+01 4.0E-05 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83567E+01 1.6E-05 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.13414E-07 0.00073 ];
IMP_EALF                  (idx, [1:   2]) = [  2.13222E-07 0.00030 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.13016E-01 0.00114 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.12818E-01 0.00041 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.14188E-03 0.00178  1.55117E-04 0.01010  8.32097E-04 0.00410  8.13306E-04 0.00422  2.35867E-03 0.00257  7.30138E-04 0.00467  2.52547E-04 0.00796 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.91864E-01 0.00421  1.24907E-02 5.0E-07  3.17293E-02 4.7E-05  1.09827E-01 6.7E-05  3.19044E-01 5.6E-05  1.34902E+00 4.3E-05  8.77461E+00 0.00036 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.74616E-03 0.00254  2.03883E-04 0.01386  1.09166E-03 0.00597  1.06942E-03 0.00595  3.09255E-03 0.00354  9.59450E-04 0.00677  3.29196E-04 0.01163 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.89173E-01 0.00600  1.24907E-02 6.9E-07  3.17304E-02 6.9E-05  1.09830E-01 9.4E-05  3.19060E-01 7.8E-05  1.34898E+00 5.9E-05  8.77420E+00 0.00050 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.69164E-05 0.00028  3.69068E-05 0.00028  3.83441E-05 0.00312 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.91949E-05 0.00024  4.91821E-05 0.00024  5.10977E-05 0.00312 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.71072E-03 0.00237  2.04329E-04 0.01359  1.08592E-03 0.00586  1.06183E-03 0.00561  3.07436E-03 0.00347  9.57655E-04 0.00646  3.26623E-04 0.01092 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.88621E-01 0.00569  1.24907E-02 6.9E-07  3.17293E-02 7.2E-05  1.09840E-01 9.2E-05  3.19056E-01 7.9E-05  1.34906E+00 5.8E-05  8.77505E+00 0.00051 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.68985E-05 0.00059  3.68888E-05 0.00059  3.83248E-05 0.00739 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.91713E-05 0.00059  4.91584E-05 0.00059  5.10742E-05 0.00740 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.67394E-03 0.00705  1.90298E-04 0.03917  1.07251E-03 0.01669  1.06972E-03 0.01740  3.09614E-03 0.01018  9.38757E-04 0.01830  3.06512E-04 0.03036 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  7.63312E-01 0.01510  1.24906E-02 1.6E-06  3.17299E-02 0.00020  1.09833E-01 0.00027  3.19100E-01 0.00021  1.34896E+00 0.00018  8.75653E+00 0.00142 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.69924E-03 0.00683  1.94142E-04 0.03716  1.07505E-03 0.01614  1.06935E-03 0.01687  3.11199E-03 0.00977  9.39743E-04 0.01782  3.08973E-04 0.02982 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.64421E-01 0.01476  1.24907E-02 1.7E-06  3.17297E-02 0.00019  1.09843E-01 0.00027  3.19111E-01 0.00021  1.34899E+00 0.00017  8.75934E+00 0.00142 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.80932E+02 0.00704 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.69237E-05 0.00017 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.92047E-05 0.00011 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.71366E-03 0.00140 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.81830E+02 0.00143 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.13891E-07 0.00013 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.32035E-06 0.00014  3.32045E-06 0.00014  3.30652E-06 0.00170 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.24941E-05 0.00016  5.24953E-05 0.00016  5.23123E-05 0.00197 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.43498E-01 8.6E-05  7.42106E-01 8.8E-05  1.01438E+00 0.00269 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.04854E+01 0.00414 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.15570E+01 9.1E-05  4.57364E+01 0.00011 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  6.97073E+05 0.00101  2.86490E+06 0.00042  6.17226E+06 0.00033  7.45487E+06 0.00027  7.12480E+06 0.00019  7.46949E+06 0.00024  5.14045E+06 0.00025  4.41560E+06 0.00025  3.37784E+06 0.00022  2.75797E+06 0.00028  2.36675E+06 0.00029  2.17075E+06 0.00030  1.98611E+06 0.00028  1.88769E+06 0.00016  1.83455E+06 0.00027  1.59919E+06 0.00044  1.56851E+06 0.00037  1.56573E+06 0.00033  1.54566E+06 0.00043  3.02411E+06 0.00020  2.91425E+06 0.00025  2.13898E+06 0.00026  1.39575E+06 0.00040  1.63477E+06 0.00039  1.56838E+06 0.00040  1.41223E+06 0.00033  2.40835E+06 0.00028  5.42751E+05 0.00060  6.81555E+05 0.00057  6.19553E+05 0.00047  3.60367E+05 0.00053  6.26718E+05 0.00053  4.27358E+05 0.00070  3.65956E+05 0.00082  7.00927E+04 0.00097  6.96863E+04 0.00115  7.13034E+04 0.00085  7.35625E+04 0.00126  7.28962E+04 0.00122  7.15625E+04 0.00123  7.42239E+04 0.00116  6.95860E+04 0.00109  1.31549E+05 0.00096  2.10287E+05 0.00085  2.68168E+05 0.00063  7.10332E+05 0.00046  7.58820E+05 0.00041  8.64254E+05 0.00045  6.20152E+05 0.00046  4.69455E+05 0.00062  3.79251E+05 0.00048  4.57289E+05 0.00041  8.76494E+05 0.00042  1.17017E+06 0.00034  2.31599E+06 0.00039  3.45022E+06 0.00027  5.07670E+06 0.00023  3.17628E+06 0.00021  2.25164E+06 0.00026  1.60131E+06 0.00026  1.42371E+06 0.00026  1.39212E+06 0.00024  1.16334E+06 0.00032  7.75759E+05 0.00031  7.15653E+05 0.00040  6.36157E+05 0.00037  5.40550E+05 0.00046  4.16057E+05 0.00044  2.70142E+05 0.00058  9.32027E+04 0.00059 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.33209E+00 0.00015 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.26937E+16 0.00017  4.55932E+15 0.00012 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.22214E-01 2.7E-05  1.23927E+00 5.9E-05 ];
INF_CAPT                  (idx, [1:   4]) = [  4.49046E-03 0.00021  1.70884E-02 7.6E-05 ];
INF_ABS                   (idx, [1:   4]) = [  5.99973E-03 0.00016  4.80938E-02 0.00011 ];
INF_FISS                  (idx, [1:   4]) = [  1.50926E-03 0.00021  3.10054E-02 0.00013 ];
INF_NSF                   (idx, [1:   4]) = [  3.83722E-03 0.00020  7.55509E-02 0.00013 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54245E+00 1.7E-05  2.43670E+00 3.8E-09 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03607E+02 1.6E-06  2.02270E+02 2.7E-09 ];
INF_INVV                  (idx, [1:   4]) = [  6.35340E-08 0.00013  2.52457E-06 3.8E-05 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.16214E-01 2.8E-05  1.19117E+00 6.1E-05 ];
INF_SCATT1                (idx, [1:   4]) = [  2.25712E-01 5.0E-05  3.08187E-01 0.00012 ];
INF_SCATT2                (idx, [1:   4]) = [  8.98453E-02 9.1E-05  7.70535E-02 0.00019 ];
INF_SCATT3                (idx, [1:   4]) = [  6.85253E-03 0.00109  2.40754E-02 0.00064 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.10117E-03 0.00074 -5.40333E-03 0.00269 ];
INF_SCATT5                (idx, [1:   4]) = [  1.54379E-06 1.00000  5.73454E-03 0.00250 ];
INF_SCATT6                (idx, [1:   4]) = [  4.49584E-03 0.00100 -1.25905E-02 0.00064 ];
INF_SCATT7                (idx, [1:   4]) = [  6.25691E-04 0.00648  4.60085E-04 0.01618 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.16240E-01 2.8E-05  1.19117E+00 6.1E-05 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.25713E-01 5.0E-05  3.08187E-01 0.00012 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.98454E-02 9.1E-05  7.70535E-02 0.00019 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.85253E-03 0.00109  2.40754E-02 0.00064 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.10113E-03 0.00074 -5.40333E-03 0.00269 ];
INF_SCATTP5               (idx, [1:   4]) = [  1.57318E-06 1.00000  5.73454E-03 0.00250 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.49586E-03 0.00100 -1.25905E-02 0.00064 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.25701E-04 0.00648  4.60085E-04 0.01618 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27421E-01 7.5E-05  8.31028E-01 4.5E-05 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46571E+00 7.5E-05  4.01110E-01 4.5E-05 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.97367E-03 0.00017  4.80938E-02 0.00011 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36466E-02 6.7E-05  4.91309E-02 0.00011 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.98567E-01 2.6E-05  1.76468E-02 0.00012  1.02633E-03 0.00093  1.19014E+00 6.1E-05 ];
INF_S1                    (idx, [1:   8]) = [  2.20532E-01 4.9E-05  5.18003E-03 0.00028  3.97478E-04 0.00193  3.07789E-01 0.00012 ];
INF_S2                    (idx, [1:   8]) = [  9.13348E-02 9.1E-05 -1.48949E-03 0.00079  2.22549E-04 0.00243  7.68309E-02 0.00019 ];
INF_S3                    (idx, [1:   8]) = [  8.66275E-03 0.00085 -1.81021E-03 0.00055  7.99430E-05 0.00548  2.39955E-02 0.00064 ];
INF_S4                    (idx, [1:   8]) = [ -8.48348E-03 0.00077 -6.17690E-04 0.00140  2.15969E-06 0.20571 -5.40549E-03 0.00271 ];
INF_S5                    (idx, [1:   8]) = [ -5.26489E-06 0.88759  6.80868E-06 0.11112 -3.02462E-05 0.01221  5.76479E-03 0.00250 ];
INF_S6                    (idx, [1:   8]) = [  4.63602E-03 0.00098 -1.40185E-04 0.00454 -3.88425E-05 0.00909 -1.25516E-02 0.00066 ];
INF_S7                    (idx, [1:   8]) = [  7.90721E-04 0.00509 -1.65030E-04 0.00422 -3.58556E-05 0.00852  4.95940E-04 0.01490 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.98593E-01 2.6E-05  1.76468E-02 0.00012  1.02633E-03 0.00093  1.19014E+00 6.1E-05 ];
INF_SP1                   (idx, [1:   8]) = [  2.20533E-01 4.9E-05  5.18003E-03 0.00028  3.97478E-04 0.00193  3.07789E-01 0.00012 ];
INF_SP2                   (idx, [1:   8]) = [  9.13349E-02 9.1E-05 -1.48949E-03 0.00079  2.22549E-04 0.00243  7.68309E-02 0.00019 ];
INF_SP3                   (idx, [1:   8]) = [  8.66274E-03 0.00085 -1.81021E-03 0.00055  7.99430E-05 0.00548  2.39955E-02 0.00064 ];
INF_SP4                   (idx, [1:   8]) = [ -8.48344E-03 0.00077 -6.17690E-04 0.00140  2.15969E-06 0.20571 -5.40549E-03 0.00271 ];
INF_SP5                   (idx, [1:   8]) = [ -5.23549E-06 0.89144  6.80868E-06 0.11112 -3.02462E-05 0.01221  5.76479E-03 0.00250 ];
INF_SP6                   (idx, [1:   8]) = [  4.63604E-03 0.00098 -1.40185E-04 0.00454 -3.88425E-05 0.00909 -1.25516E-02 0.00066 ];
INF_SP7                   (idx, [1:   8]) = [  7.90731E-04 0.00509 -1.65030E-04 0.00422 -3.58556E-05 0.00852  4.95940E-04 0.01490 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37628E-01 0.00017  7.10630E-01 0.00089 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37826E-01 0.00030  7.21478E-01 0.00116 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37873E-01 0.00027  7.22204E-01 0.00114 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.37188E-01 0.00027  6.89243E-01 0.00102 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40275E+00 0.00017  4.69076E-01 0.00089 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40159E+00 0.00030  4.62030E-01 0.00116 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40131E+00 0.00027  4.61564E-01 0.00114 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40536E+00 0.00027  4.83634E-01 0.00102 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.74616E-03 0.00254  2.03883E-04 0.01386  1.09166E-03 0.00597  1.06942E-03 0.00595  3.09255E-03 0.00354  9.59450E-04 0.00677  3.29196E-04 0.01163 ];
LAMBDA                    (idx, [1:  14]) = [  7.89173E-01 0.00600  1.24907E-02 6.9E-07  3.17304E-02 6.9E-05  1.09830E-01 9.4E-05  3.19060E-01 7.8E-05  1.34898E+00 5.9E-05  8.77420E+00 0.00050 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 19:40:52 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  1.01945E+00  9.89488E-01  9.70566E-01  9.75640E-01  9.75226E-01  9.79515E-01  1.02607E+00  1.02438E+00  9.82168E-01  9.80465E-01  1.02777E+00  1.02256E+00  1.02596E+00  9.76609E-01  1.00913E+00  9.81936E-01  1.02883E+00  9.63009E-01  1.00982E+00  1.02075E+00  9.76274E-01  1.02387E+00  1.02819E+00  1.02867E+00  9.78795E-01  1.02199E+00  9.80313E-01  9.72557E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 9.3E-10  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.57343E-02 0.00028  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84266E-01 4.5E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.90072E-01 2.4E-05  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.91066E-01 2.4E-05  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.94767E+00 7.9E-05  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.08211E+01 9.3E-05  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.08211E+01 9.3E-05  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.82487E+01 0.00013  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.51811E-01 0.00031  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 50000432 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  1.00001E+05 0.00021 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  1.00001E+05 0.00021 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  5.42443E+02 ;
RUNNING_TIME              (idx, 1)        =  2.51710E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  9.18333E-03  3.55000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  1.94366E+01  7.23528E+00  4.88258E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  2.36500E-02  1.33000E-02 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  2.51708E+01  8.63461E+01 ];
CPU_USAGE                 (idx, 1)        = 21.55038 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  2.78743E+01 0.00053 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  6.58627E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.71668E+14 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.22949E+02 ;
TOT_SF_RATE               (idx, 1)        =  8.60465E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.32663E+14 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  9.25981E+00 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  8.39003E+14 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.13688E+02 ;
INHALATION_TOXICITY       (idx, 1)        =  3.74711E+05 ;
INGESTION_TOXICITY        (idx, 1)        =  3.79040E+05 ;
ACTINIDE_INH_TOX          (idx, 1)        =  8.23120E+04 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.48257E+04 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  2.92399E+05 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  3.24215E+05 ;
SR90_ACTIVITY             (idx, 1)        =  1.49035E+10 ;
TE132_ACTIVITY            (idx, 1)        =  6.91365E+12 ;
I131_ACTIVITY             (idx, 1)        =  4.12070E+12 ;
I132_ACTIVITY             (idx, 1)        =  6.96234E+12 ;
CS134_ACTIVITY            (idx, 1)        =  3.49323E+08 ;
CS137_ACTIVITY            (idx, 1)        =  1.56129E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.39961E+14 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.83069E+12 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.24178E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.18932E+15 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  3.11086E+09 0.00014  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 1 ;
BURNUP                     (idx, [1:  2])  = [  1.00000E+00  1.00001E+00 ];
BURN_DAYS                 (idx, 1)        =  2.50000E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.61595E-01 0.00036 ];
U235_FISS                 (idx, [1:   4]) = [  1.50184E+14 0.00018  9.36638E-01 5.3E-05 ];
U238_FISS                 (idx, [1:   4]) = [  5.67583E+12 0.00111  3.53973E-02 0.00107 ];
PU239_FISS                (idx, [1:   4]) = [  4.46669E+12 0.00119  2.78568E-02 0.00118 ];
PU240_FISS                (idx, [1:   4]) = [  2.85965E+08 0.15351  1.78520E-06 0.15351 ];
PU241_FISS                (idx, [1:   4]) = [  3.54611E+09 0.04095  2.21147E-05 0.04095 ];
U235_CAPT                 (idx, [1:   4]) = [  3.04632E+13 0.00044  2.01620E-01 0.00039 ];
U238_CAPT                 (idx, [1:   4]) = [  6.72586E+13 0.00033  4.45150E-01 0.00023 ];
PU239_CAPT                (idx, [1:   4]) = [  2.48930E+12 0.00152  1.64755E-02 0.00151 ];
PU240_CAPT                (idx, [1:   4]) = [  1.32913E+11 0.00649  8.79655E-04 0.00647 ];
PU241_CAPT                (idx, [1:   4]) = [  1.08275E+09 0.07880  7.16567E-06 0.07880 ];
XE135_CAPT                (idx, [1:   4]) = [  8.27619E+12 0.00082  5.47762E-02 0.00080 ];
SM149_CAPT                (idx, [1:   4]) = [  1.71341E+12 0.00186  1.13403E-02 0.00185 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50000432 5.00000E+07 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.63740E+04 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50000432 5.00564E+07 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 24257234 2.42846E+07 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 25743198 2.57718E+07 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50000432 5.00564E+07 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -4.84288E-07 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  5.20612E+03 2.9E-09  5.20612E+03 2.9E-09  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  4.00000E-02 8.1E-09  4.00000E-02 8.1E-09  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  3.94889E+14 2.2E-06  3.94889E+14 2.2E-06  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  1.60389E+14 2.7E-07  1.60389E+14 2.7E-07  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.51114E+14 0.00011  1.12422E+14 0.00013  3.86923E+13 0.00013 ];
TOT_ABSRATE               (idx, [1:   6]) = [  3.11504E+14 5.1E-05  2.72811E+14 5.4E-05  3.86923E+13 0.00013 ];
TOT_SRCRATE               (idx, [1:   6]) = [  3.11086E+14 0.00014  3.11086E+14 0.00014  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  1.79924E+16 0.00011  2.96713E+15 0.00013  1.50253E+16 0.00011 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  3.11504E+14 5.1E-05 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.27127E+16 9.2E-05 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.30018E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.30018E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.72025E+00 0.00012 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.65818E-01 6.5E-05 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.42954E-01 8.5E-05 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14679E+00 8.0E-05 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.26901E+00 0.00014 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.26901E+00 0.00014 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.46206E+00 2.4E-06 ];
FISSE                     (idx, [1:   2]) = [  2.02595E+02 2.7E-07 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.26903E+00 0.00015  1.26063E+00 0.00014  8.38250E-03 0.00231 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.26911E+00 5.1E-05 ];
COL_KEFF                  (idx, [1:   2]) = [  1.26940E+00 0.00014 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.26911E+00 5.1E-05 ];
ABS_KINF                  (idx, [1:   2]) = [  1.26911E+00 5.1E-05 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.82869E+01 4.4E-05 ];
IMP_ALF                   (idx, [1:   2]) = [  1.82858E+01 1.6E-05 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.28667E-07 0.00080 ];
IMP_EALF                  (idx, [1:   2]) = [  2.28891E-07 0.00030 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.18878E-01 0.00114 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.19134E-01 0.00039 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.31313E-03 0.00172  1.57019E-04 0.00999  8.69275E-04 0.00427  8.36979E-04 0.00413  2.43863E-03 0.00259  7.55524E-04 0.00440  2.55706E-04 0.00801 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.84755E-01 0.00409  1.24906E-02 9.7E-07  3.16895E-02 6.3E-05  1.09815E-01 6.8E-05  3.19229E-01 5.8E-05  1.34867E+00 4.4E-05  8.80271E+00 0.00041 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.65118E-03 0.00234  1.94688E-04 0.01432  1.09003E-03 0.00599  1.04079E-03 0.00590  3.05714E-03 0.00368  9.46743E-04 0.00618  3.21786E-04 0.01061 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.87523E-01 0.00563  1.24905E-02 1.4E-06  3.16927E-02 8.1E-05  1.09814E-01 9.4E-05  3.19224E-01 8.1E-05  1.34862E+00 6.1E-05  8.80177E+00 0.00055 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.69124E-05 0.00032  3.69025E-05 0.00032  3.83925E-05 0.00305 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.68423E-05 0.00027  4.68297E-05 0.00028  4.87207E-05 0.00305 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.60736E-03 0.00231  1.96067E-04 0.01360  1.08444E-03 0.00598  1.03489E-03 0.00586  3.03033E-03 0.00356  9.41371E-04 0.00613  3.20257E-04 0.01175 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.87632E-01 0.00612  1.24905E-02 1.5E-06  3.16897E-02 8.8E-05  1.09816E-01 0.00010  3.19212E-01 8.3E-05  1.34868E+00 6.2E-05  8.79828E+00 0.00062 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.69114E-05 0.00066  3.69013E-05 0.00066  3.83774E-05 0.00741 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.68410E-05 0.00063  4.68281E-05 0.00064  4.87022E-05 0.00742 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.67656E-03 0.00685  2.04364E-04 0.03982  1.11847E-03 0.01733  1.03731E-03 0.01795  3.07287E-03 0.01058  9.39729E-04 0.01831  3.03814E-04 0.03373 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  7.61103E-01 0.01733  1.24906E-02 3.3E-06  3.16920E-02 0.00024  1.09757E-01 0.00026  3.19096E-01 0.00023  1.34904E+00 0.00018  8.79212E+00 0.00165 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.66395E-03 0.00661  2.06689E-04 0.03844  1.11076E-03 0.01661  1.03343E-03 0.01728  3.07120E-03 0.01021  9.39420E-04 0.01803  3.02452E-04 0.03262 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.59286E-01 0.01663  1.24906E-02 3.3E-06  3.16910E-02 0.00024  1.09760E-01 0.00025  3.19104E-01 0.00022  1.34907E+00 0.00017  8.78904E+00 0.00161 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.80973E+02 0.00689 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.69395E-05 0.00020 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.68766E-05 0.00013 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.61781E-03 0.00146 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.79155E+02 0.00146 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  6.92094E-07 0.00014 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.31912E-06 0.00014  3.31911E-06 0.00014  3.32171E-06 0.00170 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.02107E-05 0.00017  5.02116E-05 0.00017  5.00722E-05 0.00205 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.43363E-01 8.5E-05  7.42171E-01 8.6E-05  9.68004E-01 0.00253 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.05116E+01 0.00395 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.08211E+01 9.3E-05  4.46517E+01 0.00012 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  7.01295E+05 0.00087  2.87149E+06 0.00058  6.17990E+06 0.00039  7.45717E+06 0.00027  7.12708E+06 0.00023  7.47167E+06 0.00020  5.13989E+06 0.00023  4.41541E+06 0.00023  3.37799E+06 0.00024  2.75831E+06 0.00034  2.36648E+06 0.00034  2.17078E+06 0.00031  1.98773E+06 0.00029  1.88791E+06 0.00034  1.83514E+06 0.00028  1.59874E+06 0.00028  1.56831E+06 0.00033  1.56544E+06 0.00034  1.54738E+06 0.00030  3.02525E+06 0.00027  2.91616E+06 0.00027  2.13957E+06 0.00035  1.39784E+06 0.00032  1.63555E+06 0.00027  1.57101E+06 0.00035  1.41254E+06 0.00029  2.40580E+06 0.00019  5.42832E+05 0.00062  6.81751E+05 0.00046  6.19446E+05 0.00051  3.60791E+05 0.00065  6.26673E+05 0.00051  4.27484E+05 0.00078  3.65554E+05 0.00087  7.01481E+04 0.00113  6.96079E+04 0.00104  7.13099E+04 0.00090  7.33406E+04 0.00091  7.25983E+04 0.00108  7.15327E+04 0.00114  7.41039E+04 0.00133  6.94715E+04 0.00117  1.31490E+05 0.00090  2.10226E+05 0.00072  2.68014E+05 0.00055  7.10274E+05 0.00044  7.58202E+05 0.00051  8.58275E+05 0.00034  6.09539E+05 0.00057  4.57858E+05 0.00054  3.67590E+05 0.00054  4.41710E+05 0.00028  8.45452E+05 0.00046  1.12729E+06 0.00032  2.22725E+06 0.00024  3.30909E+06 0.00023  4.84792E+06 0.00026  3.02601E+06 0.00029  2.14346E+06 0.00029  1.52484E+06 0.00034  1.35609E+06 0.00029  1.32601E+06 0.00028  1.10936E+06 0.00030  7.39854E+05 0.00039  6.83086E+05 0.00040  6.07021E+05 0.00041  5.16361E+05 0.00045  3.97677E+05 0.00047  2.58211E+05 0.00047  8.89636E+04 0.00108 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.26940E+00 0.00014 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.33842E+16 0.00013  4.60828E+15 0.00011 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.22209E-01 3.6E-05  1.24199E+00 6.3E-05 ];
INF_CAPT                  (idx, [1:   4]) = [  4.52087E-03 0.00021  1.96618E-02 6.8E-05 ];
INF_ABS                   (idx, [1:   4]) = [  6.00385E-03 0.00018  5.01595E-02 9.1E-05 ];
INF_FISS                  (idx, [1:   4]) = [  1.48298E-03 0.00020  3.04978E-02 0.00011 ];
INF_NSF                   (idx, [1:   4]) = [  3.77931E-03 0.00021  7.47154E-02 0.00011 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54845E+00 2.0E-05  2.44986E+00 6.4E-07 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03683E+02 2.2E-06  2.02441E+02 1.0E-07 ];
INF_INVV                  (idx, [1:   4]) = [  6.35027E-08 0.00012  2.51777E-06 4.1E-05 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.16208E-01 3.6E-05  1.19184E+00 6.7E-05 ];
INF_SCATT1                (idx, [1:   4]) = [  2.25702E-01 5.6E-05  3.08879E-01 0.00013 ];
INF_SCATT2                (idx, [1:   4]) = [  8.98431E-02 7.2E-05  7.73299E-02 0.00022 ];
INF_SCATT3                (idx, [1:   4]) = [  6.85905E-03 0.00089  2.41568E-02 0.00055 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.08801E-03 0.00079 -5.37250E-03 0.00265 ];
INF_SCATT5                (idx, [1:   4]) = [  1.74900E-05 0.28325  5.72698E-03 0.00209 ];
INF_SCATT6                (idx, [1:   4]) = [  4.50800E-03 0.00091 -1.25638E-02 0.00085 ];
INF_SCATT7                (idx, [1:   4]) = [  6.18247E-04 0.00609  4.30584E-04 0.01977 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.16234E-01 3.6E-05  1.19184E+00 6.7E-05 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.25703E-01 5.6E-05  3.08879E-01 0.00013 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.98432E-02 7.2E-05  7.73299E-02 0.00022 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.85902E-03 0.00089  2.41568E-02 0.00055 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.08799E-03 0.00079 -5.37250E-03 0.00265 ];
INF_SCATTP5               (idx, [1:   4]) = [  1.74825E-05 0.28334  5.72698E-03 0.00209 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.50800E-03 0.00091 -1.25638E-02 0.00085 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.18251E-04 0.00609  4.30584E-04 0.01977 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27370E-01 7.5E-05  8.32626E-01 6.5E-05 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46604E+00 7.5E-05  4.00340E-01 6.5E-05 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.97764E-03 0.00017  5.01595E-02 9.1E-05 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36371E-02 6.6E-05  5.12232E-02 0.00015 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.98572E-01 3.5E-05  1.76365E-02 9.8E-05  1.06948E-03 0.00119  1.19077E+00 6.7E-05 ];
INF_S1                    (idx, [1:   8]) = [  2.20525E-01 5.5E-05  5.17756E-03 0.00026  4.12450E-04 0.00211  3.08467E-01 0.00013 ];
INF_S2                    (idx, [1:   8]) = [  9.13317E-02 7.2E-05 -1.48857E-03 0.00073  2.31499E-04 0.00239  7.70984E-02 0.00022 ];
INF_S3                    (idx, [1:   8]) = [  8.66920E-03 0.00071 -1.81016E-03 0.00041  8.26840E-05 0.00544  2.40741E-02 0.00055 ];
INF_S4                    (idx, [1:   8]) = [ -8.47033E-03 0.00081 -6.17677E-04 0.00151  1.45737E-06 0.31429 -5.37396E-03 0.00268 ];
INF_S5                    (idx, [1:   8]) = [  9.70462E-06 0.51673  7.78538E-06 0.09709 -3.23928E-05 0.00992  5.75937E-03 0.00209 ];
INF_S6                    (idx, [1:   8]) = [  4.64881E-03 0.00084 -1.40809E-04 0.00472 -4.10696E-05 0.00859 -1.25227E-02 0.00086 ];
INF_S7                    (idx, [1:   8]) = [  7.84780E-04 0.00472 -1.66533E-04 0.00474 -3.82616E-05 0.00745  4.68846E-04 0.01824 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.98598E-01 3.5E-05  1.76365E-02 9.8E-05  1.06948E-03 0.00119  1.19077E+00 6.7E-05 ];
INF_SP1                   (idx, [1:   8]) = [  2.20525E-01 5.5E-05  5.17756E-03 0.00026  4.12450E-04 0.00211  3.08467E-01 0.00013 ];
INF_SP2                   (idx, [1:   8]) = [  9.13318E-02 7.2E-05 -1.48857E-03 0.00073  2.31499E-04 0.00239  7.70984E-02 0.00022 ];
INF_SP3                   (idx, [1:   8]) = [  8.66918E-03 0.00071 -1.81016E-03 0.00041  8.26840E-05 0.00544  2.40741E-02 0.00055 ];
INF_SP4                   (idx, [1:   8]) = [ -8.47031E-03 0.00081 -6.17677E-04 0.00151  1.45737E-06 0.31429 -5.37396E-03 0.00268 ];
INF_SP5                   (idx, [1:   8]) = [  9.69717E-06 0.51706  7.78538E-06 0.09709 -3.23928E-05 0.00992  5.75937E-03 0.00209 ];
INF_SP6                   (idx, [1:   8]) = [  4.64881E-03 0.00084 -1.40809E-04 0.00472 -4.10696E-05 0.00859 -1.25227E-02 0.00086 ];
INF_SP7                   (idx, [1:   8]) = [  7.84784E-04 0.00472 -1.66533E-04 0.00474 -3.82616E-05 0.00745  4.68846E-04 0.01824 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37530E-01 0.00021  7.09362E-01 0.00101 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37763E-01 0.00031  7.19918E-01 0.00126 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37797E-01 0.00034  7.20437E-01 0.00129 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.37034E-01 0.00032  6.88698E-01 0.00106 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40333E+00 0.00021  4.69917E-01 0.00101 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40196E+00 0.00031  4.63034E-01 0.00126 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40176E+00 0.00034  4.62701E-01 0.00129 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40627E+00 0.00032  4.84018E-01 0.00106 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.65118E-03 0.00234  1.94688E-04 0.01432  1.09003E-03 0.00599  1.04079E-03 0.00590  3.05714E-03 0.00368  9.46743E-04 0.00618  3.21786E-04 0.01061 ];
LAMBDA                    (idx, [1:  14]) = [  7.87523E-01 0.00563  1.24905E-02 1.4E-06  3.16927E-02 8.1E-05  1.09814E-01 9.4E-05  3.19224E-01 8.1E-05  1.34862E+00 6.1E-05  8.80177E+00 0.00055 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 19:53:24 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  9.74230E-01  1.02483E+00  9.94621E-01  1.02534E+00  9.73830E-01  9.79016E-01  1.02552E+00  1.02857E+00  9.97095E-01  9.70186E-01  9.71458E-01  1.02756E+00  1.02873E+00  9.74325E-01  1.02567E+00  1.02326E+00  9.75189E-01  9.73646E-01  9.78349E-01  1.02330E+00  9.78345E-01  1.02756E+00  1.02669E+00  1.02194E+00  9.73189E-01  1.02409E+00  9.79161E-01  9.74311E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 1.6E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.57551E-02 0.00028  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84245E-01 4.5E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.90357E-01 2.4E-05  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.91352E-01 2.4E-05  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.94566E+00 7.9E-05  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.06764E+01 9.0E-05  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.06764E+01 9.0E-05  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.81596E+01 0.00012  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.49644E-01 0.00031  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 50000942 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  1.00002E+05 0.00020 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  1.00002E+05 0.00020 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  8.89707E+02 ;
RUNNING_TIME              (idx, 1)        =  3.77102E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  1.82500E-02  5.21667E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.19238E+01  7.27122E+00  5.21592E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  6.66000E-02  2.56833E-02 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  3.77099E+01  8.77619E+01 ];
CPU_USAGE                 (idx, 1)        = 23.59330 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  2.79262E+01 0.00026 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  7.11670E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.93166E+14 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.24014E+02 ;
TOT_SF_RATE               (idx, 1)        =  8.75601E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.35854E+14 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  9.48108E+00 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  8.57311E+14 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.14531E+02 ;
INHALATION_TOXICITY       (idx, 1)        =  5.03414E+05 ;
INGESTION_TOXICITY        (idx, 1)        =  4.21116E+05 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.03297E+05 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.62488E+04 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  4.00116E+05 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  3.64867E+05 ;
SR90_ACTIVITY             (idx, 1)        =  2.94839E+10 ;
TE132_ACTIVITY            (idx, 1)        =  6.98739E+12 ;
I131_ACTIVITY             (idx, 1)        =  4.64617E+12 ;
I132_ACTIVITY             (idx, 1)        =  7.04944E+12 ;
CS134_ACTIVITY            (idx, 1)        =  1.95581E+09 ;
CS137_ACTIVITY            (idx, 1)        =  3.12383E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.56366E+14 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.80429E+12 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.65961E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.22481E+15 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  3.15214E+09 0.00013  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 2 ;
BURNUP                     (idx, [1:  2])  = [  2.00000E+00  2.00001E+00 ];
BURN_DAYS                 (idx, 1)        =  5.00000E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.64722E-01 0.00035 ];
U235_FISS                 (idx, [1:   4]) = [  1.45262E+14 0.00017  9.06560E-01 6.6E-05 ];
U238_FISS                 (idx, [1:   4]) = [  5.77084E+12 0.00114  3.60145E-02 0.00109 ];
PU239_FISS                (idx, [1:   4]) = [  9.15351E+12 0.00085  5.71261E-02 0.00084 ];
PU240_FISS                (idx, [1:   4]) = [  1.13465E+09 0.07322  7.08099E-06 0.07321 ];
PU241_FISS                (idx, [1:   4]) = [  2.93432E+10 0.01455  1.83139E-04 0.01455 ];
U235_CAPT                 (idx, [1:   4]) = [  2.94946E+13 0.00044  1.89878E-01 0.00041 ];
U238_CAPT                 (idx, [1:   4]) = [  6.79606E+13 0.00033  4.37509E-01 0.00023 ];
PU239_CAPT                (idx, [1:   4]) = [  5.10279E+12 0.00113  3.28503E-02 0.00112 ];
PU240_CAPT                (idx, [1:   4]) = [  5.46163E+11 0.00318  3.51605E-03 0.00318 ];
PU241_CAPT                (idx, [1:   4]) = [  1.03333E+10 0.02333  6.65126E-05 0.02331 ];
XE135_CAPT                (idx, [1:   4]) = [  8.34246E+12 0.00082  5.37069E-02 0.00083 ];
SM149_CAPT                (idx, [1:   4]) = [  1.79260E+12 0.00194  1.15401E-02 0.00192 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50000942 5.00000E+07 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.62625E+04 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50000942 5.00563E+07 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 24611972 2.46395E+07 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 25388970 2.54167E+07 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50000942 5.00563E+07 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -1.68383E-06 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  5.20612E+03 2.9E-09  5.20612E+03 2.9E-09  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  4.00000E-02 8.1E-09  4.00000E-02 8.1E-09  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  3.96633E+14 2.3E-06  3.96633E+14 2.3E-06  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  1.60256E+14 3.2E-07  1.60256E+14 3.2E-07  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.55329E+14 0.00010  1.16377E+14 0.00012  3.89525E+13 0.00013 ];
TOT_ABSRATE               (idx, [1:   6]) = [  3.15585E+14 5.2E-05  2.76633E+14 5.2E-05  3.89525E+13 0.00013 ];
TOT_SRCRATE               (idx, [1:   6]) = [  3.15214E+14 0.00013  3.15214E+14 0.00013  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  1.81926E+16 0.00011  2.99993E+15 0.00013  1.51926E+16 0.00011 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  3.15585E+14 5.2E-05 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.28358E+16 9.7E-05 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29883E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29883E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.70738E+00 0.00011 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.66794E-01 6.5E-05 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.41909E-01 8.4E-05 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14583E+00 8.0E-05 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.25811E+00 0.00014 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.25811E+00 0.00014 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.47500E+00 2.6E-06 ];
FISSE                     (idx, [1:   2]) = [  2.02764E+02 3.2E-07 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.25811E+00 0.00014  1.24999E+00 0.00014  8.11791E-03 0.00253 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.25824E+00 5.2E-05 ];
COL_KEFF                  (idx, [1:   2]) = [  1.25831E+00 0.00013 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.25824E+00 5.2E-05 ];
ABS_KINF                  (idx, [1:   2]) = [  1.25824E+00 5.2E-05 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.82682E+01 4.5E-05 ];
IMP_ALF                   (idx, [1:   2]) = [  1.82679E+01 1.6E-05 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.32987E-07 0.00082 ];
IMP_EALF                  (idx, [1:   2]) = [  2.33012E-07 0.00030 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.21048E-01 0.00115 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.20883E-01 0.00039 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.24490E-03 0.00167  1.53996E-04 0.00991  8.62146E-04 0.00412  8.30202E-04 0.00427  2.40219E-03 0.00260  7.46209E-04 0.00476  2.50158E-04 0.00768 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.81135E-01 0.00391  1.24905E-02 7.6E-06  3.16492E-02 7.2E-05  1.09822E-01 7.1E-05  3.19284E-01 5.8E-05  1.34841E+00 4.9E-05  8.80958E+00 0.00045 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.48385E-03 0.00240  1.88900E-04 0.01348  1.06900E-03 0.00600  1.02292E-03 0.00621  2.96359E-03 0.00366  9.25965E-04 0.00662  3.13472E-04 0.01086 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.87073E-01 0.00560  1.24904E-02 2.1E-06  3.16522E-02 9.5E-05  1.09822E-01 0.00010  3.19280E-01 8.2E-05  1.34837E+00 6.7E-05  8.80649E+00 0.00060 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.70137E-05 0.00031  3.70030E-05 0.00031  3.86575E-05 0.00319 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.65669E-05 0.00027  4.65535E-05 0.00027  4.86349E-05 0.00319 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.45404E-03 0.00253  1.89863E-04 0.01437  1.05796E-03 0.00611  1.02318E-03 0.00603  2.95537E-03 0.00389  9.16634E-04 0.00684  3.11040E-04 0.01103 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.85197E-01 0.00574  1.24904E-02 2.1E-06  3.16457E-02 0.00010  1.09823E-01 0.00010  3.19309E-01 8.3E-05  1.34854E+00 6.4E-05  8.80482E+00 0.00062 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.69967E-05 0.00066  3.69858E-05 0.00066  3.86482E-05 0.00742 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.65456E-05 0.00065  4.65318E-05 0.00064  4.86221E-05 0.00741 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.42170E-03 0.00700  1.86823E-04 0.04456  1.03521E-03 0.01800  1.01161E-03 0.01825  2.96178E-03 0.01063  9.21777E-04 0.01853  3.04503E-04 0.03159 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  7.84341E-01 0.01690  1.24905E-02 5.4E-06  3.16452E-02 0.00031  1.09896E-01 0.00034  3.19356E-01 0.00025  1.34893E+00 0.00017  8.79936E+00 0.00164 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.41560E-03 0.00691  1.87707E-04 0.04268  1.03404E-03 0.01755  1.01188E-03 0.01785  2.96188E-03 0.01034  9.17878E-04 0.01790  3.02219E-04 0.03125 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.80429E-01 0.01655  1.24905E-02 5.5E-06  3.16461E-02 0.00030  1.09894E-01 0.00033  3.19345E-01 0.00024  1.34886E+00 0.00017  8.80115E+00 0.00161 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.73648E+02 0.00700 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.70418E-05 0.00019 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.66023E-05 0.00013 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.46083E-03 0.00147 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.74423E+02 0.00148 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  6.88268E-07 0.00014 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.31365E-06 0.00014  3.31370E-06 0.00014  3.30683E-06 0.00178 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  4.98739E-05 0.00017  4.98744E-05 0.00017  4.98031E-05 0.00197 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.42317E-01 8.4E-05  7.41208E-01 8.4E-05  9.53968E-01 0.00259 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.05532E+01 0.00435 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.06764E+01 9.0E-05  4.45181E+01 0.00012 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  7.06079E+05 0.00087  2.88090E+06 0.00047  6.18785E+06 0.00031  7.45751E+06 0.00024  7.12832E+06 0.00028  7.47152E+06 0.00018  5.13839E+06 0.00022  4.41566E+06 0.00027  3.37824E+06 0.00029  2.75951E+06 0.00024  2.36745E+06 0.00028  2.17095E+06 0.00031  1.98662E+06 0.00024  1.88736E+06 0.00026  1.83389E+06 0.00037  1.59878E+06 0.00043  1.56829E+06 0.00034  1.56606E+06 0.00032  1.54715E+06 0.00039  3.02549E+06 0.00026  2.91563E+06 0.00022  2.14030E+06 0.00025  1.39640E+06 0.00026  1.63714E+06 0.00032  1.57159E+06 0.00035  1.41185E+06 0.00037  2.40331E+06 0.00027  5.42831E+05 0.00052  6.81421E+05 0.00048  6.19384E+05 0.00054  3.60815E+05 0.00059  6.26907E+05 0.00065  4.27403E+05 0.00058  3.65811E+05 0.00062  6.99697E+04 0.00101  6.91847E+04 0.00125  7.04679E+04 0.00083  7.22235E+04 0.00125  7.16695E+04 0.00115  7.08017E+04 0.00130  7.35951E+04 0.00109  6.93099E+04 0.00105  1.31217E+05 0.00080  2.09695E+05 0.00068  2.67622E+05 0.00071  7.09269E+05 0.00040  7.56770E+05 0.00039  8.53945E+05 0.00040  6.04600E+05 0.00051  4.51790E+05 0.00052  3.61388E+05 0.00054  4.33558E+05 0.00039  8.31807E+05 0.00039  1.11195E+06 0.00026  2.20233E+06 0.00026  3.27578E+06 0.00023  4.80650E+06 0.00023  3.00233E+06 0.00024  2.12742E+06 0.00029  1.51315E+06 0.00029  1.34641E+06 0.00033  1.31757E+06 0.00025  1.10208E+06 0.00036  7.34733E+05 0.00033  6.78348E+05 0.00034  6.03409E+05 0.00036  5.12578E+05 0.00042  3.94909E+05 0.00054  2.56416E+05 0.00062  8.85315E+04 0.00075 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.25831E+00 0.00015 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.35640E+16 0.00016  4.62865E+15 0.00011 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.22174E-01 3.5E-05  1.24294E+00 5.6E-05 ];
INF_CAPT                  (idx, [1:   4]) = [  4.56646E-03 0.00023  2.01767E-02 8.1E-05 ];
INF_ABS                   (idx, [1:   4]) = [  6.02363E-03 0.00019  5.05294E-02 0.00011 ];
INF_FISS                  (idx, [1:   4]) = [  1.45716E-03 0.00015  3.03527E-02 0.00013 ];
INF_NSF                   (idx, [1:   4]) = [  3.72278E-03 0.00015  7.47822E-02 0.00013 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.55481E+00 1.7E-05  2.46377E+00 1.1E-06 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03764E+02 1.5E-06  2.02623E+02 1.9E-07 ];
INF_INVV                  (idx, [1:   4]) = [  6.34233E-08 0.00017  2.51934E-06 3.6E-05 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.16150E-01 3.6E-05  1.19241E+00 5.8E-05 ];
INF_SCATT1                (idx, [1:   4]) = [  2.25657E-01 6.1E-05  3.09012E-01 8.3E-05 ];
INF_SCATT2                (idx, [1:   4]) = [  8.98350E-02 9.5E-05  7.73834E-02 0.00024 ];
INF_SCATT3                (idx, [1:   4]) = [  6.86466E-03 0.00102  2.41547E-02 0.00053 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.08354E-03 0.00076 -5.37981E-03 0.00291 ];
INF_SCATT5                (idx, [1:   4]) = [  1.15054E-05 0.42540  5.73634E-03 0.00264 ];
INF_SCATT6                (idx, [1:   4]) = [  4.50107E-03 0.00102 -1.25969E-02 0.00079 ];
INF_SCATT7                (idx, [1:   4]) = [  6.32604E-04 0.00692  4.31927E-04 0.02092 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.16176E-01 3.6E-05  1.19241E+00 5.8E-05 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.25657E-01 6.1E-05  3.09012E-01 8.3E-05 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.98352E-02 9.5E-05  7.73834E-02 0.00024 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.86466E-03 0.00102  2.41547E-02 0.00053 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.08352E-03 0.00076 -5.37981E-03 0.00291 ];
INF_SCATTP5               (idx, [1:   4]) = [  1.15303E-05 0.42399  5.73634E-03 0.00264 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.50107E-03 0.00102 -1.25969E-02 0.00079 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.32581E-04 0.00691  4.31927E-04 0.02092 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27316E-01 7.7E-05  8.33961E-01 5.5E-05 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46639E+00 7.7E-05  3.99699E-01 5.5E-05 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.99748E-03 0.00019  5.05294E-02 0.00011 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36326E-02 7.3E-05  5.16009E-02 0.00017 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.98541E-01 3.5E-05  1.76086E-02 0.00010  1.07638E-03 0.00105  1.19134E+00 5.8E-05 ];
INF_S1                    (idx, [1:   8]) = [  2.20489E-01 6.2E-05  5.16869E-03 0.00030  4.16927E-04 0.00161  3.08595E-01 8.3E-05 ];
INF_S2                    (idx, [1:   8]) = [  9.13228E-02 9.4E-05 -1.48780E-03 0.00069  2.34472E-04 0.00291  7.71490E-02 0.00025 ];
INF_S3                    (idx, [1:   8]) = [  8.67100E-03 0.00076 -1.80633E-03 0.00047  8.57477E-05 0.00534  2.40690E-02 0.00053 ];
INF_S4                    (idx, [1:   8]) = [ -8.46859E-03 0.00078 -6.14954E-04 0.00149  2.69490E-06 0.15634 -5.38251E-03 0.00289 ];
INF_S5                    (idx, [1:   8]) = [  4.06672E-06 1.00000  7.43872E-06 0.08231 -3.17117E-05 0.01347  5.76805E-03 0.00261 ];
INF_S6                    (idx, [1:   8]) = [  4.64171E-03 0.00098 -1.40636E-04 0.00493 -4.14301E-05 0.00836 -1.25555E-02 0.00079 ];
INF_S7                    (idx, [1:   8]) = [  7.98748E-04 0.00536 -1.66144E-04 0.00339 -3.86309E-05 0.00684  4.70557E-04 0.01930 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.98567E-01 3.5E-05  1.76086E-02 0.00010  1.07638E-03 0.00105  1.19134E+00 5.8E-05 ];
INF_SP1                   (idx, [1:   8]) = [  2.20489E-01 6.2E-05  5.16869E-03 0.00030  4.16927E-04 0.00161  3.08595E-01 8.3E-05 ];
INF_SP2                   (idx, [1:   8]) = [  9.13230E-02 9.4E-05 -1.48780E-03 0.00069  2.34472E-04 0.00291  7.71490E-02 0.00025 ];
INF_SP3                   (idx, [1:   8]) = [  8.67099E-03 0.00077 -1.80633E-03 0.00047  8.57477E-05 0.00534  2.40690E-02 0.00053 ];
INF_SP4                   (idx, [1:   8]) = [ -8.46856E-03 0.00078 -6.14954E-04 0.00149  2.69490E-06 0.15634 -5.38251E-03 0.00289 ];
INF_SP5                   (idx, [1:   8]) = [  4.09158E-06 1.00000  7.43872E-06 0.08231 -3.17117E-05 0.01347  5.76805E-03 0.00261 ];
INF_SP6                   (idx, [1:   8]) = [  4.64171E-03 0.00098 -1.40636E-04 0.00493 -4.14301E-05 0.00836 -1.25555E-02 0.00079 ];
INF_SP7                   (idx, [1:   8]) = [  7.98725E-04 0.00535 -1.66144E-04 0.00339 -3.86309E-05 0.00684  4.70557E-04 0.01930 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37525E-01 0.00018  7.10287E-01 0.00132 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37806E-01 0.00033  7.21099E-01 0.00144 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37801E-01 0.00032  7.20403E-01 0.00166 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.36973E-01 0.00017  6.90267E-01 0.00133 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40336E+00 0.00018  4.69313E-01 0.00132 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40171E+00 0.00033  4.62280E-01 0.00144 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40174E+00 0.00032  4.62735E-01 0.00168 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40663E+00 0.00017  4.82925E-01 0.00133 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.48385E-03 0.00240  1.88900E-04 0.01348  1.06900E-03 0.00600  1.02292E-03 0.00621  2.96359E-03 0.00366  9.25965E-04 0.00662  3.13472E-04 0.01086 ];
LAMBDA                    (idx, [1:  14]) = [  7.87073E-01 0.00560  1.24904E-02 2.1E-06  3.16522E-02 9.5E-05  1.09822E-01 0.00010  3.19280E-01 8.2E-05  1.34837E+00 6.7E-05  8.80649E+00 0.00060 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 20:05:30 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  1.02324E+00  1.02369E+00  1.02418E+00  1.02336E+00  9.72816E-01  9.79000E-01  9.78700E-01  1.02802E+00  1.02552E+00  1.00754E+00  9.75862E-01  1.02032E+00  1.02577E+00  9.78421E-01  9.85204E-01  1.02733E+00  9.79942E-01  9.69953E-01  9.80627E-01  1.01809E+00  9.73080E-01  9.86097E-01  1.02897E+00  1.02543E+00  9.77285E-01  9.75582E-01  1.01129E+00  9.74685E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.57546E-02 0.00030  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84245E-01 4.8E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.90438E-01 2.4E-05  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.91433E-01 2.4E-05  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.94548E+00 7.6E-05  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.06537E+01 8.8E-05  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.06537E+01 8.8E-05  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.81426E+01 0.00012  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.49171E-01 0.00033  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 49999838 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  9.99997E+04 0.00019 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  9.99997E+04 0.00019 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.22690E+03 ;
RUNNING_TIME              (idx, 1)        =  4.98054E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  2.73500E-02  4.50000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  4.39861E+01  7.16513E+00  4.89715E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  9.03667E-02  1.09500E-02 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  4.98052E+01  8.64030E+01 ];
CPU_USAGE                 (idx, 1)        = 24.63395 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  2.79508E+01 0.00010 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  7.43084E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.97945E+14 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.24733E+02 ;
TOT_SF_RATE               (idx, 1)        =  8.79973E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.36648E+14 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  9.53674E+00 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  8.61295E+14 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.15195E+02 ;
INHALATION_TOXICITY       (idx, 1)        =  5.24745E+05 ;
INGESTION_TOXICITY        (idx, 1)        =  4.26260E+05 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.07988E+05 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.65553E+04 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  4.16757E+05 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  3.69704E+05 ;
SR90_ACTIVITY             (idx, 1)        =  3.23615E+10 ;
TE132_ACTIVITY            (idx, 1)        =  7.00207E+12 ;
I131_ACTIVITY             (idx, 1)        =  4.67769E+12 ;
I132_ACTIVITY             (idx, 1)        =  7.06611E+12 ;
CS134_ACTIVITY            (idx, 1)        =  2.44224E+09 ;
CS137_ACTIVITY            (idx, 1)        =  3.43624E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.59976E+14 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.80340E+12 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.95569E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.23160E+15 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  3.16081E+09 0.00013  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 3 ;
BURNUP                     (idx, [1:  2])  = [  2.20000E+00  2.20002E+00 ];
BURN_DAYS                 (idx, 1)        =  5.50000E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.65459E-01 0.00035 ];
U235_FISS                 (idx, [1:   4]) = [  1.44339E+14 0.00018  9.00808E-01 6.7E-05 ];
U238_FISS                 (idx, [1:   4]) = [  5.78087E+12 0.00108  3.60774E-02 0.00104 ];
PU239_FISS                (idx, [1:   4]) = [  1.00548E+13 0.00078  6.27511E-02 0.00077 ];
PU240_FISS                (idx, [1:   4]) = [  1.32177E+09 0.06840  8.24667E-06 0.06837 ];
PU241_FISS                (idx, [1:   4]) = [  3.83188E+10 0.01200  2.39138E-04 0.01199 ];
U235_CAPT                 (idx, [1:   4]) = [  2.93098E+13 0.00048  1.87633E-01 0.00043 ];
U238_CAPT                 (idx, [1:   4]) = [  6.81096E+13 0.00031  4.36018E-01 0.00023 ];
PU239_CAPT                (idx, [1:   4]) = [  5.59750E+12 0.00105  3.58340E-02 0.00105 ];
PU240_CAPT                (idx, [1:   4]) = [  6.48628E+11 0.00305  4.15229E-03 0.00304 ];
PU241_CAPT                (idx, [1:   4]) = [  1.36219E+10 0.02206  8.72141E-05 0.02207 ];
XE135_CAPT                (idx, [1:   4]) = [  8.37248E+12 0.00087  5.35987E-02 0.00087 ];
SM149_CAPT                (idx, [1:   4]) = [  1.79770E+12 0.00184  1.15083E-02 0.00183 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 49999838 5.00000E+07 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.69550E+04 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 49999838 5.00570E+07 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 24681537 2.47101E+07 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 25318301 2.53469E+07 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 49999838 5.00570E+07 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.61515E-06 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  5.20612E+03 2.9E-09  5.20612E+03 2.9E-09  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  4.00000E-02 8.1E-09  4.00000E-02 8.1E-09  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  3.96963E+14 2.5E-06  3.96963E+14 2.5E-06  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  1.60231E+14 3.2E-07  1.60231E+14 3.2E-07  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.56208E+14 9.8E-05  1.17193E+14 0.00012  3.90152E+13 0.00013 ];
TOT_ABSRATE               (idx, [1:   6]) = [  3.16439E+14 4.9E-05  2.77423E+14 5.1E-05  3.90152E+13 0.00013 ];
TOT_SRCRATE               (idx, [1:   6]) = [  3.16081E+14 0.00013  3.16081E+14 0.00013  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  1.82397E+16 0.00011  3.00777E+15 0.00012  1.52319E+16 0.00011 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  3.16439E+14 4.9E-05 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.28642E+16 9.4E-05 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29856E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29856E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.70502E+00 0.00012 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.66893E-01 6.7E-05 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.41614E-01 8.4E-05 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14573E+00 8.0E-05 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.25590E+00 0.00014 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.25590E+00 0.00014 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.47745E+00 2.8E-06 ];
FISSE                     (idx, [1:   2]) = [  2.02796E+02 3.2E-07 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.25582E+00 0.00014  1.24781E+00 0.00014  8.09592E-03 0.00247 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.25590E+00 4.8E-05 ];
COL_KEFF                  (idx, [1:   2]) = [  1.25590E+00 0.00013 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.25590E+00 4.8E-05 ];
ABS_KINF                  (idx, [1:   2]) = [  1.25590E+00 4.8E-05 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.82650E+01 4.4E-05 ];
IMP_ALF                   (idx, [1:   2]) = [  1.82637E+01 1.6E-05 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.33730E-07 0.00080 ];
IMP_EALF                  (idx, [1:   2]) = [  2.33988E-07 0.00029 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.21186E-01 0.00110 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.21403E-01 0.00041 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.24627E-03 0.00173  1.56369E-04 0.01018  8.66144E-04 0.00432  8.30573E-04 0.00433  2.40211E-03 0.00250  7.41965E-04 0.00461  2.49116E-04 0.00804 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.78892E-01 0.00418  1.24905E-02 1.3E-06  3.16404E-02 7.3E-05  1.09815E-01 7.0E-05  3.19335E-01 5.6E-05  1.34831E+00 5.5E-05  8.82479E+00 0.00045 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.48686E-03 0.00238  1.94766E-04 0.01463  1.07093E-03 0.00605  1.02428E-03 0.00586  2.97234E-03 0.00351  9.13204E-04 0.00644  3.11338E-04 0.01109 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.82794E-01 0.00577  1.24905E-02 1.7E-06  3.16406E-02 9.4E-05  1.09816E-01 0.00010  3.19382E-01 7.9E-05  1.34829E+00 7.2E-05  8.82426E+00 0.00063 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.70124E-05 0.00030  3.70017E-05 0.00030  3.86691E-05 0.00342 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.64804E-05 0.00027  4.64669E-05 0.00027  4.85605E-05 0.00341 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.44454E-03 0.00250  1.90622E-04 0.01451  1.06628E-03 0.00629  1.02711E-03 0.00601  2.94233E-03 0.00366  9.10079E-04 0.00664  3.08122E-04 0.01110 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.81528E-01 0.00578  1.24905E-02 1.8E-06  3.16444E-02 0.00010  1.09823E-01 0.00011  3.19400E-01 8.4E-05  1.34833E+00 7.7E-05  8.82713E+00 0.00067 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.69959E-05 0.00066  3.69846E-05 0.00066  3.87112E-05 0.00797 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.64597E-05 0.00064  4.64454E-05 0.00064  4.86143E-05 0.00797 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.49158E-03 0.00717  1.84611E-04 0.04354  1.06402E-03 0.01808  1.00298E-03 0.01922  2.99610E-03 0.01039  9.17116E-04 0.01961  3.26747E-04 0.03288 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  8.07939E-01 0.01757  1.24906E-02 3.9E-06  3.16450E-02 0.00029  1.09816E-01 0.00030  3.19405E-01 0.00022  1.34815E+00 0.00035  8.84523E+00 0.00190 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.48329E-03 0.00705  1.85255E-04 0.04262  1.05661E-03 0.01760  1.00352E-03 0.01854  2.99738E-03 0.01002  9.14788E-04 0.01926  3.25732E-04 0.03185 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  8.06330E-01 0.01697  1.24906E-02 3.9E-06  3.16493E-02 0.00027  1.09809E-01 0.00029  3.19414E-01 0.00021  1.34833E+00 0.00027  8.84294E+00 0.00186 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.75597E+02 0.00725 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.70263E-05 0.00018 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.64978E-05 0.00012 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.46859E-03 0.00145 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.74706E+02 0.00146 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  6.87320E-07 0.00013 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.31249E-06 0.00014  3.31251E-06 0.00014  3.30976E-06 0.00172 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  4.98102E-05 0.00016  4.98094E-05 0.00016  4.99418E-05 0.00211 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.42023E-01 8.4E-05  7.40913E-01 8.5E-05  9.54034E-01 0.00268 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.05241E+01 0.00411 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.06537E+01 8.8E-05  4.44914E+01 0.00012 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  7.08706E+05 0.00099  2.88550E+06 0.00046  6.19511E+06 0.00027  7.46229E+06 0.00032  7.13032E+06 0.00028  7.47113E+06 0.00018  5.14045E+06 0.00023  4.41750E+06 0.00023  3.37931E+06 0.00031  2.75894E+06 0.00032  2.36720E+06 0.00034  2.17118E+06 0.00026  1.98835E+06 0.00026  1.88856E+06 0.00029  1.83411E+06 0.00023  1.59948E+06 0.00033  1.56969E+06 0.00029  1.56651E+06 0.00034  1.54752E+06 0.00027  3.02556E+06 0.00029  2.91800E+06 0.00024  2.14013E+06 0.00029  1.39732E+06 0.00033  1.63739E+06 0.00036  1.57134E+06 0.00030  1.41221E+06 0.00039  2.40397E+06 0.00029  5.42884E+05 0.00051  6.82030E+05 0.00064  6.18597E+05 0.00048  3.60642E+05 0.00079  6.27034E+05 0.00045  4.27177E+05 0.00057  3.65461E+05 0.00059  6.98235E+04 0.00120  6.90906E+04 0.00129  7.02328E+04 0.00156  7.18346E+04 0.00115  7.15541E+04 0.00117  7.07709E+04 0.00116  7.36178E+04 0.00089  6.93215E+04 0.00115  1.31197E+05 0.00090  2.09772E+05 0.00075  2.67770E+05 0.00056  7.08842E+05 0.00043  7.55821E+05 0.00050  8.53714E+05 0.00039  6.02997E+05 0.00045  4.50028E+05 0.00051  3.59794E+05 0.00053  4.31762E+05 0.00060  8.28289E+05 0.00045  1.10876E+06 0.00031  2.19722E+06 0.00028  3.27060E+06 0.00027  4.79888E+06 0.00028  2.99741E+06 0.00029  2.12523E+06 0.00025  1.51061E+06 0.00034  1.34473E+06 0.00027  1.31578E+06 0.00033  1.10036E+06 0.00040  7.33729E+05 0.00031  6.77510E+05 0.00038  6.02397E+05 0.00039  5.11831E+05 0.00052  3.94360E+05 0.00039  2.56068E+05 0.00055  8.83988E+04 0.00076 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.25590E+00 0.00015 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.36066E+16 0.00015  4.63316E+15 0.00010 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.22122E-01 3.7E-05  1.24319E+00 5.7E-05 ];
INF_CAPT                  (idx, [1:   4]) = [  4.57792E-03 0.00021  2.02710E-02 6.8E-05 ];
INF_ABS                   (idx, [1:   4]) = [  6.03030E-03 0.00018  5.05894E-02 8.9E-05 ];
INF_FISS                  (idx, [1:   4]) = [  1.45238E-03 0.00018  3.03184E-02 0.00010 ];
INF_NSF                   (idx, [1:   4]) = [  3.71249E-03 0.00018  7.47767E-02 0.00010 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.55614E+00 1.8E-05  2.46638E+00 1.5E-06 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03781E+02 1.5E-06  2.02657E+02 2.4E-07 ];
INF_INVV                  (idx, [1:   4]) = [  6.33887E-08 0.00014  2.51967E-06 5.0E-05 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.16093E-01 3.9E-05  1.19260E+00 5.7E-05 ];
INF_SCATT1                (idx, [1:   4]) = [  2.25625E-01 5.2E-05  3.09050E-01 0.00010 ];
INF_SCATT2                (idx, [1:   4]) = [  8.98397E-02 7.0E-05  7.73644E-02 0.00020 ];
INF_SCATT3                (idx, [1:   4]) = [  6.86725E-03 0.00086  2.41546E-02 0.00079 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.06820E-03 0.00069 -5.39776E-03 0.00289 ];
INF_SCATT5                (idx, [1:   4]) = [  2.25216E-05 0.19336  5.71326E-03 0.00224 ];
INF_SCATT6                (idx, [1:   4]) = [  4.50803E-03 0.00118 -1.26117E-02 0.00088 ];
INF_SCATT7                (idx, [1:   4]) = [  6.28384E-04 0.00887  4.33099E-04 0.02645 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.16119E-01 3.9E-05  1.19260E+00 5.7E-05 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.25625E-01 5.2E-05  3.09050E-01 0.00010 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.98398E-02 7.0E-05  7.73644E-02 0.00020 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.86725E-03 0.00086  2.41546E-02 0.00079 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.06823E-03 0.00069 -5.39776E-03 0.00289 ];
INF_SCATTP5               (idx, [1:   4]) = [  2.25154E-05 0.19332  5.71326E-03 0.00224 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.50806E-03 0.00118 -1.26117E-02 0.00088 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.28406E-04 0.00889  4.33099E-04 0.02645 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27264E-01 6.7E-05  8.34271E-01 6.9E-05 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46672E+00 6.7E-05  3.99550E-01 6.9E-05 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.00384E-03 0.00018  5.05894E-02 8.9E-05 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36232E-02 5.6E-05  5.16710E-02 0.00016 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.98498E-01 3.7E-05  1.75944E-02 0.00014  1.07694E-03 0.00083  1.19152E+00 5.8E-05 ];
INF_S1                    (idx, [1:   8]) = [  2.20462E-01 5.1E-05  5.16306E-03 0.00030  4.15897E-04 0.00218  3.08635E-01 0.00010 ];
INF_S2                    (idx, [1:   8]) = [  9.13289E-02 7.0E-05 -1.48915E-03 0.00091  2.33362E-04 0.00278  7.71310E-02 0.00020 ];
INF_S3                    (idx, [1:   8]) = [  8.67234E-03 0.00068 -1.80509E-03 0.00060  8.49989E-05 0.00525  2.40696E-02 0.00079 ];
INF_S4                    (idx, [1:   8]) = [ -8.45300E-03 0.00076 -6.15200E-04 0.00114  2.86012E-06 0.14097 -5.40062E-03 0.00287 ];
INF_S5                    (idx, [1:   8]) = [  1.56188E-05 0.28019  6.90287E-06 0.10170 -3.14404E-05 0.00995  5.74470E-03 0.00223 ];
INF_S6                    (idx, [1:   8]) = [  4.64747E-03 0.00112 -1.39435E-04 0.00558 -4.12025E-05 0.01022 -1.25705E-02 0.00087 ];
INF_S7                    (idx, [1:   8]) = [  7.93209E-04 0.00687 -1.64825E-04 0.00400 -3.80540E-05 0.00908  4.71153E-04 0.02404 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.98525E-01 3.7E-05  1.75944E-02 0.00014  1.07694E-03 0.00083  1.19152E+00 5.8E-05 ];
INF_SP1                   (idx, [1:   8]) = [  2.20462E-01 5.1E-05  5.16306E-03 0.00030  4.15897E-04 0.00218  3.08635E-01 0.00010 ];
INF_SP2                   (idx, [1:   8]) = [  9.13289E-02 7.0E-05 -1.48915E-03 0.00091  2.33362E-04 0.00278  7.71310E-02 0.00020 ];
INF_SP3                   (idx, [1:   8]) = [  8.67234E-03 0.00068 -1.80509E-03 0.00060  8.49989E-05 0.00525  2.40696E-02 0.00079 ];
INF_SP4                   (idx, [1:   8]) = [ -8.45303E-03 0.00076 -6.15200E-04 0.00114  2.86012E-06 0.14097 -5.40062E-03 0.00287 ];
INF_SP5                   (idx, [1:   8]) = [  1.56125E-05 0.28006  6.90287E-06 0.10170 -3.14404E-05 0.00995  5.74470E-03 0.00223 ];
INF_SP6                   (idx, [1:   8]) = [  4.64749E-03 0.00112 -1.39435E-04 0.00558 -4.12025E-05 0.01022 -1.25705E-02 0.00087 ];
INF_SP7                   (idx, [1:   8]) = [  7.93232E-04 0.00688 -1.64825E-04 0.00400 -3.80540E-05 0.00908  4.71153E-04 0.02404 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37473E-01 0.00020  7.11050E-01 0.00118 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37804E-01 0.00033  7.21810E-01 0.00163 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37714E-01 0.00028  7.22144E-01 0.00134 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.36905E-01 0.00030  6.90186E-01 0.00116 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40367E+00 0.00020  4.68806E-01 0.00118 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40172E+00 0.00033  4.61831E-01 0.00163 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40225E+00 0.00028  4.61608E-01 0.00134 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40704E+00 0.00030  4.82977E-01 0.00116 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.48686E-03 0.00238  1.94766E-04 0.01463  1.07093E-03 0.00605  1.02428E-03 0.00586  2.97234E-03 0.00351  9.13204E-04 0.00644  3.11338E-04 0.01109 ];
LAMBDA                    (idx, [1:  14]) = [  7.82794E-01 0.00577  1.24905E-02 1.7E-06  3.16406E-02 9.4E-05  1.09816E-01 0.00010  3.19382E-01 7.9E-05  1.34829E+00 7.2E-05  8.82426E+00 0.00063 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 20:10:28 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 50000530 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  0.00000E+00 0.00000 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  0.00000E+00 0.00000 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.36471E+03 ;
RUNNING_TIME              (idx, 1)        =  5.47812E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  3.28833E-02  6.66649E-05 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  4.89289E+01  7.16513E+00  4.94285E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.17783E-01  1.67333E-02 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  5.47642E+01  8.38667E+01 ];
CPU_USAGE                 (idx, 1)        = 24.91197 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  7.47643E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.00027E+15 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.24674E+02 ;
TOT_SF_RATE               (idx, 1)        =  8.84849E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.37027E+14 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  9.56280E+00 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  8.63244E+14 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.15110E+02 ;
INHALATION_TOXICITY       (idx, 1)        =  5.44909E+05 ;
INGESTION_TOXICITY        (idx, 1)        =  4.30400E+05 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.12721E+05 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.67453E+04 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  4.32189E+05 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  3.73655E+05 ;
SR90_ACTIVITY             (idx, 1)        =  3.52268E+10 ;
TE132_ACTIVITY            (idx, 1)        =  7.01125E+12 ;
I131_ACTIVITY             (idx, 1)        =  4.70098E+12 ;
I132_ACTIVITY             (idx, 1)        =  7.07745E+12 ;
CS134_ACTIVITY            (idx, 1)        =  2.98328E+09 ;
CS137_ACTIVITY            (idx, 1)        =  3.74863E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.61557E+14 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.79809E+12 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  3.25773E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.23540E+15 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 4 ;
BURNUP                     (idx, [1:  2])  = [  2.40000E+00  2.40002E+00 ];
BURN_DAYS                 (idx, 1)        =  6.00000E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 0 0.00000E+00 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 0 0.00000E+00 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 0.00000E+00 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_ABSRATE               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_SRCRATE               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29829E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29829E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_F                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_P                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_LF                 (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
FISSE                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
IMP_KEFF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
COL_KEFF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ABS_KEFF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ABS_KINF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
IMP_ALF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
IMP_EALF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
IMP_AFGE                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CAPT                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_ABS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_FISS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_NSF                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_NUBAR                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_KAPPA                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_INVV                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP1               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP2               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP3               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP4               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP5               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP6               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP7               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_REMXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP1                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP2                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP3                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP4                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP5                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP6                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP7                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
LAMBDA                    (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 20:17:42 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  1.01511E+00  1.02368E+00  1.02425E+00  1.02371E+00  9.76973E-01  1.02957E+00  9.78517E-01  1.02697E+00  1.02358E+00  1.02425E+00  9.79429E-01  1.02070E+00  9.78560E-01  9.77100E-01  9.79756E-01  1.02249E+00  9.79283E-01  9.68195E-01  9.78258E-01  1.01893E+00  9.69583E-01  1.02623E+00  9.76347E-01  1.02417E+00  9.79028E-01  9.78451E-01  1.02439E+00  9.72490E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 1.7E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.57905E-02 0.00028  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84209E-01 4.5E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.89509E-01 2.5E-05  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.90506E-01 2.5E-05  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.95053E+00 7.8E-05  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.10033E+01 8.5E-05  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.10033E+01 8.5E-05  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.83782E+01 0.00011  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.58869E-01 0.00030  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 50000311 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  1.00001E+05 0.00020 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  1.00001E+05 0.00020 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.56665E+03 ;
RUNNING_TIME              (idx, 1)        =  6.20089E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  3.67333E-02  3.85000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  5.61522E+01  7.22327E+00  4.94285E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.18350E-01  5.66667E-04 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  6.20087E+01  7.90728E+01 ];
CPU_USAGE                 (idx, 1)        = 25.26485 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  2.79509E+01 0.00010 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  7.61820E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  6.12198E+13 ;
TOT_DECAY_HEAT            (idx, 1)        =  7.27245E+00 ;
TOT_SF_RATE               (idx, 1)        =  8.84935E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  3.79446E+12 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  2.49181E-01 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  5.74254E+13 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  7.02327E+00 ;
INHALATION_TOXICITY       (idx, 1)        =  3.23874E+05 ;
INGESTION_TOXICITY        (idx, 1)        =  1.27236E+05 ;
ACTINIDE_INH_TOX          (idx, 1)        =  4.81922E+04 ;
ACTINIDE_ING_TOX          (idx, 1)        =  3.11918E+03 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  2.75682E+05 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  1.24117E+05 ;
SR90_ACTIVITY             (idx, 1)        =  3.52055E+10 ;
TE132_ACTIVITY            (idx, 1)        =  8.06222E+11 ;
I131_ACTIVITY             (idx, 1)        =  2.02180E+12 ;
I132_ACTIVITY             (idx, 1)        =  8.31024E+11 ;
CS134_ACTIVITY            (idx, 1)        =  2.95788E+09 ;
CS137_ACTIVITY            (idx, 1)        =  3.74651E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  4.99637E+13 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  3.44172E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  9.55630E+13 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  3.07854E+09 0.00014  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 5 ;
BURNUP                     (idx, [1:  2])  = [  2.40000E+00  2.40002E+00 ];
BURN_DAYS                 (idx, 1)        =  7.00000E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.58672E-01 0.00034 ];
U235_FISS                 (idx, [1:   4]) = [  1.42942E+14 0.00017  8.92335E-01 6.6E-05 ];
U238_FISS                 (idx, [1:   4]) = [  5.64458E+12 0.00110  3.52368E-02 0.00107 ];
PU239_FISS                (idx, [1:   4]) = [  1.15349E+13 0.00071  7.20081E-02 0.00069 ];
PU240_FISS                (idx, [1:   4]) = [  1.42871E+09 0.06288  8.91643E-06 0.06288 ];
PU241_FISS                (idx, [1:   4]) = [  4.94527E+10 0.01116  3.08727E-04 0.01117 ];
U235_CAPT                 (idx, [1:   4]) = [  2.89297E+13 0.00044  1.95450E-01 0.00040 ];
U238_CAPT                 (idx, [1:   4]) = [  6.69173E+13 0.00032  4.52094E-01 0.00021 ];
PU239_CAPT                (idx, [1:   4]) = [  6.39842E+12 0.00095  4.32282E-02 0.00094 ];
PU240_CAPT                (idx, [1:   4]) = [  7.51279E+11 0.00297  5.07576E-03 0.00298 ];
PU241_CAPT                (idx, [1:   4]) = [  1.86975E+10 0.01871  1.26307E-04 0.01870 ];
SM149_CAPT                (idx, [1:   4]) = [  2.98984E+12 0.00150  2.01995E-02 0.00149 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50000311 5.00000E+07 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.69005E+04 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50000311 5.00569E+07 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 24012648 2.40399E+07 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 25987663 2.60170E+07 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50000311 5.00569E+07 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.04146E-06 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  5.20612E+03 2.9E-09  5.20612E+03 2.9E-09  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  4.00000E-02 8.1E-09  4.00000E-02 8.1E-09  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  3.97462E+14 2.5E-06  3.97462E+14 2.5E-06  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  1.60192E+14 3.4E-07  1.60192E+14 3.4E-07  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.47980E+14 0.00011  1.09321E+14 0.00014  3.86592E+13 0.00014 ];
TOT_ABSRATE               (idx, [1:   6]) = [  3.08173E+14 5.4E-05  2.69514E+14 5.5E-05  3.86592E+13 0.00014 ];
TOT_SRCRATE               (idx, [1:   6]) = [  3.07854E+14 0.00014  3.07854E+14 0.00014  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  1.78552E+16 0.00012  2.94464E+15 0.00013  1.49105E+16 0.00012 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  3.08173E+14 5.4E-05 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.26371E+16 0.00010 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29829E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29829E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.76693E+00 0.00011 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.63859E-01 6.5E-05 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.41245E-01 8.4E-05 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14107E+00 7.8E-05 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.29103E+00 0.00014 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.29103E+00 0.00014 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.48115E+00 2.7E-06 ];
FISSE                     (idx, [1:   2]) = [  2.02844E+02 3.4E-07 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.29100E+00 0.00014  1.28279E+00 0.00014  8.24115E-03 0.00247 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.29121E+00 5.4E-05 ];
COL_KEFF                  (idx, [1:   2]) = [  1.29108E+00 0.00014 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.29121E+00 5.4E-05 ];
ABS_KINF                  (idx, [1:   2]) = [  1.29121E+00 5.4E-05 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.82980E+01 4.4E-05 ];
IMP_ALF                   (idx, [1:   2]) = [  1.82978E+01 1.7E-05 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.26143E-07 0.00080 ];
IMP_EALF                  (idx, [1:   2]) = [  2.26163E-07 0.00030 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.18243E-01 0.00112 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.18293E-01 0.00042 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.04228E-03 0.00177  1.49471E-04 0.01021  8.33731E-04 0.00430  8.02392E-04 0.00429  2.29838E-03 0.00255  7.17084E-04 0.00472  2.41223E-04 0.00832 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.81903E-01 0.00424  1.24908E-02 1.9E-05  3.16375E-02 7.4E-05  1.09803E-01 7.2E-05  3.19265E-01 5.7E-05  1.34827E+00 5.8E-05  8.81448E+00 0.00046 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.41471E-03 0.00238  1.87866E-04 0.01459  1.05734E-03 0.00585  1.02704E-03 0.00599  2.92582E-03 0.00359  9.14594E-04 0.00663  3.02050E-04 0.01125 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.75610E-01 0.00572  1.24908E-02 2.0E-05  3.16350E-02 0.00010  1.09811E-01 0.00010  3.19261E-01 7.9E-05  1.34828E+00 7.4E-05  8.81213E+00 0.00063 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.70327E-05 0.00029  3.70227E-05 0.00029  3.85786E-05 0.00297 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.78087E-05 0.00024  4.77959E-05 0.00025  4.98044E-05 0.00296 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.38676E-03 0.00250  1.88367E-04 0.01403  1.05603E-03 0.00627  1.01759E-03 0.00594  2.90863E-03 0.00366  9.13097E-04 0.00672  3.03051E-04 0.01168 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.79065E-01 0.00605  1.24908E-02 2.2E-05  3.16375E-02 0.00010  1.09807E-01 0.00010  3.19274E-01 8.0E-05  1.34831E+00 8.2E-05  8.81196E+00 0.00065 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.70266E-05 0.00061  3.70180E-05 0.00061  3.83815E-05 0.00728 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.78008E-05 0.00059  4.77898E-05 0.00060  4.95506E-05 0.00728 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.42416E-03 0.00764  1.91601E-04 0.03984  1.07077E-03 0.01741  1.03247E-03 0.01737  2.91103E-03 0.01061  9.11346E-04 0.01864  3.06941E-04 0.03265 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  7.79975E-01 0.01678  1.24904E-02 5.5E-06  3.16366E-02 0.00032  1.09812E-01 0.00031  3.19350E-01 0.00024  1.34792E+00 0.00028  8.79595E+00 0.00159 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.41497E-03 0.00748  1.91631E-04 0.03969  1.06554E-03 0.01655  1.03167E-03 0.01685  2.90230E-03 0.01038  9.14896E-04 0.01843  3.08939E-04 0.03196 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.83470E-01 0.01652  1.24904E-02 5.5E-06  3.16363E-02 0.00031  1.09820E-01 0.00031  3.19345E-01 0.00023  1.34798E+00 0.00026  8.79385E+00 0.00153 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.73574E+02 0.00766 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.70582E-05 0.00018 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.78417E-05 0.00011 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.37633E-03 0.00140 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.72067E+02 0.00143 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  6.98411E-07 0.00013 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.31134E-06 0.00014  3.31140E-06 0.00014  3.30217E-06 0.00172 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.09793E-05 0.00016  5.09799E-05 0.00016  5.08930E-05 0.00203 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.41646E-01 8.4E-05  7.40438E-01 8.6E-05  9.81577E-01 0.00274 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.06038E+01 0.00412 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.10033E+01 8.5E-05  4.50804E+01 0.00011 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  7.10600E+05 0.00125  2.88845E+06 0.00048  6.19591E+06 0.00035  7.46299E+06 0.00027  7.13024E+06 0.00022  7.47341E+06 0.00022  5.13839E+06 0.00025  4.41633E+06 0.00021  3.37837E+06 0.00024  2.75968E+06 0.00029  2.36645E+06 0.00034  2.16979E+06 0.00029  1.98646E+06 0.00037  1.88770E+06 0.00029  1.83451E+06 0.00034  1.59916E+06 0.00044  1.56907E+06 0.00034  1.56564E+06 0.00034  1.54690E+06 0.00033  3.02831E+06 0.00025  2.91700E+06 0.00025  2.13999E+06 0.00036  1.39737E+06 0.00033  1.63730E+06 0.00038  1.57141E+06 0.00032  1.41211E+06 0.00029  2.40436E+06 0.00028  5.42902E+05 0.00036  6.81554E+05 0.00045  6.19336E+05 0.00048  3.60859E+05 0.00052  6.26806E+05 0.00061  4.26790E+05 0.00051  3.64849E+05 0.00071  6.98170E+04 0.00135  6.89346E+04 0.00122  7.00232E+04 0.00107  7.16996E+04 0.00120  7.13609E+04 0.00114  7.08185E+04 0.00133  7.35242E+04 0.00135  6.93438E+04 0.00115  1.30895E+05 0.00067  2.09414E+05 0.00071  2.67369E+05 0.00051  7.08624E+05 0.00056  7.55840E+05 0.00045  8.53462E+05 0.00031  6.03785E+05 0.00050  4.51039E+05 0.00058  3.60924E+05 0.00066  4.33904E+05 0.00068  8.34354E+05 0.00043  1.12046E+06 0.00035  2.23046E+06 0.00026  3.33108E+06 0.00024  4.90830E+06 0.00021  3.07432E+06 0.00028  2.18204E+06 0.00031  1.55182E+06 0.00032  1.38046E+06 0.00031  1.35118E+06 0.00029  1.13001E+06 0.00026  7.53280E+05 0.00033  6.95430E+05 0.00032  6.18469E+05 0.00031  5.25927E+05 0.00042  4.04808E+05 0.00036  2.62964E+05 0.00043  9.06843E+04 0.00098 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.29108E+00 0.00012 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.32520E+16 0.00013  4.60319E+15 0.00012 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.22106E-01 2.5E-05  1.24222E+00 6.7E-05 ];
INF_CAPT                  (idx, [1:   4]) = [  4.58786E-03 0.00022  1.89396E-02 8.1E-05 ];
INF_ABS                   (idx, [1:   4]) = [  6.03734E-03 0.00019  4.95674E-02 0.00011 ];
INF_FISS                  (idx, [1:   4]) = [  1.44948E-03 0.00019  3.06277E-02 0.00013 ];
INF_NSF                   (idx, [1:   4]) = [  3.70754E-03 0.00020  7.56721E-02 0.00013 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.55784E+00 1.9E-05  2.47071E+00 1.6E-06 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03803E+02 1.7E-06  2.02713E+02 2.5E-07 ];
INF_INVV                  (idx, [1:   4]) = [  6.33677E-08 0.00014  2.52663E-06 4.1E-05 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.16068E-01 2.5E-05  1.19264E+00 7.1E-05 ];
INF_SCATT1                (idx, [1:   4]) = [  2.25637E-01 5.7E-05  3.08624E-01 0.00012 ];
INF_SCATT2                (idx, [1:   4]) = [  8.98293E-02 9.6E-05  7.71417E-02 0.00023 ];
INF_SCATT3                (idx, [1:   4]) = [  6.86418E-03 0.00134  2.41015E-02 0.00048 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.08848E-03 0.00063 -5.40104E-03 0.00209 ];
INF_SCATT5                (idx, [1:   4]) = [  1.95311E-05 0.20103  5.74458E-03 0.00194 ];
INF_SCATT6                (idx, [1:   4]) = [  4.51042E-03 0.00123 -1.26243E-02 0.00091 ];
INF_SCATT7                (idx, [1:   4]) = [  6.35856E-04 0.00696  4.48180E-04 0.02791 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.16095E-01 2.5E-05  1.19264E+00 7.1E-05 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.25637E-01 5.7E-05  3.08624E-01 0.00012 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.98293E-02 9.6E-05  7.71417E-02 0.00023 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.86416E-03 0.00134  2.41015E-02 0.00048 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.08850E-03 0.00063 -5.40104E-03 0.00209 ];
INF_SCATTP5               (idx, [1:   4]) = [  1.95691E-05 0.20078  5.74458E-03 0.00194 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.51036E-03 0.00123 -1.26243E-02 0.00091 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.35898E-04 0.00695  4.48180E-04 0.02791 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27212E-01 6.5E-05  8.34664E-01 7.0E-05 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46706E+00 6.5E-05  3.99362E-01 7.0E-05 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.01091E-03 0.00019  4.95674E-02 0.00011 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36244E-02 8.6E-05  5.06305E-02 0.00011 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.98481E-01 2.4E-05  1.75869E-02 1.0E-04  1.05723E-03 0.00125  1.19159E+00 7.1E-05 ];
INF_S1                    (idx, [1:   8]) = [  2.20477E-01 5.7E-05  5.16025E-03 0.00020  4.08756E-04 0.00216  3.08215E-01 0.00012 ];
INF_S2                    (idx, [1:   8]) = [  9.13158E-02 9.5E-05 -1.48660E-03 0.00065  2.29732E-04 0.00294  7.69120E-02 0.00024 ];
INF_S3                    (idx, [1:   8]) = [  8.66608E-03 0.00102 -1.80190E-03 0.00062  8.34210E-05 0.00563  2.40181E-02 0.00048 ];
INF_S4                    (idx, [1:   8]) = [ -8.47535E-03 0.00065 -6.13133E-04 0.00123  2.25489E-06 0.17205 -5.40329E-03 0.00208 ];
INF_S5                    (idx, [1:   8]) = [  1.20265E-05 0.33231  7.50457E-06 0.09098 -3.11256E-05 0.01079  5.77571E-03 0.00193 ];
INF_S6                    (idx, [1:   8]) = [  4.65181E-03 0.00121 -1.41389E-04 0.00412 -4.03096E-05 0.00955 -1.25840E-02 0.00092 ];
INF_S7                    (idx, [1:   8]) = [  8.01808E-04 0.00523 -1.65952E-04 0.00471 -3.76488E-05 0.00931  4.85829E-04 0.02562 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.98508E-01 2.4E-05  1.75869E-02 1.0E-04  1.05723E-03 0.00125  1.19159E+00 7.1E-05 ];
INF_SP1                   (idx, [1:   8]) = [  2.20477E-01 5.7E-05  5.16025E-03 0.00020  4.08756E-04 0.00216  3.08215E-01 0.00012 ];
INF_SP2                   (idx, [1:   8]) = [  9.13159E-02 9.5E-05 -1.48660E-03 0.00065  2.29732E-04 0.00294  7.69120E-02 0.00024 ];
INF_SP3                   (idx, [1:   8]) = [  8.66605E-03 0.00102 -1.80190E-03 0.00062  8.34210E-05 0.00563  2.40181E-02 0.00048 ];
INF_SP4                   (idx, [1:   8]) = [ -8.47537E-03 0.00065 -6.13133E-04 0.00123  2.25489E-06 0.17205 -5.40329E-03 0.00208 ];
INF_SP5                   (idx, [1:   8]) = [  1.20645E-05 0.33140  7.50457E-06 0.09098 -3.11256E-05 0.01079  5.77571E-03 0.00193 ];
INF_SP6                   (idx, [1:   8]) = [  4.65175E-03 0.00121 -1.41389E-04 0.00412 -4.03096E-05 0.00955 -1.25840E-02 0.00092 ];
INF_SP7                   (idx, [1:   8]) = [  8.01850E-04 0.00522 -1.65952E-04 0.00471 -3.76488E-05 0.00931  4.85829E-04 0.02562 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37377E-01 0.00016  7.11683E-01 0.00099 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37682E-01 0.00029  7.21967E-01 0.00118 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37649E-01 0.00027  7.23146E-01 0.00136 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.36804E-01 0.00025  6.90922E-01 0.00126 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40424E+00 0.00016  4.68384E-01 0.00099 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40243E+00 0.00029  4.61717E-01 0.00118 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40263E+00 0.00027  4.60970E-01 0.00136 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40764E+00 0.00025  4.82465E-01 0.00126 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.41471E-03 0.00238  1.87866E-04 0.01459  1.05734E-03 0.00585  1.02704E-03 0.00599  2.92582E-03 0.00359  9.14594E-04 0.00663  3.02050E-04 0.01125 ];
LAMBDA                    (idx, [1:  14]) = [  7.75610E-01 0.00572  1.24908E-02 2.0E-05  3.16350E-02 0.00010  1.09811E-01 0.00010  3.19261E-01 7.9E-05  1.34828E+00 7.4E-05  8.81213E+00 0.00063 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-10-l.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Tue Mar 19 19:15:42 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Tue Mar 19 20:29:52 2019' ;

% Run parameters:

POP                       (idx, 1)        = 100000 ;
CYCLES                    (idx, 1)        = 500 ;
SKIP                      (idx, 1)        = 200 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1553037342 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 28 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:  28]) = [  9.71722E-01  1.02871E+00  1.02895E+00  1.03010E+00  1.02316E+00  1.00786E+00  9.75743E-01  1.02537E+00  9.87630E-01  1.01330E+00  9.97589E-01  1.01845E+00  9.79820E-01  9.99885E-01  9.78215E-01  1.02904E+00  9.72476E-01  9.72348E-01  9.78125E-01  1.02182E+00  9.79908E-01  1.02883E+00  9.71812E-01  1.02800E+00  9.71597E-01  9.75424E-01  1.02620E+00  9.77916E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 68])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 9.3E-10  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.57977E-02 0.00028  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84202E-01 4.6E-06  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.90707E-01 2.6E-05  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.91704E-01 2.6E-05  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.94233E+00 7.7E-05  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.05230E+01 9.2E-05  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.05230E+01 9.2E-05  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.80613E+01 0.00013  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.48451E-01 0.00031  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 500 ;
SOURCE_POPULATION         (idx, 1)        = 50000114 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  1.00000E+05 0.00020 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  1.00000E+05 0.00020 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.90528E+03 ;
RUNNING_TIME              (idx, 1)        =  7.41679E+01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.70142E+00  5.70142E+00 ];
PROCESS_TIME              (idx, [1:  2])  = [  4.48833E-02  4.10000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  6.82702E+01  7.28478E+00  4.83327E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.51017E-01  1.05833E-02 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  7.41676E+01  7.90156E+01 ];
CPU_USAGE                 (idx, 1)        = 25.68870 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  2.79481E+01 0.00013 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  7.73927E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 6895.16;
MEMSIZE                   (idx, 1)        = 6593.19;
XS_MEMSIZE                (idx, 1)        = 5901.79;
MAT_MEMSIZE               (idx, 1)        = 36.39;
RES_MEMSIZE               (idx, 1)        = 1.84;
MISC_MEMSIZE              (idx, 1)        = 653.18;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 301.97;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 266905 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1340 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 287 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8194 ;
TOT_TRANSMU_REA           (idx, 1)        = 2674 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.97567E+14 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.21098E+02 ;
TOT_SF_RATE               (idx, 1)        =  9.30393E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.36911E+14 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  9.55344E+00 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  8.60655E+14 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.11543E+02 ;
INHALATION_TOXICITY       (idx, 1)        =  6.28891E+05 ;
INGESTION_TOXICITY        (idx, 1)        =  4.33142E+05 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.43781E+05 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.68255E+04 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  4.85110E+05 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  3.76316E+05 ;
SR90_ACTIVITY             (idx, 1)        =  5.21291E+10 ;
TE132_ACTIVITY            (idx, 1)        =  6.99986E+12 ;
I131_ACTIVITY             (idx, 1)        =  4.54910E+12 ;
I132_ACTIVITY             (idx, 1)        =  7.07634E+12 ;
CS134_ACTIVITY            (idx, 1)        =  7.40804E+09 ;
CS137_ACTIVITY            (idx, 1)        =  5.61752E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.57209E+14 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.75591E+12 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  5.27987E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.23330E+15 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  3.21991E+09 0.00015  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 6 ;
BURNUP                     (idx, [1:  2])  = [  3.60000E+00  3.60002E+00 ];
BURN_DAYS                 (idx, 1)        =  1.00000E+02 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.72975E-01 0.00036 ];
U235_FISS                 (idx, [1:   4]) = [  1.38267E+14 0.00018  8.63972E-01 7.4E-05 ];
U238_FISS                 (idx, [1:   4]) = [  5.90542E+12 0.00103  3.68999E-02 0.00099 ];
PU239_FISS                (idx, [1:   4]) = [  1.56784E+13 0.00064  9.79673E-02 0.00060 ];
PU240_FISS                (idx, [1:   4]) = [  3.35615E+09 0.04349  2.09671E-05 0.04348 ];
PU241_FISS                (idx, [1:   4]) = [  1.57724E+11 0.00628  9.85555E-04 0.00628 ];
U235_CAPT                 (idx, [1:   4]) = [  2.81362E+13 0.00048  1.73337E-01 0.00044 ];
U238_CAPT                 (idx, [1:   4]) = [  6.91861E+13 0.00035  4.26226E-01 0.00023 ];
PU239_CAPT                (idx, [1:   4]) = [  8.71132E+12 0.00083  5.36673E-02 0.00082 ];
PU240_CAPT                (idx, [1:   4]) = [  1.61367E+12 0.00197  9.94103E-03 0.00194 ];
PU241_CAPT                (idx, [1:   4]) = [  5.70051E+10 0.01065  3.51208E-04 0.01067 ];
XE135_CAPT                (idx, [1:   4]) = [  8.40200E+12 0.00087  5.17617E-02 0.00085 ];
SM149_CAPT                (idx, [1:   4]) = [  1.85772E+12 0.00187  1.14449E-02 0.00189 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50000114 5.00000E+07 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.71202E+04 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50000114 5.00571E+07 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 25177006 2.52059E+07 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 24823108 2.48512E+07 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50000114 5.00571E+07 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.62260E-06 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  5.20612E+03 2.9E-09  5.20612E+03 2.9E-09  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  4.00000E-02 8.1E-09  4.00000E-02 8.1E-09  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  3.99097E+14 2.6E-06  3.99097E+14 2.6E-06  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  1.60066E+14 3.9E-07  1.60066E+14 3.9E-07  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.62299E+14 0.00011  1.22784E+14 0.00013  3.95150E+13 0.00013 ];
TOT_ABSRATE               (idx, [1:   6]) = [  3.22365E+14 5.4E-05  2.82850E+14 5.7E-05  3.95150E+13 0.00013 ];
TOT_SRCRATE               (idx, [1:   6]) = [  3.21991E+14 0.00015  3.21991E+14 0.00015  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  1.85448E+16 0.00012  3.05808E+15 0.00013  1.54867E+16 0.00012 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  3.22365E+14 5.4E-05 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.30626E+16 0.00010 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29668E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29668E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.68857E+00 0.00012 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.67474E-01 6.6E-05 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.39333E-01 8.5E-05 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14429E+00 7.8E-05 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.23923E+00 0.00014 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.23923E+00 0.00014 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.49333E+00 2.9E-06 ];
FISSE                     (idx, [1:   2]) = [  2.03004E+02 3.9E-07 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.23921E+00 0.00014  1.23145E+00 0.00014  7.77879E-03 0.00249 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.23945E+00 5.4E-05 ];
COL_KEFF                  (idx, [1:   2]) = [  1.23948E+00 0.00015 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.23945E+00 5.4E-05 ];
ABS_KINF                  (idx, [1:   2]) = [  1.23945E+00 5.4E-05 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.82433E+01 4.3E-05 ];
IMP_ALF                   (idx, [1:   2]) = [  1.82432E+01 1.7E-05 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.38850E-07 0.00079 ];
IMP_EALF                  (idx, [1:   2]) = [  2.38847E-07 0.00031 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.23832E-01 0.00107 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.23803E-01 0.00038 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.16795E-03 0.00180  1.57529E-04 0.00989  8.52861E-04 0.00455  8.21627E-04 0.00443  2.35717E-03 0.00266  7.31437E-04 0.00464  2.47328E-04 0.00770 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.81890E-01 0.00402  1.24906E-02 1.4E-05  3.15959E-02 8.1E-05  1.09801E-01 7.4E-05  3.19386E-01 5.9E-05  1.34732E+00 8.6E-05  8.82544E+00 0.00049 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.31032E-03 0.00268  1.93585E-04 0.01384  1.04037E-03 0.00643  1.00190E-03 0.00623  2.87734E-03 0.00371  8.88651E-04 0.00658  3.08465E-04 0.01131 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.89708E-01 0.00582  1.24905E-02 1.1E-05  3.15986E-02 0.00011  1.09798E-01 0.00011  3.19400E-01 8.1E-05  1.34730E+00 0.00011  8.82731E+00 0.00074 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.73873E-05 0.00031  3.73753E-05 0.00031  3.92825E-05 0.00331 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.63301E-05 0.00027  4.63152E-05 0.00027  4.86792E-05 0.00332 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.27756E-03 0.00249  1.92037E-04 0.01468  1.03907E-03 0.00625  9.91135E-04 0.00614  2.87150E-03 0.00361  8.85670E-04 0.00698  2.98154E-04 0.01093 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.78752E-01 0.00566  1.24908E-02 2.8E-05  3.15934E-02 0.00012  1.09807E-01 0.00011  3.19418E-01 8.9E-05  1.34738E+00 0.00012  8.83240E+00 0.00074 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.74106E-05 0.00066  3.73965E-05 0.00066  3.95554E-05 0.00794 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.63589E-05 0.00064  4.63414E-05 0.00065  4.90163E-05 0.00794 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.29329E-03 0.00767  1.97187E-04 0.04128  1.07325E-03 0.01802  9.89047E-04 0.01931  2.85635E-03 0.01100  8.81133E-04 0.01972  2.96323E-04 0.03549 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  7.72555E-01 0.01804  1.24923E-02 0.00016  3.15881E-02 0.00036  1.09782E-01 0.00033  3.19399E-01 0.00025  1.34794E+00 0.00027  8.87248E+00 0.00215 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.29010E-03 0.00741  2.00288E-04 0.03995  1.07308E-03 0.01779  9.81963E-04 0.01862  2.85256E-03 0.01067  8.80690E-04 0.01918  3.01521E-04 0.03412 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.79908E-01 0.01765  1.24922E-02 0.00015  3.15874E-02 0.00035  1.09778E-01 0.00032  3.19420E-01 0.00025  1.34794E+00 0.00027  8.87052E+00 0.00208 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.68294E+02 0.00765 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.74157E-05 0.00018 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.63653E-05 0.00012 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.28661E-03 0.00140 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.68021E+02 0.00139 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  6.83967E-07 0.00014 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.30170E-06 0.00014  3.30178E-06 0.00014  3.29060E-06 0.00174 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  4.96123E-05 0.00017  4.96118E-05 0.00017  4.96763E-05 0.00211 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.39735E-01 8.5E-05  7.38702E-01 8.6E-05  9.40033E-01 0.00274 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.06204E+01 0.00420 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.05230E+01 9.2E-05  4.44029E+01 0.00012 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  7.12418E+05 0.00104  2.89980E+06 0.00043  6.20113E+06 0.00028  7.46752E+06 0.00032  7.13351E+06 0.00027  7.47242E+06 0.00027  5.14019E+06 0.00022  4.41853E+06 0.00027  3.37877E+06 0.00022  2.75868E+06 0.00026  2.36557E+06 0.00034  2.17134E+06 0.00029  1.98671E+06 0.00031  1.88791E+06 0.00027  1.83502E+06 0.00035  1.59961E+06 0.00038  1.56869E+06 0.00034  1.56612E+06 0.00026  1.54805E+06 0.00037  3.02756E+06 0.00031  2.92070E+06 0.00021  2.14183E+06 0.00028  1.39836E+06 0.00037  1.63874E+06 0.00031  1.57274E+06 0.00037  1.41176E+06 0.00034  2.40229E+06 0.00034  5.42909E+05 0.00052  6.81743E+05 0.00048  6.18638E+05 0.00032  3.61046E+05 0.00057  6.26986E+05 0.00063  4.26684E+05 0.00064  3.64210E+05 0.00066  6.95577E+04 0.00083  6.83248E+04 0.00120  6.86281E+04 0.00104  6.97287E+04 0.00099  6.96283E+04 0.00128  6.94890E+04 0.00118  7.28208E+04 0.00111  6.87793E+04 0.00138  1.30402E+05 0.00111  2.08867E+05 0.00064  2.66710E+05 0.00066  7.06470E+05 0.00039  7.53393E+05 0.00043  8.47913E+05 0.00036  5.96145E+05 0.00050  4.42734E+05 0.00049  3.52709E+05 0.00052  4.22625E+05 0.00038  8.12737E+05 0.00039  1.09135E+06 0.00038  2.17093E+06 0.00028  3.23841E+06 0.00028  4.76032E+06 0.00019  2.97684E+06 0.00025  2.11139E+06 0.00024  1.50282E+06 0.00022  1.33702E+06 0.00025  1.30819E+06 0.00029  1.09490E+06 0.00026  7.30544E+05 0.00035  6.74120E+05 0.00030  5.99654E+05 0.00034  5.10194E+05 0.00031  3.92902E+05 0.00043  2.54968E+05 0.00051  8.80917E+04 0.00071 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.23948E+00 0.00013 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.38646E+16 0.00016  4.68029E+15 0.00010 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.22106E-01 3.0E-05  1.24434E+00 6.0E-05 ];
INF_CAPT                  (idx, [1:   4]) = [  4.66450E-03 0.00018  2.08596E-02 7.0E-05 ];
INF_ABS                   (idx, [1:   4]) = [  6.08018E-03 0.00015  5.08663E-02 9.2E-05 ];
INF_FISS                  (idx, [1:   4]) = [  1.41568E-03 0.00015  3.00068E-02 0.00011 ];
INF_NSF                   (idx, [1:   4]) = [  3.63071E-03 0.00015  7.45176E-02 0.00011 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.56464E+00 1.7E-05  2.48336E+00 1.7E-06 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03891E+02 1.8E-06  2.02880E+02 2.7E-07 ];
INF_INVV                  (idx, [1:   4]) = [  6.32363E-08 0.00011  2.52278E-06 3.5E-05 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.16026E-01 3.0E-05  1.19348E+00 6.2E-05 ];
INF_SCATT1                (idx, [1:   4]) = [  2.25598E-01 5.6E-05  3.09149E-01 0.00012 ];
INF_SCATT2                (idx, [1:   4]) = [  8.98270E-02 8.0E-05  7.73702E-02 0.00020 ];
INF_SCATT3                (idx, [1:   4]) = [  6.86635E-03 0.00085  2.41828E-02 0.00049 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.07734E-03 0.00056 -5.39545E-03 0.00274 ];
INF_SCATT5                (idx, [1:   4]) = [  1.30476E-05 0.34831  5.73494E-03 0.00224 ];
INF_SCATT6                (idx, [1:   4]) = [  4.50579E-03 0.00105 -1.26174E-02 0.00091 ];
INF_SCATT7                (idx, [1:   4]) = [  6.27664E-04 0.00684  4.35884E-04 0.02461 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.16052E-01 3.0E-05  1.19348E+00 6.2E-05 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.25598E-01 5.6E-05  3.09149E-01 0.00012 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.98271E-02 8.0E-05  7.73702E-02 0.00020 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.86637E-03 0.00085  2.41828E-02 0.00049 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.07736E-03 0.00056 -5.39545E-03 0.00274 ];
INF_SCATTP5               (idx, [1:   4]) = [  1.30138E-05 0.34998  5.73494E-03 0.00224 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.50577E-03 0.00106 -1.26174E-02 0.00091 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.27624E-04 0.00685  4.35884E-04 0.02461 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27157E-01 6.5E-05  8.36007E-01 5.4E-05 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46742E+00 6.5E-05  3.98721E-01 5.4E-05 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.05365E-03 0.00015  5.08663E-02 9.2E-05 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36152E-02 7.7E-05  5.19442E-02 0.00013 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.98491E-01 2.9E-05  1.75349E-02 9.2E-05  1.08011E-03 0.00127  1.19240E+00 6.2E-05 ];
INF_S1                    (idx, [1:   8]) = [  2.20455E-01 5.3E-05  5.14242E-03 0.00034  4.17290E-04 0.00163  3.08732E-01 0.00012 ];
INF_S2                    (idx, [1:   8]) = [  9.13136E-02 7.6E-05 -1.48662E-03 0.00070  2.34302E-04 0.00236  7.71359E-02 0.00020 ];
INF_S3                    (idx, [1:   8]) = [  8.66554E-03 0.00066 -1.79919E-03 0.00048  8.44071E-05 0.00621  2.40984E-02 0.00050 ];
INF_S4                    (idx, [1:   8]) = [ -8.46760E-03 0.00057 -6.09742E-04 0.00151  2.38422E-06 0.18246 -5.39783E-03 0.00275 ];
INF_S5                    (idx, [1:   8]) = [  2.89601E-06 1.00000  1.01516E-05 0.08688 -3.17913E-05 0.01555  5.76673E-03 0.00223 ];
INF_S6                    (idx, [1:   8]) = [  4.64474E-03 0.00093 -1.38951E-04 0.00539 -4.16127E-05 0.01044 -1.25758E-02 0.00091 ];
INF_S7                    (idx, [1:   8]) = [  7.93256E-04 0.00545 -1.65591E-04 0.00349 -3.75436E-05 0.00893  4.73428E-04 0.02256 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.98517E-01 2.9E-05  1.75349E-02 9.2E-05  1.08011E-03 0.00127  1.19240E+00 6.2E-05 ];
INF_SP1                   (idx, [1:   8]) = [  2.20456E-01 5.3E-05  5.14242E-03 0.00034  4.17290E-04 0.00163  3.08732E-01 0.00012 ];
INF_SP2                   (idx, [1:   8]) = [  9.13137E-02 7.6E-05 -1.48662E-03 0.00070  2.34302E-04 0.00236  7.71359E-02 0.00020 ];
INF_SP3                   (idx, [1:   8]) = [  8.66556E-03 0.00066 -1.79919E-03 0.00048  8.44071E-05 0.00621  2.40984E-02 0.00050 ];
INF_SP4                   (idx, [1:   8]) = [ -8.46762E-03 0.00057 -6.09742E-04 0.00151  2.38422E-06 0.18246 -5.39783E-03 0.00275 ];
INF_SP5                   (idx, [1:   8]) = [  2.86221E-06 1.00000  1.01516E-05 0.08688 -3.17913E-05 0.01555  5.76673E-03 0.00223 ];
INF_SP6                   (idx, [1:   8]) = [  4.64472E-03 0.00093 -1.38951E-04 0.00539 -4.16127E-05 0.01044 -1.25758E-02 0.00091 ];
INF_SP7                   (idx, [1:   8]) = [  7.93215E-04 0.00545 -1.65591E-04 0.00349 -3.75436E-05 0.00893  4.73428E-04 0.02256 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37349E-01 0.00021  7.11530E-01 0.00109 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37625E-01 0.00027  7.22080E-01 0.00111 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37600E-01 0.00025  7.22155E-01 0.00154 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.36826E-01 0.00031  6.91290E-01 0.00137 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40440E+00 0.00021  4.68488E-01 0.00110 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40278E+00 0.00027  4.61643E-01 0.00111 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40292E+00 0.00025  4.61608E-01 0.00153 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40751E+00 0.00031  4.82212E-01 0.00137 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.31032E-03 0.00268  1.93585E-04 0.01384  1.04037E-03 0.00643  1.00190E-03 0.00623  2.87734E-03 0.00371  8.88651E-04 0.00658  3.08465E-04 0.01131 ];
LAMBDA                    (idx, [1:  14]) = [  7.89708E-01 0.00582  1.24905E-02 1.1E-05  3.15986E-02 0.00011  1.09798E-01 0.00011  3.19400E-01 8.1E-05  1.34730E+00 0.00011  8.82731E+00 0.00074 ];

