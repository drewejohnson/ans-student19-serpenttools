
% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Feb 15 2018 09:16:52' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  6])  = 'simple' ;
WORKING_DIRECTORY         (idx, [1: 69])  = '/gpfs/pace1/project/me-kotlyar/ajohnson400/ans-student19-serpenttools' ;
HOSTNAME                  (idx, [1: 32])  = 'rich133-c36-11-r.pace.gatech.edu' ;
CPU_TYPE                  (idx, [1: 41])  = 'Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz' ;
CPU_MHZ                   (idx, 1)        = 184549409.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Mar  8 11:58:19 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Mar  8 11:58:23 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1552064299 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.01272E+00  9.94876E-01  9.79371E-01  1.01304E+00  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 72])  = '/nv/hp22/ajohnson400/data/Codes/Serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1:  3])  = 'N/A' ;
SFY_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;
NFY_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 4.0E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.50917E-02 0.00843  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84908E-01 0.00013  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.88463E-01 0.00072  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.89405E-01 0.00072  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.94748E+00 0.00251  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.16975E+01 0.00285  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.16975E+01 0.00285  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.87910E+01 0.00397  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.41200E-01 0.00972  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50130 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.01300E+02 0.00679 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.01300E+02 0.00679 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.58333E-01 ;
RUNNING_TIME              (idx, 1)        =  7.56000E-02 ;
INIT_TIME                 (idx, [1:  2])  = [  4.23667E-02  4.23667E-02 ];
PROCESS_TIME              (idx, [1:  2])  = [  2.00001E-04  2.00001E-04 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.30333E-02  3.30333E-02  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  7.51833E-02  0.00000E+00 ];
CPU_USAGE                 (idx, 1)        = 2.09436 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  4.01421E+00 0.00838 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  4.24383E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 129078.54 ;
ALLOC_MEMSIZE             (idx, 1)        = 200.35;
MEMSIZE                   (idx, 1)        = 134.93;
XS_MEMSIZE                (idx, 1)        = 88.77;
MAT_MEMSIZE               (idx, 1)        = 15.21;
RES_MEMSIZE               (idx, 1)        = 4.66;
MISC_MEMSIZE              (idx, 1)        = 26.28;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 65.42;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  0.00000E+00 ;
NEUTRON_ERG_NE            (idx, 1)        = 124272 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 4 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 12 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 12 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 0 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 365 ;
TOT_TRANSMU_REA           (idx, 1)        = 0 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  0.00000E+00 ;
TOT_DECAY_HEAT            (idx, 1)        =  0.00000E+00 ;
TOT_SF_RATE               (idx, 1)        =  0.00000E+00 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  0.00000E+00 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  0.00000E+00 ;
INHALATION_TOXICITY       (idx, 1)        =  0.00000E+00 ;
INGESTION_TOXICITY        (idx, 1)        =  0.00000E+00 ;
ACTINIDE_INH_TOX          (idx, 1)        =  0.00000E+00 ;
ACTINIDE_ING_TOX          (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  0.00000E+00 ;
SR90_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
TE132_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
I131_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
I132_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
CS134_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
CS137_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  0.00000E+00 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  0.00000E+00 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  0.00000E+00 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.99311E-03 0.00326  0.00000E+00 0.0E+00 ];

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.36610E-01 0.01190 ];
U235_FISS                 (idx, [1:   4]) = [  5.29391E-01 0.00509  9.66654E-01 0.00119 ];
U238_FISS                 (idx, [1:   4]) = [  1.83290E-02 0.03615  3.33107E-02 0.03458 ];
U235_CAPT                 (idx, [1:   4]) = [  1.06807E-01 0.01234  2.37755E-01 0.01211 ];
U238_CAPT                 (idx, [1:   4]) = [  2.11760E-01 0.00964  4.70609E-01 0.00714 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50130 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 6.03767E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50130 5.00604E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 22617 2.25746E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 27513 2.74858E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50130 5.00604E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -2.91038E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   2]) = [  1.77273E-11 0.00161 ];
TOT_POWDENS               (idx, [1:   2]) = [  1.36203E-16 0.00161 ];
TOT_GENRATE               (idx, [1:   2]) = [  1.33880E+00 0.00159 ];
TOT_FISSRATE              (idx, [1:   2]) = [  5.46587E-01 0.00161 ];
TOT_CAPTRATE              (idx, [1:   2]) = [  4.53413E-01 0.00194 ];
TOT_ABSRATE               (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
TOT_SRCRATE               (idx, [1:   2]) = [  9.96557E-01 0.00326 ];
TOT_FLUX                  (idx, [1:   2]) = [  5.82861E+01 0.00251 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  4.15756E+01 0.00229 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.30153E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.83209E+00 0.00342 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.60854E-01 0.00240 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.46886E-01 0.00265 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14375E+00 0.00245 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.34661E+00 0.00452 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.34661E+00 0.00452 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.44938E+00 7.7E-05 ];
FISSE                     (idx, [1:   2]) = [  2.02429E+02 8.2E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.34547E+00 0.00483  1.33785E+00 0.00458  8.76429E-03 0.06788 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.34030E+00 0.00160 ];
COL_KEFF                  (idx, [1:   2]) = [  1.34501E+00 0.00397 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.34030E+00 0.00160 ];
ABS_KINF                  (idx, [1:   2]) = [  1.34030E+00 0.00160 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83547E+01 0.00127 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83704E+01 0.00052 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.19301E-07 0.02267 ];
IMP_EALF                  (idx, [1:   2]) = [  2.11279E-07 0.00978 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.14818E-01 0.03516 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.13066E-01 0.01329 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.02696E-03 0.05454  9.91788E-05 0.36728  9.60090E-04 0.11130  9.25125E-04 0.13583  2.04912E-03 0.09142  7.97133E-04 0.12928  1.96305E-04 0.28464 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.44092E-01 0.16053  8.74339E-04 0.36633  1.64962E-02 0.09657  4.60361E-02 0.11812  2.45000E-01 0.05495  5.93690E-01 0.11339  1.04979E+00 0.27244 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.31739E-03 0.07484  1.28958E-04 0.47404  1.30280E-03 0.17368  9.70515E-04 0.21358  2.60340E-03 0.11625  9.82895E-04 0.19952  3.28825E-04 0.34712 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  8.47461E-01 0.17413  1.24906E-02 8.2E-09  3.17194E-02 0.00168  1.09617E-01 0.00162  3.18283E-01 0.00162  1.34954E+00 0.00128  8.74826E+00 0.01279 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.64637E-05 0.00902  3.64590E-05 0.00900  3.09464E-05 0.09598 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.89594E-05 0.00786  4.89520E-05 0.00782  4.15522E-05 0.09677 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.66781E-03 0.06782  2.13399E-04 0.45602  1.28889E-03 0.16667  1.01450E-03 0.19122  2.78075E-03 0.11204  9.30887E-04 0.21673  4.39384E-04 0.30470 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  9.28217E-01 0.18817  1.24906E-02 0.0E+00  3.17228E-02 0.00222  1.09638E-01 0.00239  3.18407E-01 0.00191  1.35193E+00 0.00118  8.75844E+00 0.01394 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.65907E-05 0.02102  3.65479E-05 0.02131  1.26638E-05 0.19418 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.91040E-05 0.02061  4.90482E-05 0.02091  1.67309E-05 0.19181 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  7.55531E-03 0.19973  4.42529E-04 0.72211  2.43672E-03 0.40288  1.48427E-03 0.46075  2.54337E-03 0.36105  6.48430E-04 0.44282  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  3.31200E-01 0.19798  1.24906E-02 0.0E+00  3.13962E-02 0.00704  1.09375E-01 5.7E-09  3.19525E-01 0.00516  1.34893E+00 0.00374  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  8.04512E-03 0.19380  5.48261E-04 0.70512  2.46480E-03 0.42950  1.54093E-03 0.43422  2.89610E-03 0.33209  5.95025E-04 0.46441  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  3.22477E-01 0.20193  1.24906E-02 0.0E+00  3.13962E-02 0.00704  1.09375E-01 5.7E-09  3.19438E-01 0.00526  1.34893E+00 0.00374  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -2.28707E+02 0.21771 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.63351E-05 0.00576 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.87788E-05 0.00331 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  7.65729E-03 0.03325 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -2.11389E+02 0.03386 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.18558E-07 0.00399 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.32276E-06 0.00440  3.32158E-06 0.00445  3.19199E-06 0.07254 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.26376E-05 0.00553  5.26597E-05 0.00552  4.49095E-05 0.07267 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.47265E-01 0.00264  7.46059E-01 0.00263  1.35916E+00 0.10449 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  9.21846E+00 0.10996 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.16975E+01 0.00285  4.56638E+01 0.00363 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.34808E+03 0.03217  1.43722E+04 0.00952  3.04835E+04 0.00698  3.68448E+04 0.01106  3.56336E+04 0.00335  3.73795E+04 0.00436  2.59885E+04 0.00942  2.20605E+04 0.00965  1.66340E+04 0.01257  1.40118E+04 0.00383  1.20253E+04 0.00959  1.08771E+04 0.00646  1.00256E+04 0.01152  9.24217E+03 0.01376  8.97371E+03 0.00392  7.97811E+03 0.00808  7.92235E+03 0.01019  7.71816E+03 0.00447  7.69197E+03 0.00831  1.50794E+04 0.01260  1.47062E+04 0.00770  1.05803E+04 0.01266  6.91161E+03 0.00739  8.14177E+03 0.00770  7.84543E+03 0.00870  7.17339E+03 0.01101  1.20215E+04 0.00476  2.78709E+03 0.01021  3.33730E+03 0.01250  3.13644E+03 0.01789  1.77218E+03 0.00839  3.15905E+03 0.01440  2.23073E+03 0.02417  1.82271E+03 0.01533  3.55179E+02 0.05958  3.58836E+02 0.04607  3.40456E+02 0.01481  3.69833E+02 0.03029  3.71630E+02 0.02646  3.48723E+02 0.03500  3.86151E+02 0.03218  3.38956E+02 0.02562  6.46709E+02 0.00948  1.04525E+03 0.01951  1.33170E+03 0.01949  3.54921E+03 0.00932  3.86566E+03 0.01223  4.31353E+03 0.01381  3.11685E+03 0.02110  2.34001E+03 0.01649  1.87082E+03 0.02012  2.27979E+03 0.01184  4.41229E+03 0.01839  5.90934E+03 0.01356  1.16826E+04 0.01384  1.74376E+04 0.00527  2.57661E+04 0.00745  1.59466E+04 0.00877  1.14475E+04 0.01028  8.16236E+03 0.00773  7.18111E+03 0.00980  6.98435E+03 0.01062  5.75920E+03 0.00507  3.86594E+03 0.00509  3.57163E+03 0.01067  3.18652E+03 0.00657  2.73702E+03 0.00782  2.09601E+03 0.01109  1.38331E+03 0.01009  4.77445E+02 0.01417 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.34501E+00 0.00283 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  4.27877E+01 0.00090  1.55260E+01 0.00534 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.23205E-01 0.00074  1.23772E+00 0.00152 ];
INF_CAPT                  (idx, [1:   4]) = [  4.40162E-03 0.00803  1.70999E-02 0.00317 ];
INF_ABS                   (idx, [1:   4]) = [  5.91819E-03 0.00588  4.81700E-02 0.00490 ];
INF_FISS                  (idx, [1:   4]) = [  1.51657E-03 0.00566  3.10701E-02 0.00586 ];
INF_NSF                   (idx, [1:   4]) = [  3.85722E-03 0.00585  7.57086E-02 0.00586 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54336E+00 0.00037  2.43670E+00 0.0E+00 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03608E+02 1.9E-05  2.02270E+02 0.0E+00 ];
INF_INVV                  (idx, [1:   4]) = [  6.37569E-08 0.00698  2.52420E-06 0.00069 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.17282E-01 0.00077  1.18978E+00 0.00159 ];
INF_SCATT1                (idx, [1:   4]) = [  2.26385E-01 0.00058  3.08044E-01 0.00395 ];
INF_SCATT2                (idx, [1:   4]) = [  9.02601E-02 0.00189  7.76363E-02 0.00437 ];
INF_SCATT3                (idx, [1:   4]) = [  6.58917E-03 0.01803  2.41568E-02 0.02523 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.45462E-03 0.01578 -5.27997E-03 0.06608 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.46407E-04 0.38299  5.43677E-03 0.03951 ];
INF_SCATT6                (idx, [1:   4]) = [  4.52534E-03 0.03131 -1.28095E-02 0.03617 ];
INF_SCATT7                (idx, [1:   4]) = [  5.39742E-04 0.17711  6.00756E-04 0.43648 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.17310E-01 0.00077  1.18978E+00 0.00159 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.26385E-01 0.00058  3.08044E-01 0.00395 ];
INF_SCATTP2               (idx, [1:   4]) = [  9.02584E-02 0.00190  7.76363E-02 0.00437 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.58984E-03 0.01790  2.41568E-02 0.02523 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.45638E-03 0.01579 -5.27997E-03 0.06608 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.46392E-04 0.38463  5.43677E-03 0.03951 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.52492E-03 0.03134 -1.28095E-02 0.03617 ];
INF_SCATTP7               (idx, [1:   4]) = [  5.40210E-04 0.17712  6.00756E-04 0.43648 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.28521E-01 0.00164  8.29574E-01 0.00155 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.45867E+00 0.00164  4.01816E-01 0.00155 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.89007E-03 0.00576  4.81700E-02 0.00490 ];
INF_REMXS                 (idx, [1:   4]) = [  2.36700E-02 0.00066  4.89129E-02 0.00536 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.99535E-01 0.00079  1.77467E-02 0.00132  9.68362E-04 0.04609  1.18881E+00 0.00161 ];
INF_S1                    (idx, [1:   8]) = [  2.21173E-01 0.00048  5.21146E-03 0.00703  4.37766E-04 0.08014  3.07606E-01 0.00399 ];
INF_S2                    (idx, [1:   8]) = [  9.17340E-02 0.00171 -1.47392E-03 0.02122  2.75890E-04 0.06461  7.73604E-02 0.00444 ];
INF_S3                    (idx, [1:   8]) = [  8.43035E-03 0.01350 -1.84118E-03 0.01135  1.25980E-04 0.10378  2.40308E-02 0.02585 ];
INF_S4                    (idx, [1:   8]) = [ -8.81049E-03 0.01713 -6.44133E-04 0.01714  5.60311E-06 1.00000 -5.28557E-03 0.06433 ];
INF_S5                    (idx, [1:   8]) = [ -1.72395E-04 0.39060  2.59883E-05 0.48252 -2.05633E-05 0.56315  5.45733E-03 0.03795 ];
INF_S6                    (idx, [1:   8]) = [  4.64398E-03 0.03330 -1.18638E-04 0.26107 -4.71507E-05 0.20815 -1.27623E-02 0.03590 ];
INF_S7                    (idx, [1:   8]) = [  7.23448E-04 0.13327 -1.83706E-04 0.06825 -4.01055E-05 0.12283  6.40862E-04 0.41116 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.99563E-01 0.00079  1.77467E-02 0.00132  9.68362E-04 0.04609  1.18881E+00 0.00161 ];
INF_SP1                   (idx, [1:   8]) = [  2.21174E-01 0.00048  5.21146E-03 0.00703  4.37766E-04 0.08014  3.07606E-01 0.00399 ];
INF_SP2                   (idx, [1:   8]) = [  9.17323E-02 0.00172 -1.47392E-03 0.02122  2.75890E-04 0.06461  7.73604E-02 0.00444 ];
INF_SP3                   (idx, [1:   8]) = [  8.43102E-03 0.01342 -1.84118E-03 0.01135  1.25980E-04 0.10378  2.40308E-02 0.02585 ];
INF_SP4                   (idx, [1:   8]) = [ -8.81225E-03 0.01714 -6.44133E-04 0.01714  5.60311E-06 1.00000 -5.28557E-03 0.06433 ];
INF_SP5                   (idx, [1:   8]) = [ -1.72381E-04 0.39209  2.59883E-05 0.48252 -2.05633E-05 0.56315  5.45733E-03 0.03795 ];
INF_SP6                   (idx, [1:   8]) = [  4.64356E-03 0.03327 -1.18638E-04 0.26107 -4.71507E-05 0.20815 -1.27623E-02 0.03590 ];
INF_SP7                   (idx, [1:   8]) = [  7.23916E-04 0.13324 -1.83706E-04 0.06825 -4.01055E-05 0.12283  6.40862E-04 0.41116 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.38650E-01 0.00428  6.83178E-01 0.03079 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.38126E-01 0.00784  6.73865E-01 0.03553 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.39170E-01 0.00913  7.07210E-01 0.04313 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.38743E-01 0.00132  6.72318E-01 0.02874 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.39685E+00 0.00432  4.89721E-01 0.02999 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40017E+00 0.00784  4.97119E-01 0.03494 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.39417E+00 0.00908  4.74570E-01 0.03956 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.39621E+00 0.00132  4.97475E-01 0.02935 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.31739E-03 0.07484  1.28958E-04 0.47404  1.30280E-03 0.17368  9.70515E-04 0.21358  2.60340E-03 0.11625  9.82895E-04 0.19952  3.28825E-04 0.34712 ];
LAMBDA                    (idx, [1:  14]) = [  8.47461E-01 0.17413  1.24906E-02 8.2E-09  3.17194E-02 0.00168  1.09617E-01 0.00162  3.18283E-01 0.00162  1.34954E+00 0.00128  8.74826E+00 0.01279 ];

