
ZAI = [
666
0
];

NAMES = [
'lost            '
'total           '
];

iLOST    = 1;
iTOT     = 2;

MAT_fuel_VOLUME = [ 1.43351E+01 1.43351E+01 ];

MAT_fuel_BURNUP = [ 0.00000E+00 1.00143E-01 ];

MAT_fuel_ADENS = [
0.00000E+00 1.06422E-13 % lost data
6.88389E-02 6.88413E-02 % total
];

MAT_fuel_MDENS = [
0.00000E+00 0.00000E+00 % lost data
1.02975E+01 1.02975E+01 % total
];

MAT_fuel_A = [
0.00000E+00 0.00000E+00 % lost data
9.32680E+06 8.25591E+16 % total
];

MAT_fuel_H = [
0.00000E+00 0.00000E+00 % lost data
7.09528E-06 3.66016E+04 % total
];

MAT_fuel_SF = [
0.00000E+00 0.00000E+00 % lost data
8.56119E+01 8.56079E+01 % total
];

MAT_fuel_GSRC = [
0.00000E+00 0.00000E+00 % lost data
1.24909E+06 6.03766E+16 % total
];

MAT_fuel_ING_TOX = [
0.00000E+00 0.00000E+00 % lost data
4.50096E-01 1.13199E+06 % total
];

MAT_fuel_INH_TOX = [
0.00000E+00 0.00000E+00 % lost data
8.51863E+01 5.84937E+05 % total
];

TOT_VOLUME = [ 1.43351E+01 1.43351E+01 ];

TOT_BURNUP = [ 0.00000E+00 1.00143E-01 ];

TOT_ADENS = [
0.00000E+00 1.06422E-13 % lost data
6.88389E-02 6.88413E-02 % total
];

TOT_MASS = [
0.00000E+00 0.00000E+00 % lost data
1.47615E+02 1.47615E+02 % total
];

TOT_A = [
0.00000E+00 0.00000E+00 % lost data
9.32680E+06 8.25591E+16 % total
];

TOT_H = [
0.00000E+00 0.00000E+00 % lost data
7.09528E-06 3.66016E+04 % total
];

TOT_SF = [
0.00000E+00 0.00000E+00 % lost data
8.56119E+01 8.56079E+01 % total
];

TOT_GSRC = [
0.00000E+00 0.00000E+00 % lost data
1.24909E+06 6.03766E+16 % total
];

TOT_ING_TOX = [
0.00000E+00 0.00000E+00 % lost data
4.50096E-01 1.13199E+06 % total
];

TOT_INH_TOX = [
0.00000E+00 0.00000E+00 % lost data
8.51863E+01 5.84937E+05 % total
];

BU = [ 0.00000E+00 1.00000E-01 ];

DAYS = [ 0.00000E+00 1.66667E-02 ];
