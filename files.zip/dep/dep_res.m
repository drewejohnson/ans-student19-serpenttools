
% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:03 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  9.98632E-01  1.00830E+00  9.94915E-01  9.98154E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 1.9E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  8.51904E-02 0.00425  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.14810E-01 0.00040  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.98669E-01 0.00059  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.01353E-01 0.00058  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.09503E+00 0.00266  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  3.95472E+01 0.00257  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  3.95472E+01 0.00257  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.68397E+01 0.00281  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  4.70078E+00 0.00602  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50078 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.00780E+02 0.00611 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.00780E+02 0.00611 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  5.59414E-01 ;
RUNNING_TIME              (idx, 1)        =  5.39850E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  5.16665E-04  5.16665E-04 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.32833E-02  3.32833E-02  0.00000E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  5.39467E-01  0.00000E+00 ];
CPU_USAGE                 (idx, 1)        = 1.03624 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.98892E+00 0.00783 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  6.06033E-02 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.32680E+06 ;
TOT_DECAY_HEAT            (idx, 1)        =  7.09528E-06 ;
TOT_SF_RATE               (idx, 1)        =  8.56119E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  9.32680E+06 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  7.09528E-06 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  0.00000E+00 ;
INHALATION_TOXICITY       (idx, 1)        =  8.51863E+01 ;
INGESTION_TOXICITY        (idx, 1)        =  4.50096E-01 ;
ACTINIDE_INH_TOX          (idx, 1)        =  8.51863E+01 ;
ACTINIDE_ING_TOX          (idx, 1)        =  4.50096E-01 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  0.00000E+00 ;
SR90_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
TE132_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
I131_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
I132_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
CS134_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
CS137_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.24909E+06 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  9.32204E+06 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  3.88066E+06 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  8.60741E+13 0.00410  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 0 ;
BURNUP                     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
BURN_DAYS                 (idx, 1)        =  0.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.45833E-01 0.01069 ];
U235_FISS                 (idx, [1:   4]) = [  2.32584E+16 0.00488  9.66631E-01 0.00100 ];
U238_FISS                 (idx, [1:   4]) = [  8.01262E+14 0.02931  3.32941E-02 0.02906 ];
U235_CAPT                 (idx, [1:   4]) = [  4.64171E+15 0.01330  2.43947E-01 0.01150 ];
U238_CAPT                 (idx, [1:   4]) = [  9.56586E+15 0.01038  5.02348E-01 0.00706 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50078 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 7.12650E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50078 5.00713E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 22111 2.21040E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 27967 2.79672E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50078 5.00713E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -7.27596E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  5.89684E+16 6.6E-05  5.89684E+16 6.6E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.40784E+16 8.1E-06  2.40784E+16 8.1E-06  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.89231E+16 0.00344  1.42590E+16 0.00441  4.66415E+15 0.00440 ];
TOT_ABSRATE               (idx, [1:   6]) = [  4.30015E+16 0.00151  3.83373E+16 0.00164  4.66415E+15 0.00440 ];
TOT_SRCRATE               (idx, [1:   6]) = [  4.30370E+16 0.00410  4.30370E+16 0.00410  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  2.56475E+18 0.00356  4.21578E+17 0.00409  2.14317E+18 0.00365 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  4.30015E+16 0.00151 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.70291E+18 0.00292 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.30153E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.82386E+00 0.00294 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.75037E-01 0.00183 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.53798E-01 0.00241 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.13912E+00 0.00189 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.36997E+00 0.00395 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.36997E+00 0.00395 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.44902E+00 7.3E-05 ];
FISSE                     (idx, [1:   2]) = [  2.02427E+02 8.1E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.37179E+00 0.00408  1.36149E+00 0.00407  8.47481E-03 0.08100 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.37318E+00 0.00149 ];
COL_KEFF                  (idx, [1:   2]) = [  1.37247E+00 0.00413 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.37318E+00 0.00149 ];
ABS_KINF                  (idx, [1:   2]) = [  1.37318E+00 0.00149 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83988E+01 0.00104 ];
IMP_ALF                   (idx, [1:   2]) = [  1.84051E+01 0.00049 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.08351E-07 0.02071 ];
IMP_EALF                  (idx, [1:   2]) = [  2.03964E-07 0.00921 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.12381E-01 0.03243 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.10434E-01 0.01309 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  4.67295E-03 0.05731  1.65616E-04 0.32112  8.08380E-04 0.11962  6.96462E-04 0.15023  2.36061E-03 0.07606  4.69086E-04 0.19411  1.72795E-04 0.29529 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  5.59616E-01 0.15958  1.24906E-03 0.30151  1.49259E-02 0.10674  4.28368E-02 0.12571  2.71333E-01 0.04226  3.37612E-01 0.17408  9.76854E-01 0.28642 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.35960E-03 0.08895  2.59206E-04 0.36971  1.08350E-03 0.17314  8.45442E-04 0.19908  3.31867E-03 0.13501  6.02034E-04 0.24919  2.50749E-04 0.38716 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  5.29402E-01 0.17107  1.24906E-02 3.9E-09  3.17573E-02 0.00147  1.09825E-01 0.00225  3.18817E-01 0.00189  1.35058E+00 0.00149  8.90491E+00 0.02010 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.66078E-05 0.00979  3.65677E-05 0.00971  2.81925E-05 0.10902 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  5.01353E-05 0.00890  5.00821E-05 0.00885  3.83770E-05 0.10899 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.38377E-03 0.08642  2.54794E-04 0.37105  1.23963E-03 0.18004  9.86748E-04 0.20180  3.03403E-03 0.12282  6.73987E-04 0.24413  1.94578E-04 0.45827 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  4.36992E-01 0.15270  1.24906E-02 8.0E-09  3.17700E-02 0.00170  1.09946E-01 0.00306  3.18722E-01 0.00247  1.34774E+00 0.00250  8.90491E+00 0.03016 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.66594E-05 0.02038  3.66748E-05 0.02077  9.60977E-06 0.21553 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  5.02024E-05 0.01997  5.02212E-05 0.02034  1.31818E-05 0.21459 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  8.19366E-03 0.23448  5.29695E-04 0.72973  1.99773E-03 0.50292  1.21456E-03 0.45078  3.86711E-03 0.35620  4.10761E-04 0.53358  1.73806E-04 1.00000 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  3.83634E-01 0.21767  1.24906E-02 2.1E-08  3.18241E-02 5.8E-09  1.09375E-01 5.8E-09  3.18208E-01 0.00383  1.34691E+00 0.00525  9.97903E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  7.95547E-03 0.24640  4.77177E-04 0.72310  1.78117E-03 0.49150  1.22517E-03 0.42800  3.88535E-03 0.38522  4.24660E-04 0.55307  1.61943E-04 1.00000 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  3.75130E-01 0.21262  1.24906E-02 0.0E+00  3.18241E-02 5.8E-09  1.09375E-01 8.2E-09  3.18095E-01 0.00347  1.34691E+00 0.00525  9.97903E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -2.34465E+02 0.24578 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.64301E-05 0.00508 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.98909E-05 0.00293 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.85791E-03 0.05205 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.89090E+02 0.05306 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.18684E-07 0.00425 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.39514E-06 0.00453  3.39690E-06 0.00455  2.78963E-06 0.06877 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.31587E-05 0.00550  5.31161E-05 0.00547  5.16234E-05 0.07093 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.54101E-01 0.00243  7.52804E-01 0.00245  1.37256E+00 0.10229 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.34728E+01 0.17107 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  3.95472E+01 0.00257  4.32628E+01 0.00355 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.57177E+03 0.04719  1.47182E+04 0.01104  3.20115E+04 0.00326  3.79914E+04 0.00532  3.70312E+04 0.00373  3.82246E+04 0.00564  2.60217E+04 0.00734  2.24472E+04 0.00510  1.71490E+04 0.01148  1.38512E+04 0.00643  1.20782E+04 0.00751  1.06883E+04 0.00806  1.01636E+04 0.00975  9.76521E+03 0.00704  9.54277E+03 0.00519  8.00696E+03 0.00906  7.85471E+03 0.01068  8.02172E+03 0.01202  7.88240E+03 0.01187  1.55589E+04 0.00357  1.50424E+04 0.00704  1.08594E+04 0.00993  7.20096E+03 0.01274  8.46447E+03 0.01089  7.99142E+03 0.00612  7.22348E+03 0.01237  1.21836E+04 0.01204  2.82911E+03 0.01821  3.57169E+03 0.01379  3.17937E+03 0.02584  1.86753E+03 0.02005  3.27256E+03 0.00590  2.17270E+03 0.01734  1.89680E+03 0.03337  3.27214E+02 0.05409  3.54820E+02 0.05406  3.67463E+02 0.02603  3.94935E+02 0.05378  3.96594E+02 0.03437  3.58461E+02 0.03702  3.88614E+02 0.02760  3.52654E+02 0.02372  6.60432E+02 0.01791  1.09265E+03 0.02766  1.45882E+03 0.01306  3.68615E+03 0.02440  3.92813E+03 0.01784  4.30280E+03 0.01672  2.97700E+03 0.01919  2.32058E+03 0.00309  1.71052E+03 0.01396  2.05872E+03 0.01937  4.00151E+03 0.01297  5.52644E+03 0.01456  1.09859E+04 0.00570  1.69728E+04 0.00364  2.55903E+04 0.00624  1.62625E+04 0.00835  1.17115E+04 0.00548  8.35703E+03 0.00774  7.51286E+03 0.01524  7.16760E+03 0.00405  6.17132E+03 0.00945  4.09163E+03 0.01446  3.81948E+03 0.00895  3.36917E+03 0.00902  2.89347E+03 0.01392  2.25461E+03 0.02376  1.48059E+03 0.01855  5.39827E+02 0.04080 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.37254E+00 0.00277 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.89438E+18 0.00261  6.71403E+17 0.00368 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73438E-01 0.00089  1.20240E+00 0.00103 ];
INF_CAPT                  (idx, [1:   4]) = [  4.15941E-03 0.00436  1.64710E-02 0.00212 ];
INF_ABS                   (idx, [1:   4]) = [  5.66984E-03 0.00394  4.81332E-02 0.00317 ];
INF_FISS                  (idx, [1:   4]) = [  1.51043E-03 0.00432  3.16623E-02 0.00373 ];
INF_NSF                   (idx, [1:   4]) = [  3.83696E-03 0.00434  7.71514E-02 0.00373 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54032E+00 0.00086  2.43670E+00 0.0E+00 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03590E+02 9.6E-05  2.02270E+02 0.0E+00 ];
INF_INVV                  (idx, [1:   4]) = [  6.40181E-08 0.00453  2.56644E-06 0.00156 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.67813E-01 0.00090  1.15408E+00 0.00111 ];
INF_SCATT1                (idx, [1:   4]) = [  2.22275E-01 0.00141  2.97760E-01 0.00152 ];
INF_SCATT2                (idx, [1:   4]) = [  8.82252E-02 0.00260  7.18353E-02 0.00485 ];
INF_SCATT3                (idx, [1:   4]) = [  6.18186E-03 0.03187  2.16381E-02 0.00733 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.49103E-03 0.00666 -6.13377E-03 0.05285 ];
INF_SCATT5                (idx, [1:   4]) = [ -7.92026E-05 1.00000  5.70304E-03 0.07782 ];
INF_SCATT6                (idx, [1:   4]) = [  4.41982E-03 0.01342 -1.21893E-02 0.03108 ];
INF_SCATT7                (idx, [1:   4]) = [  6.63526E-04 0.19171  9.06756E-04 0.20503 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67846E-01 0.00090  1.15408E+00 0.00111 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.22277E-01 0.00142  2.97760E-01 0.00152 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.82231E-02 0.00259  7.18353E-02 0.00485 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.18214E-03 0.03185  2.16381E-02 0.00733 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.49220E-03 0.00668 -6.13377E-03 0.05285 ];
INF_SCATTP5               (idx, [1:   4]) = [ -7.97844E-05 1.00000  5.70304E-03 0.07782 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.41964E-03 0.01342 -1.21893E-02 0.03108 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.63947E-04 0.19156  9.06756E-04 0.20503 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95439E-01 0.00169  7.91626E-01 0.00298 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70558E+00 0.00169  4.21089E-01 0.00298 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.63745E-03 0.00353  4.81332E-02 0.00317 ];
INF_REMXS                 (idx, [1:   4]) = [  2.30347E-02 0.00091  4.91239E-02 0.00272 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50403E-01 0.00094  1.74101E-02 0.00173  8.04106E-04 0.02872  1.15328E+00 0.00111 ];
INF_S1                    (idx, [1:   8]) = [  2.17137E-01 0.00157  5.13775E-03 0.00718  3.74193E-04 0.07323  2.97386E-01 0.00152 ];
INF_S2                    (idx, [1:   8]) = [  8.96836E-02 0.00242 -1.45846E-03 0.03054  2.23542E-04 0.08035  7.16117E-02 0.00498 ];
INF_S3                    (idx, [1:   8]) = [  7.98520E-03 0.02642 -1.80334E-03 0.00967  1.00044E-04 0.18520  2.15380E-02 0.00724 ];
INF_S4                    (idx, [1:   8]) = [ -8.84432E-03 0.00715 -6.46705E-04 0.04669  4.09594E-06 1.00000 -6.13787E-03 0.05169 ];
INF_S5                    (idx, [1:   8]) = [ -9.62009E-05 1.00000  1.69983E-05 1.00000 -2.33699E-05 0.58771  5.72641E-03 0.07822 ];
INF_S6                    (idx, [1:   8]) = [  4.56508E-03 0.01433 -1.45255E-04 0.15687 -3.39371E-05 0.25064 -1.21553E-02 0.03079 ];
INF_S7                    (idx, [1:   8]) = [  8.59077E-04 0.13885 -1.95551E-04 0.14188 -4.20700E-05 0.17831  9.48826E-04 0.19318 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50435E-01 0.00094  1.74101E-02 0.00173  8.04106E-04 0.02872  1.15328E+00 0.00111 ];
INF_SP1                   (idx, [1:   8]) = [  2.17139E-01 0.00157  5.13775E-03 0.00718  3.74193E-04 0.07323  2.97386E-01 0.00152 ];
INF_SP2                   (idx, [1:   8]) = [  8.96816E-02 0.00241 -1.45846E-03 0.03054  2.23542E-04 0.08035  7.16117E-02 0.00498 ];
INF_SP3                   (idx, [1:   8]) = [  7.98548E-03 0.02641 -1.80334E-03 0.00967  1.00044E-04 0.18520  2.15380E-02 0.00724 ];
INF_SP4                   (idx, [1:   8]) = [ -8.84550E-03 0.00719 -6.46705E-04 0.04669  4.09594E-06 1.00000 -6.13787E-03 0.05169 ];
INF_SP5                   (idx, [1:   8]) = [ -9.67827E-05 1.00000  1.69983E-05 1.00000 -2.33699E-05 0.58771  5.72641E-03 0.07822 ];
INF_SP6                   (idx, [1:   8]) = [  4.56489E-03 0.01429 -1.45255E-04 0.15687 -3.39371E-05 0.25064 -1.21553E-02 0.03079 ];
INF_SP7                   (idx, [1:   8]) = [  8.59498E-04 0.13863 -1.95551E-04 0.14188 -4.20700E-05 0.17831  9.48826E-04 0.19318 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.02581E-01 0.00319  6.48727E-01 0.02471 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.02281E-01 0.01018  6.78869E-01 0.02932 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.04090E-01 0.00831  6.79552E-01 0.04066 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.01525E-01 0.00495  5.99104E-01 0.03284 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.64550E+00 0.00321  5.15037E-01 0.02378 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.64857E+00 0.01039  4.92666E-01 0.02863 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.63371E+00 0.00814  4.93577E-01 0.03818 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.65422E+00 0.00499  5.58867E-01 0.03387 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.35960E-03 0.08895  2.59206E-04 0.36971  1.08350E-03 0.17314  8.45442E-04 0.19908  3.31867E-03 0.13501  6.02034E-04 0.24919  2.50749E-04 0.38716 ];
LAMBDA                    (idx, [1:  14]) = [  5.29402E-01 0.17107  1.24906E-02 3.9E-09  3.17573E-02 0.00147  1.09825E-01 0.00225  3.18817E-01 0.00189  1.35058E+00 0.00149  8.90491E+00 0.02010 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:08 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00616E+00  1.00313E+00  9.96794E-01  9.93920E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  8.80759E-02 0.00364  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.11924E-01 0.00035  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.98326E-01 0.00063  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.01087E-01 0.00062  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.09310E+00 0.00230  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.09789E+01 0.00254  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.09789E+01 0.00254  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.74718E+01 0.00289  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  5.05683E+00 0.00519  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50064 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.00640E+02 0.00604 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.00640E+02 0.00604 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  8.34250E-01 ;
RUNNING_TIME              (idx, 1)        =  6.24550E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  5.73333E-03  2.58333E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  9.55333E-02  3.38000E-02  2.84500E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.68833E-02  8.40000E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  6.83335E-04  6.83335E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  6.24183E-01  1.21008E+00 ];
CPU_USAGE                 (idx, 1)        = 1.33576 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  4.01579E+00 0.00817 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  1.83972E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.13108E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.16437E+04 ;
TOT_SF_RATE               (idx, 1)        =  9.01594E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.33132E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  1.03507E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  9.97942E+16 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.06084E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  1.08118E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  1.81473E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  2.81673E+06 ;
ACTINIDE_ING_TOX          (idx, 1)        =  2.30302E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  7.99504E+06 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  1.58443E+07 ;
SR90_ACTIVITY             (idx, 1)        =  8.87232E+10 ;
TE132_ACTIVITY            (idx, 1)        =  1.99868E+14 ;
I131_ACTIVITY             (idx, 1)        =  5.09388E+13 ;
I132_ACTIVITY             (idx, 1)        =  1.99509E+14 ;
CS134_ACTIVITY            (idx, 1)        =  1.80454E+08 ;
CS137_ACTIVITY            (idx, 1)        =  9.26681E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  9.08497E+16 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.47108E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.70579E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.18723E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  9.88100E+13 0.00418  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 1 ;
BURNUP                     (idx, [1:  2])  = [  6.00000E+00  6.00741E+00 ];
BURN_DAYS                 (idx, 1)        =  1.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  4.13974E-01 0.01013 ];
U235_FISS                 (idx, [1:   4]) = [  2.26219E+16 0.00543  9.34130E-01 0.00173 ];
U238_FISS                 (idx, [1:   4]) = [  9.53148E+14 0.03274  3.93689E-02 0.03228 ];
PU239_FISS                (idx, [1:   4]) = [  5.88953E+14 0.04257  2.43166E-02 0.04131 ];
PU240_FISS                (idx, [1:   4]) = [  9.09256E+11 1.00000  4.09836E-05 1.00000 ];
PU241_FISS                (idx, [1:   4]) = [  2.75045E+13 0.18276  1.13085E-03 0.18141 ];
U235_CAPT                 (idx, [1:   4]) = [  4.37052E+15 0.01379  1.73310E-01 0.01320 ];
U238_CAPT                 (idx, [1:   4]) = [  1.12445E+16 0.00934  4.45382E-01 0.00700 ];
PU239_CAPT                (idx, [1:   4]) = [  2.94046E+14 0.06358  1.16136E-02 0.06316 ];
PU240_CAPT                (idx, [1:   4]) = [  2.15496E+14 0.07017  8.50225E-03 0.06950 ];
PU241_CAPT                (idx, [1:   4]) = [  8.76662E+12 0.31994  3.49536E-04 0.32041 ];
XE135_CAPT                (idx, [1:   4]) = [  1.57143E+15 0.02237  6.22725E-02 0.02177 ];
SM149_CAPT                (idx, [1:   4]) = [  5.86941E+13 0.12301  2.29257E-03 0.12090 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50064 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.76959E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50064 5.00577E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 25539 2.55415E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 24525 2.45162E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50064 5.00577E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 0.00000E+00 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  5.92334E+16 6.8E-05  5.92334E+16 6.8E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.40582E+16 9.1E-06  2.40582E+16 9.1E-06  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  2.51623E+16 0.00343  1.94940E+16 0.00421  5.66826E+15 0.00443 ];
TOT_ABSRATE               (idx, [1:   6]) = [  4.92205E+16 0.00175  4.35523E+16 0.00188  5.66826E+15 0.00443 ];
TOT_SRCRATE               (idx, [1:   6]) = [  4.94050E+16 0.00418  4.94050E+16 0.00418  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  3.01036E+18 0.00346  4.95465E+17 0.00389  2.51489E+18 0.00357 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  4.92205E+16 0.00175 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  2.02525E+18 0.00302 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29350E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29350E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.63222E+00 0.00340 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.62419E-01 0.00224 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.53261E-01 0.00256 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.13948E+00 0.00257 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.20738E+00 0.00392 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.20738E+00 0.00392 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.46208E+00 7.6E-05 ];
FISSE                     (idx, [1:   2]) = [  2.02596E+02 9.1E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.20522E+00 0.00417  1.19967E+00 0.00403  7.70470E-03 0.08019 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.20513E+00 0.00175 ];
COL_KEFF                  (idx, [1:   2]) = [  1.20102E+00 0.00419 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.20513E+00 0.00175 ];
ABS_KINF                  (idx, [1:   2]) = [  1.20513E+00 0.00175 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83573E+01 0.00140 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83695E+01 0.00056 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.20189E-07 0.02638 ];
IMP_EALF                  (idx, [1:   2]) = [  2.11622E-07 0.01034 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.29114E-01 0.03253 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.25104E-01 0.01221 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.65444E-03 0.05477  5.24856E-05 0.57209  1.00479E-03 0.15234  9.95309E-04 0.12986  2.66560E-03 0.07328  7.36442E-04 0.15135  1.99809E-04 0.27283 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  6.02326E-01 0.13753  3.74717E-04 0.57149  1.23706E-02 0.12571  4.73814E-02 0.11575  2.61600E-01 0.04713  4.71125E-01 0.13697  1.06322E+00 0.27266 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.67855E-03 0.08204  1.23138E-04 0.68885  1.41445E-03 0.20466  1.12431E-03 0.16551  2.95125E-03 0.11015  8.44020E-04 0.24411  2.21386E-04 0.37072 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  5.84009E-01 0.19682  1.24906E-02 0.0E+00  3.16928E-02 0.00233  1.10048E-01 0.00275  3.18861E-01 0.00204  1.34635E+00 0.00176  8.75844E+00 0.01394 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  4.47940E-05 0.00935  4.47837E-05 0.00946  3.07285E-05 0.12196 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  5.38964E-05 0.00841  5.38815E-05 0.00847  3.69508E-05 0.12289 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.54479E-03 0.07996  1.16644E-04 0.60303  1.23142E-03 0.18311  1.13592E-03 0.18935  2.88070E-03 0.12500  9.68297E-04 0.21529  2.11816E-04 0.46452 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  6.46677E-01 0.24176  1.24906E-02 0.0E+00  3.16312E-02 0.00339  1.10425E-01 0.00445  3.19748E-01 0.00357  1.34514E+00 0.00243  8.63638E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  4.55699E-05 0.01929  4.56570E-05 0.01952  8.13041E-06 0.25809 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  5.48083E-05 0.01860  5.49155E-05 0.01885  9.63923E-06 0.25660 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.11120E-03 0.25219  3.69757E-04 1.00000  1.28693E-03 0.69825  1.94475E-04 0.75498  3.18590E-03 0.33869  9.45065E-04 0.52326  1.29068E-04 1.00000 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  8.35445E-01 0.44032  1.24906E-02 0.0E+00  3.18241E-02 0.0E+00  1.12656E-01 0.02913  3.18727E-01 0.00597  1.35398E+00 5.9E-09  8.63638E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  5.88843E-03 0.24208  3.29218E-04 1.00000  1.11913E-03 0.68186  1.25978E-04 0.76932  3.05080E-03 0.33126  1.06196E-03 0.53439  2.01342E-04 1.00000 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  8.30728E-01 0.44268  1.24906E-02 0.0E+00  3.18241E-02 9.1E-09  1.12656E-01 0.02913  3.18701E-01 0.00598  1.35398E+00 5.9E-09  8.63638E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.36751E+02 0.27033 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  4.53769E-05 0.00515 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  5.45994E-05 0.00325 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.23759E-03 0.03641 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.37533E+02 0.03620 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.55312E-07 0.00364 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.37511E-06 0.00446  3.37490E-06 0.00444  3.21099E-06 0.06624 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.75114E-05 0.00443  5.75139E-05 0.00448  5.14384E-05 0.07137 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.53475E-01 0.00257  7.52552E-01 0.00260  1.25627E+00 0.10789 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  8.46068E+00 0.10514 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.09789E+01 0.00254  4.48536E+01 0.00362 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.53495E+03 0.03304  1.43356E+04 0.01677  3.24170E+04 0.01431  3.84605E+04 0.00756  3.71769E+04 0.00917  3.81963E+04 0.00395  2.60088E+04 0.01333  2.26075E+04 0.01196  1.72349E+04 0.00425  1.41493E+04 0.00273  1.22258E+04 0.00433  1.08810E+04 0.01259  1.02532E+04 0.01358  9.69198E+03 0.01093  9.66585E+03 0.00526  8.11056E+03 0.01525  8.02211E+03 0.01462  8.20488E+03 0.02395  8.03524E+03 0.01672  1.55388E+04 0.00540  1.50850E+04 0.01021  1.08068E+04 0.00980  7.29295E+03 0.01203  8.43712E+03 0.00614  8.14989E+03 0.01936  7.33076E+03 0.01590  1.22960E+04 0.01125  2.86116E+03 0.02285  3.53372E+03 0.02865  3.20552E+03 0.01253  1.82020E+03 0.02927  3.19686E+03 0.04152  2.24332E+03 0.00974  1.90456E+03 0.02239  3.62267E+02 0.07984  3.71974E+02 0.04203  3.86478E+02 0.05818  3.93967E+02 0.03607  3.76739E+02 0.05488  3.43939E+02 0.00765  3.61612E+02 0.03968  3.56966E+02 0.06101  7.20779E+02 0.03465  1.07325E+03 0.02700  1.35397E+03 0.01988  3.62652E+03 0.01997  3.82255E+03 0.02083  4.31126E+03 0.01040  3.09948E+03 0.03659  2.32420E+03 0.01007  1.78991E+03 0.01519  2.18919E+03 0.00968  4.26358E+03 0.01583  5.88371E+03 0.00992  1.14352E+04 0.00506  1.78456E+04 0.00777  2.74498E+04 0.00851  1.77723E+04 0.01098  1.26522E+04 0.00662  9.09743E+03 0.00768  8.08063E+03 0.01638  8.03799E+03 0.01517  6.76848E+03 0.00359  4.53365E+03 0.01032  4.13757E+03 0.00831  3.65015E+03 0.00698  3.12843E+03 0.01011  2.47259E+03 0.02551  1.63944E+03 0.02322  5.88052E+02 0.01368 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.20115E+00 0.00420 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  2.18682E+18 0.00331  8.24905E+17 0.00474 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73424E-01 0.00132  1.20187E+00 0.00241 ];
INF_CAPT                  (idx, [1:   4]) = [  4.36435E-03 0.00438  1.89579E-02 0.00349 ];
INF_ABS                   (idx, [1:   4]) = [  5.64674E-03 0.00388  4.47742E-02 0.00420 ];
INF_FISS                  (idx, [1:   4]) = [  1.28239E-03 0.00258  2.58162E-02 0.00474 ];
INF_NSF                   (idx, [1:   4]) = [  3.28535E-03 0.00259  6.32216E-02 0.00473 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.56190E+00 0.00076  2.44891E+00 2.9E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03851E+02 0.00012  2.02431E+02 4.7E-06 ];
INF_INVV                  (idx, [1:   4]) = [  6.36020E-08 0.00947  2.58955E-06 0.00173 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.67826E-01 0.00130  1.15675E+00 0.00234 ];
INF_SCATT1                (idx, [1:   4]) = [  2.22280E-01 0.00187  2.97100E-01 0.00393 ];
INF_SCATT2                (idx, [1:   4]) = [  8.88964E-02 0.00330  7.06839E-02 0.00386 ];
INF_SCATT3                (idx, [1:   4]) = [  6.58735E-03 0.01485  2.13986E-02 0.03167 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.34532E-03 0.01706 -6.47861E-03 0.05653 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.26549E-04 1.00000  5.43950E-03 0.02411 ];
INF_SCATT6                (idx, [1:   4]) = [  4.40697E-03 0.05057 -1.17602E-02 0.02293 ];
INF_SCATT7                (idx, [1:   4]) = [  6.43292E-04 0.11248  3.83630E-04 0.42631 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67852E-01 0.00130  1.15675E+00 0.00234 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.22279E-01 0.00186  2.97100E-01 0.00393 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.88963E-02 0.00330  7.06839E-02 0.00386 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.58647E-03 0.01490  2.13986E-02 0.03167 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.34525E-03 0.01709 -6.47861E-03 0.05653 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.26366E-04 1.00000  5.43950E-03 0.02411 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.40701E-03 0.05058 -1.17602E-02 0.02293 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.43639E-04 0.11065  3.83630E-04 0.42631 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95962E-01 0.00266  7.94509E-01 0.00217 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70105E+00 0.00265  4.19554E-01 0.00217 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.62066E-03 0.00387  4.47742E-02 0.00420 ];
INF_REMXS                 (idx, [1:   4]) = [  2.29018E-02 0.00219  4.58760E-02 0.00569 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50522E-01 0.00136  1.73037E-02 0.00129  7.59345E-04 0.03908  1.15599E+00 0.00232 ];
INF_S1                    (idx, [1:   8]) = [  2.17232E-01 0.00182  5.04771E-03 0.00549  3.63892E-04 0.04197  2.96736E-01 0.00394 ];
INF_S2                    (idx, [1:   8]) = [  9.03927E-02 0.00306 -1.49637E-03 0.02228  1.95308E-04 0.07573  7.04886E-02 0.00379 ];
INF_S3                    (idx, [1:   8]) = [  8.37815E-03 0.01113 -1.79080E-03 0.01688  6.13529E-05 0.25724  2.13373E-02 0.03161 ];
INF_S4                    (idx, [1:   8]) = [ -8.71385E-03 0.01695 -6.31470E-04 0.04121 -5.99031E-06 1.00000 -6.47262E-03 0.05502 ];
INF_S5                    (idx, [1:   8]) = [ -1.29601E-04 1.00000  3.05137E-06 1.00000 -1.63382E-05 0.83867  5.45584E-03 0.02431 ];
INF_S6                    (idx, [1:   8]) = [  4.52616E-03 0.04585 -1.19188E-04 0.19768 -3.39058E-05 0.25258 -1.17263E-02 0.02302 ];
INF_S7                    (idx, [1:   8]) = [  7.98552E-04 0.10550 -1.55260E-04 0.08646 -3.79260E-05 0.23764  4.21556E-04 0.38645 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50549E-01 0.00136  1.73037E-02 0.00129  7.59345E-04 0.03908  1.15599E+00 0.00232 ];
INF_SP1                   (idx, [1:   8]) = [  2.17231E-01 0.00182  5.04771E-03 0.00549  3.63892E-04 0.04197  2.96736E-01 0.00394 ];
INF_SP2                   (idx, [1:   8]) = [  9.03927E-02 0.00306 -1.49637E-03 0.02228  1.95308E-04 0.07573  7.04886E-02 0.00379 ];
INF_SP3                   (idx, [1:   8]) = [  8.37727E-03 0.01120 -1.79080E-03 0.01688  6.13529E-05 0.25724  2.13373E-02 0.03161 ];
INF_SP4                   (idx, [1:   8]) = [ -8.71379E-03 0.01699 -6.31470E-04 0.04121 -5.99031E-06 1.00000 -6.47262E-03 0.05502 ];
INF_SP5                   (idx, [1:   8]) = [ -1.29417E-04 1.00000  3.05137E-06 1.00000 -1.63382E-05 0.83867  5.45584E-03 0.02431 ];
INF_SP6                   (idx, [1:   8]) = [  4.52620E-03 0.04587 -1.19188E-04 0.19768 -3.39058E-05 0.25258 -1.17263E-02 0.02302 ];
INF_SP7                   (idx, [1:   8]) = [  7.98899E-04 0.10406 -1.55260E-04 0.08646 -3.79260E-05 0.23764  4.21556E-04 0.38645 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.03038E-01 0.00904  6.65070E-01 0.03574 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.03208E-01 0.01070  7.04044E-01 0.04832 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.04396E-01 0.00454  6.93762E-01 0.05359 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.01594E-01 0.01376  6.09616E-01 0.02113 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.64227E+00 0.00911  5.03754E-01 0.03552 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.64112E+00 0.01097  4.77870E-01 0.04789 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.63096E+00 0.00455  4.85604E-01 0.04954 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.65473E+00 0.01364  5.47787E-01 0.02148 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.67855E-03 0.08204  1.23138E-04 0.68885  1.41445E-03 0.20466  1.12431E-03 0.16551  2.95125E-03 0.11015  8.44020E-04 0.24411  2.21386E-04 0.37072 ];
LAMBDA                    (idx, [1:  14]) = [  5.84009E-01 0.19682  1.24906E-02 0.0E+00  3.16928E-02 0.00233  1.10048E-01 0.00275  3.18861E-01 0.00204  1.34635E+00 0.00176  8.75844E+00 0.01394 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:14 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00833E+00  1.00110E+00  1.00387E+00  9.86695E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  9.29405E-02 0.00402  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.07060E-01 0.00041  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.99961E-01 0.00067  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.02887E-01 0.00066  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.09941E+00 0.00242  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.34463E+01 0.00301  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.34463E+01 0.00301  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.83640E+01 0.00318  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  5.66832E+00 0.00615  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50180 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.01800E+02 0.00864 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.01800E+02 0.00864 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.12729E+00 ;
RUNNING_TIME              (idx, 1)        =  7.14483E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  1.18167E-02  3.05000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  1.62100E-01  3.64167E-02  3.01500E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  3.38000E-02  8.43333E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  1.35001E-03  6.66670E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  7.14117E-01  1.23562E+00 ];
CPU_USAGE                 (idx, 1)        = 1.57777 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.98906E+00 0.00768 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  2.83072E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.21350E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.24017E+04 ;
TOT_SF_RATE               (idx, 1)        =  1.14471E+02 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.80614E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  1.46944E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.03288E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.09320E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  1.69662E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  2.56638E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  5.29792E+06 ;
ACTINIDE_ING_TOX          (idx, 1)        =  4.16492E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.16682E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.14989E+07 ;
SR90_ACTIVITY             (idx, 1)        =  1.75242E+11 ;
TE132_ACTIVITY            (idx, 1)        =  3.64451E+14 ;
I131_ACTIVITY             (idx, 1)        =  9.98046E+13 ;
I132_ACTIVITY             (idx, 1)        =  4.01485E+14 ;
CS134_ACTIVITY            (idx, 1)        =  2.71297E+09 ;
CS137_ACTIVITY            (idx, 1)        =  1.86597E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  9.91489E+16 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.40512E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  6.06216E+08 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.34473E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.10678E+14 0.00419  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 2 ;
BURNUP                     (idx, [1:  2])  = [  1.20000E+01  1.20155E+01 ];
BURN_DAYS                 (idx, 1)        =  2.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  5.05536E-01 0.00908 ];
U235_FISS                 (idx, [1:   4]) = [  2.05630E+16 0.00661  8.54718E-01 0.00277 ];
U238_FISS                 (idx, [1:   4]) = [  1.03884E+15 0.03143  4.31654E-02 0.03062 ];
PU239_FISS                (idx, [1:   4]) = [  2.08156E+15 0.02283  8.65219E-02 0.02226 ];
PU240_FISS                (idx, [1:   4]) = [  1.03336E+12 1.00000  4.14938E-05 1.00000 ];
PU241_FISS                (idx, [1:   4]) = [  3.36626E+14 0.05507  1.39463E-02 0.05383 ];
U235_CAPT                 (idx, [1:   4]) = [  4.02199E+15 0.01556  1.28173E-01 0.01358 ];
U238_CAPT                 (idx, [1:   4]) = [  1.31361E+16 0.00820  4.19179E-01 0.00684 ];
PU239_CAPT                (idx, [1:   4]) = [  1.08343E+15 0.03343  3.44808E-02 0.03236 ];
PU240_CAPT                (idx, [1:   4]) = [  1.02086E+15 0.03301  3.25617E-02 0.03268 ];
PU241_CAPT                (idx, [1:   4]) = [  1.34367E+14 0.09037  4.26883E-03 0.08930 ];
XE135_CAPT                (idx, [1:   4]) = [  1.60127E+15 0.02770  5.10140E-02 0.02654 ];
SM149_CAPT                (idx, [1:   4]) = [  8.50151E+13 0.10963  2.70730E-03 0.10861 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50180 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 7.43356E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50180 5.00743E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 28412 2.83305E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 21768 2.17439E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50180 5.00743E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -5.09317E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  5.99317E+16 9.4E-05  5.99317E+16 9.4E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.40025E+16 1.1E-05  2.40025E+16 1.1E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  3.16651E+16 0.00286  2.45814E+16 0.00349  7.08371E+15 0.00431 ];
TOT_ABSRATE               (idx, [1:   6]) = [  5.56676E+16 0.00163  4.85839E+16 0.00177  7.08371E+15 0.00431 ];
TOT_SRCRATE               (idx, [1:   6]) = [  5.53389E+16 0.00419  5.53389E+16 0.00419  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  3.48741E+18 0.00342  5.75519E+17 0.00384  2.91189E+18 0.00352 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  5.56676E+16 0.00163 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  2.40552E+18 0.00279 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.28541E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.28541E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.50722E+00 0.00459 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.52839E-01 0.00221 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.48763E-01 0.00216 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.12885E+00 0.00241 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.08592E+00 0.00510 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.08592E+00 0.00510 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.49689E+00 0.00010 ];
FISSE                     (idx, [1:   2]) = [  2.03067E+02 1.1E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.08440E+00 0.00533  1.07824E+00 0.00508  7.68689E-03 0.07390 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.07826E+00 0.00164 ];
COL_KEFF                  (idx, [1:   2]) = [  1.08484E+00 0.00413 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.07826E+00 0.00164 ];
ABS_KINF                  (idx, [1:   2]) = [  1.07826E+00 0.00164 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83316E+01 0.00137 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83279E+01 0.00055 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.25501E-07 0.02512 ];
IMP_EALF                  (idx, [1:   2]) = [  2.20548E-07 0.01005 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.38768E-01 0.03402 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.44299E-01 0.01423 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.90831E-03 0.05223  2.03929E-04 0.28719  9.43799E-04 0.13473  9.67589E-04 0.12035  2.82444E-03 0.07898  7.89865E-04 0.15790  1.78691E-04 0.30313 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  6.28366E-01 0.17192  1.39613E-03 0.28606  1.32376E-02 0.11815  4.95359E-02 0.11114  2.58982E-01 0.04873  4.44029E-01 0.14322  8.63638E-01 0.30151 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.99617E-03 0.06790  1.68607E-04 0.41121  1.13602E-03 0.23838  1.21099E-03 0.15822  3.25781E-03 0.11192  9.38406E-04 0.20923  2.84331E-04 0.39986 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.70866E-01 0.21289  1.26921E-02 0.01065  3.15129E-02 0.00337  1.10092E-01 0.00265  3.19844E-01 0.00251  1.34532E+00 0.00191  8.63638E+00 3.9E-09 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  5.66527E-05 0.01161  5.65765E-05 0.01168  4.58157E-05 0.12718 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  6.12018E-05 0.00924  6.11225E-05 0.00938  4.97143E-05 0.12569 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.99121E-03 0.07278  2.51366E-04 0.44433  8.29580E-04 0.23533  9.72747E-04 0.19920  3.70683E-03 0.10428  9.25504E-04 0.21948  3.05184E-04 0.37056 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.51276E-01 0.21580  1.27122E-02 0.01744  3.15109E-02 0.00539  1.09270E-01 0.00097  3.19346E-01 0.00276  1.34595E+00 0.00242  8.63638E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  5.55895E-05 0.02461  5.56690E-05 0.02485  1.09665E-05 0.33173 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  6.00171E-05 0.02292  6.00967E-05 0.02311  1.21681E-05 0.34180 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.36273E-03 0.27603  2.19765E-04 0.88261  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  5.00463E-03 0.32904  1.13833E-03 0.55509  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  4.73260E-01 0.19159  1.24906E-02 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.19241E-01 0.00710  1.35398E+00 1.2E-08  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.11445E-03 0.28377  3.56466E-04 0.73665  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  4.63786E-03 0.34721  1.12012E-03 0.60484  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  4.78566E-01 0.19329  1.24906E-02 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.19310E-01 0.00706  1.35398E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.15579E+02 0.27492 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  5.63477E-05 0.00641 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  6.09328E-05 0.00357 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.87198E-03 0.05166 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.22845E+02 0.05256 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  8.22613E-07 0.00435 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.33214E-06 0.00491  3.33418E-06 0.00494  2.85647E-06 0.06735 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  6.56526E-05 0.00541  6.56380E-05 0.00545  6.83037E-05 0.07857 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.48973E-01 0.00215  7.48384E-01 0.00222  1.13021E+00 0.09683 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  9.71140E+00 0.11361 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.34463E+01 0.00301  4.78993E+01 0.00419 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.62002E+03 0.03052  1.52254E+04 0.01095  3.22421E+04 0.01049  3.79962E+04 0.00937  3.68119E+04 0.00461  3.91079E+04 0.00534  2.61656E+04 0.00537  2.25183E+04 0.01253  1.72788E+04 0.00912  1.40146E+04 0.01191  1.21715E+04 0.01268  1.11302E+04 0.00722  1.00337E+04 0.00910  9.86186E+03 0.00751  9.58060E+03 0.00987  8.17059E+03 0.01052  8.16951E+03 0.01109  8.02404E+03 0.00906  7.86303E+03 0.01125  1.54654E+04 0.00436  1.50294E+04 0.01026  1.10186E+04 0.00571  7.26604E+03 0.01123  8.39303E+03 0.01019  8.08128E+03 0.01015  7.33405E+03 0.01002  1.23602E+04 0.01083  2.78587E+03 0.02041  3.54722E+03 0.01221  3.26138E+03 0.01721  1.90179E+03 0.01276  3.26333E+03 0.01665  2.23012E+03 0.01764  1.96272E+03 0.03255  3.59265E+02 0.04280  3.26080E+02 0.03883  3.27628E+02 0.02784  3.22276E+02 0.02364  3.18169E+02 0.04727  3.20253E+02 0.06585  3.63601E+02 0.04588  3.27578E+02 0.02643  5.95007E+02 0.02623  1.07158E+03 0.04044  1.33335E+03 0.03589  3.61511E+03 0.01778  3.93694E+03 0.01841  4.41487E+03 0.02428  3.14055E+03 0.01832  2.39581E+03 0.01731  1.91763E+03 0.00977  2.33677E+03 0.01142  4.51325E+03 0.01776  6.15444E+03 0.01543  1.25260E+04 0.00432  2.02171E+04 0.00793  3.09218E+04 0.00589  2.02016E+04 0.00228  1.44590E+04 0.00838  1.03303E+04 0.00609  9.37463E+03 0.01870  9.32420E+03 0.00568  7.82522E+03 0.01315  5.22467E+03 0.00647  4.84384E+03 0.00986  4.32435E+03 0.01045  3.59457E+03 0.00635  2.82875E+03 0.01881  1.88248E+03 0.01804  6.80187E+02 0.03172 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.08488E+00 0.00559 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  2.45243E+18 0.00555  1.03681E+18 0.00281 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73357E-01 0.00072  1.20252E+00 0.00161 ];
INF_CAPT                  (idx, [1:   4]) = [  4.71452E-03 0.00714  1.94158E-02 0.00226 ];
INF_ABS                   (idx, [1:   4]) = [  5.79478E-03 0.00626  4.00488E-02 0.00279 ];
INF_FISS                  (idx, [1:   4]) = [  1.08026E-03 0.00358  2.06330E-02 0.00332 ];
INF_NSF                   (idx, [1:   4]) = [  2.81116E-03 0.00414  5.12485E-02 0.00337 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.60227E+00 0.00071  2.48381E+00 6.8E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.04306E+02 5.9E-05  2.02913E+02 1.1E-05 ];
INF_INVV                  (idx, [1:   4]) = [  6.30524E-08 0.00369  2.62031E-06 0.00161 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.67655E-01 0.00071  1.16256E+00 0.00163 ];
INF_SCATT1                (idx, [1:   4]) = [  2.21902E-01 0.00170  2.97699E-01 0.00228 ];
INF_SCATT2                (idx, [1:   4]) = [  8.85688E-02 0.00123  7.00193E-02 0.00808 ];
INF_SCATT3                (idx, [1:   4]) = [  6.56857E-03 0.02497  2.16759E-02 0.01401 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.29296E-03 0.02307 -6.37733E-03 0.06149 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.31599E-04 1.00000  5.06538E-03 0.04959 ];
INF_SCATT6                (idx, [1:   4]) = [  4.29916E-03 0.03597 -1.27259E-02 0.02020 ];
INF_SCATT7                (idx, [1:   4]) = [  6.74974E-04 0.12656  6.62181E-04 0.37269 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67688E-01 0.00070  1.16256E+00 0.00163 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.21910E-01 0.00169  2.97699E-01 0.00228 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.85726E-02 0.00121  7.00193E-02 0.00808 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.57012E-03 0.02485  2.16759E-02 0.01401 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.29292E-03 0.02304 -6.37733E-03 0.06149 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.33398E-04 1.00000  5.06538E-03 0.04959 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.29792E-03 0.03612 -1.27259E-02 0.02020 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.76011E-04 0.12746  6.62181E-04 0.37269 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95343E-01 0.00247  7.97769E-01 0.00297 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70644E+00 0.00247  4.17847E-01 0.00298 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.76123E-03 0.00600  4.00488E-02 0.00279 ];
INF_REMXS                 (idx, [1:   4]) = [  2.28850E-02 0.00173  4.06420E-02 0.00310 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50472E-01 0.00070  1.71830E-02 0.00318  6.78764E-04 0.04254  1.16188E+00 0.00161 ];
INF_S1                    (idx, [1:   8]) = [  2.16790E-01 0.00174  5.11225E-03 0.00384  3.38869E-04 0.04670  2.97360E-01 0.00223 ];
INF_S2                    (idx, [1:   8]) = [  9.00120E-02 0.00155 -1.44322E-03 0.03084  1.82871E-04 0.09427  6.98365E-02 0.00812 ];
INF_S3                    (idx, [1:   8]) = [  8.30704E-03 0.02293 -1.73848E-03 0.02728  6.59105E-05 0.19401  2.16100E-02 0.01425 ];
INF_S4                    (idx, [1:   8]) = [ -8.75519E-03 0.02571 -5.37773E-04 0.04188  2.84779E-06 1.00000 -6.38018E-03 0.06149 ];
INF_S5                    (idx, [1:   8]) = [ -1.64505E-04 1.00000  3.29061E-05 0.90430 -2.08534E-05 0.52573  5.08623E-03 0.04854 ];
INF_S6                    (idx, [1:   8]) = [  4.48268E-03 0.03230 -1.83511E-04 0.10353 -3.20669E-05 0.28527 -1.26938E-02 0.02045 ];
INF_S7                    (idx, [1:   8]) = [  8.61271E-04 0.09002 -1.86296E-04 0.07423 -3.01159E-05 0.26391  6.92297E-04 0.35911 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50505E-01 0.00070  1.71830E-02 0.00318  6.78764E-04 0.04254  1.16188E+00 0.00161 ];
INF_SP1                   (idx, [1:   8]) = [  2.16798E-01 0.00173  5.11225E-03 0.00384  3.38869E-04 0.04670  2.97360E-01 0.00223 ];
INF_SP2                   (idx, [1:   8]) = [  9.00158E-02 0.00154 -1.44322E-03 0.03084  1.82871E-04 0.09427  6.98365E-02 0.00812 ];
INF_SP3                   (idx, [1:   8]) = [  8.30860E-03 0.02281 -1.73848E-03 0.02728  6.59105E-05 0.19401  2.16100E-02 0.01425 ];
INF_SP4                   (idx, [1:   8]) = [ -8.75515E-03 0.02569 -5.37773E-04 0.04188  2.84779E-06 1.00000 -6.38018E-03 0.06149 ];
INF_SP5                   (idx, [1:   8]) = [ -1.66305E-04 1.00000  3.29061E-05 0.90430 -2.08534E-05 0.52573  5.08623E-03 0.04854 ];
INF_SP6                   (idx, [1:   8]) = [  4.48143E-03 0.03245 -1.83511E-04 0.10353 -3.20669E-05 0.28527 -1.26938E-02 0.02045 ];
INF_SP7                   (idx, [1:   8]) = [  8.62307E-04 0.09076 -1.86296E-04 0.07423 -3.01159E-05 0.26391  6.92297E-04 0.35911 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.02272E-01 0.00621  6.15900E-01 0.03271 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.03113E-01 0.01299  6.26684E-01 0.04280 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.04740E-01 0.00415  6.36730E-01 0.02026 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  1.99224E-01 0.01250  5.89765E-01 0.04632 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.64820E+00 0.00623  5.43595E-01 0.03354 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.64222E+00 0.01290  5.35967E-01 0.04434 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.62819E+00 0.00412  5.24402E-01 0.02104 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.67419E+00 0.01226  5.70417E-01 0.04953 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.99617E-03 0.06790  1.68607E-04 0.41121  1.13602E-03 0.23838  1.21099E-03 0.15822  3.25781E-03 0.11192  9.38406E-04 0.20923  2.84331E-04 0.39986 ];
LAMBDA                    (idx, [1:  14]) = [  7.70866E-01 0.21289  1.26921E-02 0.01065  3.15129E-02 0.00337  1.10092E-01 0.00265  3.19844E-01 0.00251  1.34532E+00 0.00191  8.63638E+00 3.9E-09 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:19 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00699E+00  1.00258E+00  1.00045E+00  9.89986E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  9.76410E-02 0.00389  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.02359E-01 0.00042  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.99178E-01 0.00071  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.02191E-01 0.00069  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.12879E+00 0.00239  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.53038E+01 0.00344  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.53038E+01 0.00344  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.92111E+01 0.00328  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  6.26469E+00 0.00617  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50236 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.02360E+02 0.00957 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.02360E+02 0.00957 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.42690E+00 ;
RUNNING_TIME              (idx, 1)        =  8.06150E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  1.80833E-02  3.11667E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  2.30267E-01  3.69667E-02  3.12000E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  5.06333E-02  8.36667E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  2.01667E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  8.05800E-01  1.25872E+00 ];
CPU_USAGE                 (idx, 1)        = 1.77002 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  4.00291E+00 0.00725 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  3.61409E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.27194E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.22321E+04 ;
TOT_SF_RATE               (idx, 1)        =  2.67204E+02 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  2.34663E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  1.98724E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.03727E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.02445E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  2.20230E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  3.06391E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  7.77956E+06 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.92691E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.42434E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.47122E+07 ;
SR90_ACTIVITY             (idx, 1)        =  2.55642E+11 ;
TE132_ACTIVITY            (idx, 1)        =  4.99085E+14 ;
I131_ACTIVITY             (idx, 1)        =  1.42922E+14 ;
I132_ACTIVITY             (idx, 1)        =  5.85755E+14 ;
CS134_ACTIVITY            (idx, 1)        =  1.31983E+10 ;
CS137_ACTIVITY            (idx, 1)        =  2.80659E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.05146E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.27171E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.31876E+09 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.47736E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.29688E+14 0.00471  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 3 ;
BURNUP                     (idx, [1:  2])  = [  1.80000E+01  1.80237E+01 ];
BURN_DAYS                 (idx, 1)        =  3.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  6.44207E-01 0.01118 ];
U235_FISS                 (idx, [1:   4]) = [  1.77124E+16 0.00754  7.33658E-01 0.00439 ];
U238_FISS                 (idx, [1:   4]) = [  1.27694E+15 0.02797  5.27872E-02 0.02634 ];
PU239_FISS                (idx, [1:   4]) = [  3.93003E+15 0.01873  1.62805E-01 0.01785 ];
PU240_FISS                (idx, [1:   4]) = [  1.00995E+12 1.00000  4.54545E-05 1.00000 ];
PU241_FISS                (idx, [1:   4]) = [  1.14006E+15 0.03275  4.73240E-02 0.03290 ];
U235_CAPT                 (idx, [1:   4]) = [  3.44833E+15 0.02030  8.46550E-02 0.01959 ];
U238_CAPT                 (idx, [1:   4]) = [  1.61128E+16 0.01058  3.94870E-01 0.00721 ];
PU239_CAPT                (idx, [1:   4]) = [  2.04370E+15 0.02551  5.01749E-02 0.02474 ];
PU240_CAPT                (idx, [1:   4]) = [  2.19417E+15 0.02524  5.39281E-02 0.02527 ];
PU241_CAPT                (idx, [1:   4]) = [  3.71534E+14 0.06307  9.14289E-03 0.06377 ];
XE135_CAPT                (idx, [1:   4]) = [  1.75294E+15 0.02728  4.30484E-02 0.02673 ];
SM149_CAPT                (idx, [1:   4]) = [  7.40160E+13 0.12099  1.81822E-03 0.12005 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50236 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 6.02549E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50236 5.00603E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 31547 3.14269E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 18689 1.86333E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50236 5.00603E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 0.00000E+00 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.10084E+16 0.00010  6.10084E+16 0.00010  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.39112E+16 1.6E-05  2.39112E+16 1.6E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  4.08144E+16 0.00320  3.18769E+16 0.00371  8.93752E+15 0.00415 ];
TOT_ABSRATE               (idx, [1:   6]) = [  6.47256E+16 0.00202  5.57881E+16 0.00212  8.93752E+15 0.00415 ];
TOT_SRCRATE               (idx, [1:   6]) = [  6.48440E+16 0.00471  6.48440E+16 0.00471  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  4.18213E+18 0.00375  6.88774E+17 0.00396  3.49336E+18 0.00384 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  6.47256E+16 0.00202 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  2.93748E+18 0.00315 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.27734E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.27734E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.37339E+00 0.00533 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.31125E-01 0.00255 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.37782E-01 0.00273 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.12984E+00 0.00257 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  9.50845E-01 0.00594 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  9.50845E-01 0.00594 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.55145E+00 0.00012 ];
FISSE                     (idx, [1:   2]) = [  2.03842E+02 1.6E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  9.51310E-01 0.00626  9.45056E-01 0.00597  5.78923E-03 0.08906 ];
IMP_KEFF                  (idx, [1:   2]) = [  9.44096E-01 0.00202 ];
COL_KEFF                  (idx, [1:   2]) = [  9.42863E-01 0.00459 ];
ABS_KEFF                  (idx, [1:   2]) = [  9.44096E-01 0.00202 ];
ABS_KINF                  (idx, [1:   2]) = [  9.44096E-01 0.00202 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.81941E+01 0.00156 ];
IMP_ALF                   (idx, [1:   2]) = [  1.82084E+01 0.00060 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.61380E-07 0.03027 ];
IMP_EALF                  (idx, [1:   2]) = [  2.48783E-07 0.01119 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.74503E-01 0.02981 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.72263E-01 0.01157 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  6.65778E-03 0.06431  1.88441E-04 0.32068  1.27815E-03 0.11719  1.14977E-03 0.12479  2.98056E-03 0.09716  7.61418E-04 0.18487  2.99440E-04 0.25068 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  6.54600E-01 0.14555  1.12419E-03 0.31958  1.50647E-02 0.10466  4.85848E-02 0.11343  2.20394E-01 0.06742  3.80679E-01 0.15820  1.21554E+00 0.25449 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  5.91061E-03 0.08285  6.89172E-05 0.42189  1.22649E-03 0.17375  1.02493E-03 0.17285  2.65704E-03 0.11956  7.21972E-04 0.24607  2.11267E-04 0.33014 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.22814E-01 0.20582  1.24910E-02 3.3E-05  3.14299E-02 0.00338  1.10391E-01 0.00351  3.19765E-01 0.00296  1.31246E+00 0.01745  8.67937E+00 0.05012 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  7.09697E-05 0.01270  7.10080E-05 0.01280  3.92529E-05 0.14208 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  6.72380E-05 0.01079  6.72720E-05 0.01086  3.71843E-05 0.14052 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.03267E-03 0.08843  1.55471E-04 0.57468  1.19516E-03 0.21847  9.26143E-04 0.25132  2.72881E-03 0.12457  7.93528E-04 0.27200  2.33550E-04 0.49363 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  8.00138E-01 0.27662  1.24906E-02 0.0E+00  3.13329E-02 0.00572  1.10517E-01 0.00651  3.19794E-01 0.00400  1.31513E+00 0.02823  8.63638E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  7.14113E-05 0.02121  7.15900E-05 0.02127  1.28342E-05 0.31760 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  6.76703E-05 0.02029  6.78342E-05 0.02033  1.23035E-05 0.32012 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  6.95052E-03 0.28305  0.00000E+00 0.0E+00  1.15114E-03 0.46752  9.50743E-04 0.51288  3.46368E-03 0.44271  1.28143E-03 0.75317  1.03523E-04 1.00000 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  7.82415E-01 0.54301  0.00000E+00 0.0E+00  3.15103E-02 0.00996  1.10688E-01 0.01186  3.17610E-01 0.01050  1.35398E+00 0.0E+00  8.63638E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  6.98363E-03 0.28854  0.00000E+00 0.0E+00  1.20482E-03 0.48629  9.91613E-04 0.50728  3.21573E-03 0.45301  1.47246E-03 0.75873  9.90099E-05 1.00000 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.80329E-01 0.54467  0.00000E+00 0.0E+00  3.15103E-02 0.00996  1.10688E-01 0.01186  3.17610E-01 0.01050  1.35398E+00 1.3E-08  8.63638E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.06148E+02 0.27835 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  7.13152E-05 0.00740 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  6.75810E-05 0.00387 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.19895E-03 0.04920 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -8.74710E+01 0.04987 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  8.76548E-07 0.00400 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.29683E-06 0.00460  3.29494E-06 0.00456  3.09176E-06 0.08430 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  7.33034E-05 0.00509  7.33190E-05 0.00506  6.00290E-05 0.07318 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.38001E-01 0.00272  7.38282E-01 0.00280  8.92602E-01 0.10052 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.27991E+01 0.14820 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.53038E+01 0.00344  5.01234E+01 0.00513 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.84382E+03 0.02066  1.51729E+04 0.01612  3.31435E+04 0.00320  3.77323E+04 0.00930  3.66056E+04 0.01130  3.80942E+04 0.00832  2.62231E+04 0.00999  2.25119E+04 0.01035  1.71976E+04 0.01264  1.40868E+04 0.01305  1.23250E+04 0.01314  1.07006E+04 0.00653  1.01005E+04 0.01419  9.53604E+03 0.00543  9.49419E+03 0.00760  8.09810E+03 0.01160  7.98813E+03 0.01263  8.10128E+03 0.01183  7.77130E+03 0.01174  1.53308E+04 0.00455  1.53893E+04 0.01064  1.09527E+04 0.00561  7.39698E+03 0.01071  8.68040E+03 0.00782  8.05988E+03 0.01268  7.25352E+03 0.00752  1.23715E+04 0.00613  2.82863E+03 0.01950  3.55238E+03 0.02702  3.29611E+03 0.02396  1.85449E+03 0.02967  3.14653E+03 0.02914  2.19375E+03 0.01664  1.89402E+03 0.02031  3.39145E+02 0.04684  3.18470E+02 0.01831  2.88566E+02 0.06139  2.72632E+02 0.01342  3.11683E+02 0.00761  3.12128E+02 0.03395  3.62250E+02 0.03614  3.16366E+02 0.07009  6.41284E+02 0.04830  1.02127E+03 0.02147  1.33116E+03 0.02311  3.45804E+03 0.01192  3.84763E+03 0.01832  4.32265E+03 0.01790  3.07377E+03 0.01942  2.51022E+03 0.01433  1.94478E+03 0.03207  2.40690E+03 0.01766  4.66353E+03 0.01342  6.70822E+03 0.01561  1.36163E+04 0.00818  2.17367E+04 0.01109  3.38072E+04 0.00669  2.19775E+04 0.01279  1.59479E+04 0.00585  1.16666E+04 0.00618  1.02658E+04 0.00502  1.02546E+04 0.01149  8.61145E+03 0.01404  5.76424E+03 0.00996  5.41739E+03 0.00784  4.82855E+03 0.01016  4.05992E+03 0.01690  3.16555E+03 0.00660  2.15627E+03 0.02165  7.55978E+02 0.02706 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  9.42866E-01 0.00581 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  2.86530E+18 0.00449  1.31949E+18 0.00382 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73344E-01 0.00170  1.20075E+00 0.00087 ];
INF_CAPT                  (idx, [1:   4]) = [  5.04835E-03 0.01143  2.00103E-02 0.00245 ];
INF_ABS                   (idx, [1:   4]) = [  5.95598E-03 0.00991  3.61986E-02 0.00305 ];
INF_FISS                  (idx, [1:   4]) = [  9.07628E-04 0.00385  1.61883E-02 0.00381 ];
INF_NSF                   (idx, [1:   4]) = [  2.40815E-03 0.00459  4.11022E-02 0.00382 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.65321E+00 0.00076  2.53901E+00 5.6E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.04916E+02 3.7E-05  2.03711E+02 9.8E-06 ];
INF_INVV                  (idx, [1:   4]) = [  6.24755E-08 0.00485  2.64573E-06 0.00125 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.67382E-01 0.00169  1.16450E+00 0.00098 ];
INF_SCATT1                (idx, [1:   4]) = [  2.22273E-01 0.00301  2.95851E-01 0.00190 ];
INF_SCATT2                (idx, [1:   4]) = [  8.86763E-02 0.00203  6.95247E-02 0.00341 ];
INF_SCATT3                (idx, [1:   4]) = [  6.37345E-03 0.01653  2.10113E-02 0.03214 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.34227E-03 0.02024 -6.35680E-03 0.06220 ];
INF_SCATT5                (idx, [1:   4]) = [ -9.47970E-05 1.00000  5.02008E-03 0.05259 ];
INF_SCATT6                (idx, [1:   4]) = [  4.36979E-03 0.04289 -1.32624E-02 0.02471 ];
INF_SCATT7                (idx, [1:   4]) = [  5.35853E-04 0.25366  1.61209E-05 1.00000 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67409E-01 0.00169  1.16450E+00 0.00098 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.22273E-01 0.00301  2.95851E-01 0.00190 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.86757E-02 0.00202  6.95247E-02 0.00341 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.37460E-03 0.01657  2.10113E-02 0.03214 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.34142E-03 0.02027 -6.35680E-03 0.06220 ];
INF_SCATTP5               (idx, [1:   4]) = [ -9.60349E-05 1.00000  5.02008E-03 0.05259 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.37043E-03 0.04284 -1.32624E-02 0.02471 ];
INF_SCATTP7               (idx, [1:   4]) = [  5.36071E-04 0.25292  1.61209E-05 1.00000 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.94791E-01 0.00118  8.01353E-01 0.00098 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.71124E+00 0.00118  4.15965E-01 0.00098 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.92870E-03 0.00972  3.61986E-02 0.00305 ];
INF_REMXS                 (idx, [1:   4]) = [  2.29161E-02 0.00332  3.68166E-02 0.00389 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50428E-01 0.00166  1.69542E-02 0.00245  5.60457E-04 0.04378  1.16394E+00 0.00098 ];
INF_S1                    (idx, [1:   8]) = [  2.17274E-01 0.00297  4.99856E-03 0.00784  2.83088E-04 0.05579  2.95567E-01 0.00192 ];
INF_S2                    (idx, [1:   8]) = [  9.01300E-02 0.00178 -1.45373E-03 0.02604  1.61599E-04 0.07176  6.93631E-02 0.00332 ];
INF_S3                    (idx, [1:   8]) = [  8.11134E-03 0.01358 -1.73788E-03 0.01618  7.66494E-05 0.19993  2.09347E-02 0.03237 ];
INF_S4                    (idx, [1:   8]) = [ -8.74804E-03 0.02017 -5.94234E-04 0.02864  1.04628E-05 0.84687 -6.36726E-03 0.06280 ];
INF_S5                    (idx, [1:   8]) = [ -9.76171E-05 1.00000  2.82007E-06 1.00000 -2.63280E-05 0.34391  5.04640E-03 0.05147 ];
INF_S6                    (idx, [1:   8]) = [  4.49756E-03 0.03821 -1.27773E-04 0.18724 -2.73670E-05 0.32901 -1.32350E-02 0.02454 ];
INF_S7                    (idx, [1:   8]) = [  6.89743E-04 0.19393 -1.53890E-04 0.09860 -3.44743E-05 0.30227  5.05952E-05 1.00000 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50455E-01 0.00166  1.69542E-02 0.00245  5.60457E-04 0.04378  1.16394E+00 0.00098 ];
INF_SP1                   (idx, [1:   8]) = [  2.17275E-01 0.00296  4.99856E-03 0.00784  2.83088E-04 0.05579  2.95567E-01 0.00192 ];
INF_SP2                   (idx, [1:   8]) = [  9.01295E-02 0.00177 -1.45373E-03 0.02604  1.61599E-04 0.07176  6.93631E-02 0.00332 ];
INF_SP3                   (idx, [1:   8]) = [  8.11249E-03 0.01360 -1.73788E-03 0.01618  7.66494E-05 0.19993  2.09347E-02 0.03237 ];
INF_SP4                   (idx, [1:   8]) = [ -8.74719E-03 0.02021 -5.94234E-04 0.02864  1.04628E-05 0.84687 -6.36726E-03 0.06280 ];
INF_SP5                   (idx, [1:   8]) = [ -9.88549E-05 1.00000  2.82007E-06 1.00000 -2.63280E-05 0.34391  5.04640E-03 0.05147 ];
INF_SP6                   (idx, [1:   8]) = [  4.49821E-03 0.03816 -1.27773E-04 0.18724 -2.73670E-05 0.32901 -1.32350E-02 0.02454 ];
INF_SP7                   (idx, [1:   8]) = [  6.89962E-04 0.19345 -1.53890E-04 0.09860 -3.44743E-05 0.30227  5.05952E-05 1.00000 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.01699E-01 0.00900  6.42505E-01 0.02587 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.02501E-01 0.01268  6.67012E-01 0.02352 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.02543E-01 0.00878  6.49773E-01 0.04050 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.00123E-01 0.00820  6.16264E-01 0.03251 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.65316E+00 0.00888  5.20195E-01 0.02588 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.64714E+00 0.01267  5.00887E-01 0.02434 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.64624E+00 0.00861  5.16497E-01 0.04181 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.66609E+00 0.00820  5.43200E-01 0.03269 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  5.91061E-03 0.08285  6.89172E-05 0.42189  1.22649E-03 0.17375  1.02493E-03 0.17285  2.65704E-03 0.11956  7.21972E-04 0.24607  2.11267E-04 0.33014 ];
LAMBDA                    (idx, [1:  14]) = [  7.22814E-01 0.20582  1.24910E-02 3.3E-05  3.14299E-02 0.00338  1.10391E-01 0.00351  3.19765E-01 0.00296  1.31246E+00 0.01745  8.67937E+00 0.05012 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:25 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.01409E+00  1.00492E+00  9.96169E-01  9.84821E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.02447E-01 0.00361  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  8.97553E-01 0.00041  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.98327E-01 0.00065  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.01521E-01 0.00064  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.14030E+00 0.00268  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.76131E+01 0.00338  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.76131E+01 0.00338  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  2.02556E+01 0.00325  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  6.94804E+00 0.00601  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50227 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.02270E+02 0.00955 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.02270E+02 0.00955 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.73476E+00 ;
RUNNING_TIME              (idx, 1)        =  8.99917E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  2.43667E-02  3.13333E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.00467E-01  3.84167E-02  3.17833E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  6.75333E-02  8.43333E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  2.68334E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  8.99567E-01  1.26710E+00 ];
CPU_USAGE                 (idx, 1)        = 1.92769 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  4.00103E+00 0.00774 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  4.25188E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.34186E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.20954E+04 ;
TOT_SF_RATE               (idx, 1)        =  1.20662E+03 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  3.06377E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  2.70656E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.03548E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.93884E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  2.66957E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  3.45386E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.04801E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  7.80156E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.62157E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.67370E+07 ;
SR90_ACTIVITY             (idx, 1)        =  3.27064E+11 ;
TE132_ACTIVITY            (idx, 1)        =  6.09327E+14 ;
I131_ACTIVITY             (idx, 1)        =  1.79051E+14 ;
I132_ACTIVITY             (idx, 1)        =  7.63761E+14 ;
CS134_ACTIVITY            (idx, 1)        =  3.99621E+10 ;
CS137_ACTIVITY            (idx, 1)        =  3.74625E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.11448E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.12016E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.76748E+09 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.62425E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.57217E+14 0.00487  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 4 ;
BURNUP                     (idx, [1:  2])  = [  2.40000E+01  2.40321E+01 ];
BURN_DAYS                 (idx, 1)        =  4.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  8.64999E-01 0.01111 ];
U235_FISS                 (idx, [1:   4]) = [  1.36148E+16 0.00994  5.73006E-01 0.00678 ];
U238_FISS                 (idx, [1:   4]) = [  1.48308E+15 0.03330  6.21662E-02 0.03111 ];
PU239_FISS                (idx, [1:   4]) = [  5.86066E+15 0.01496  2.46772E-01 0.01335 ];
PU240_FISS                (idx, [1:   4]) = [  2.29875E+13 0.25917  9.58750E-04 0.25697 ];
PU241_FISS                (idx, [1:   4]) = [  2.66433E+15 0.02168  1.12312E-01 0.02106 ];
U235_CAPT                 (idx, [1:   4]) = [  2.51992E+15 0.02089  4.60390E-02 0.02184 ];
U238_CAPT                 (idx, [1:   4]) = [  2.05888E+16 0.00986  3.74578E-01 0.00688 ];
PU239_CAPT                (idx, [1:   4]) = [  3.18966E+15 0.02024  5.81755E-02 0.02030 ];
PU240_CAPT                (idx, [1:   4]) = [  4.15746E+15 0.01996  7.55903E-02 0.01838 ];
PU241_CAPT                (idx, [1:   4]) = [  9.73698E+14 0.04227  1.77506E-02 0.04220 ];
XE135_CAPT                (idx, [1:   4]) = [  1.71556E+15 0.03285  3.12572E-02 0.03252 ];
SM149_CAPT                (idx, [1:   4]) = [  8.60500E+13 0.14068  1.55989E-03 0.13920 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50227 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.28764E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50227 5.00529E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 35060 3.49298E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 15167 1.51230E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50227 5.00529E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.91038E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.24511E+16 0.00012  6.24511E+16 0.00012  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.37829E+16 1.9E-05  2.37829E+16 1.9E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  5.46917E+16 0.00304  4.28338E+16 0.00346  1.18579E+16 0.00412 ];
TOT_ABSRATE               (idx, [1:   6]) = [  7.84746E+16 0.00212  6.66167E+16 0.00223  1.18579E+16 0.00412 ];
TOT_SRCRATE               (idx, [1:   6]) = [  7.86086E+16 0.00487  7.86086E+16 0.00487  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  5.23127E+18 0.00392  8.61381E+17 0.00395  4.36989E+18 0.00409 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  7.84746E+16 0.00212 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  3.74230E+18 0.00325 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.26935E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.26935E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.19248E+00 0.00607 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.12218E-01 0.00265 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.27100E-01 0.00268 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.12838E+00 0.00339 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  7.93910E-01 0.00661 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  7.93910E-01 0.00661 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.62589E+00 0.00013 ];
FISSE                     (idx, [1:   2]) = [  2.04942E+02 1.9E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  7.93457E-01 0.00666  7.89473E-01 0.00660  4.43631E-03 0.10624 ];
IMP_KEFF                  (idx, [1:   2]) = [  7.97193E-01 0.00213 ];
COL_KEFF                  (idx, [1:   2]) = [  7.96334E-01 0.00490 ];
ABS_KEFF                  (idx, [1:   2]) = [  7.97193E-01 0.00213 ];
ABS_KINF                  (idx, [1:   2]) = [  7.97193E-01 0.00213 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.80517E+01 0.00226 ];
IMP_ALF                   (idx, [1:   2]) = [  1.80300E+01 0.00071 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  3.15301E-07 0.04535 ];
IMP_EALF                  (idx, [1:   2]) = [  2.97956E-07 0.01251 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  2.03789E-01 0.03550 ];
IMP_AFGE                  (idx, [1:   2]) = [  2.04795E-01 0.01116 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  8.06077E-03 0.06787  2.00845E-04 0.34310  1.17309E-03 0.13697  1.47146E-03 0.15491  3.54351E-03 0.08904  1.44113E-03 0.14821  2.30740E-04 0.32051 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.55455E-01 0.19762  1.01018E-03 0.34098  1.21306E-02 0.12577  4.34317E-02 0.12577  2.30380E-01 0.06275  5.50414E-01 0.11721  8.38101E-01 0.32082 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  5.68241E-03 0.09384  1.23058E-04 0.48116  5.45870E-04 0.22399  9.77612E-04 0.23050  2.49414E-03 0.12453  1.45356E-03 0.17755  8.81740E-05 0.70814 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  7.22192E-01 0.21113  1.26272E-02 0.01100  3.11125E-02 0.00460  1.11111E-01 0.00454  3.20279E-01 0.00333  1.27925E+00 0.01944  9.50534E+00 0.03384 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  9.38854E-05 0.01341  9.39657E-05 0.01346  3.54623E-05 0.20862 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  7.41205E-05 0.01088  7.41819E-05 0.01093  2.84194E-05 0.20962 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  5.69886E-03 0.10407  1.52084E-04 0.77137  8.50727E-04 0.26569  1.18391E-03 0.24150  2.31389E-03 0.17532  1.13626E-03 0.23154  6.19835E-05 1.00000 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  5.62151E-01 0.29684  1.24858E-02 0.00038  3.11509E-02 0.00794  1.11137E-01 0.00761  3.19582E-01 0.00518  1.25914E+00 0.03587  9.97903E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  9.66780E-05 0.03079  9.68349E-05 0.03072  4.27779E-06 0.38796 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  7.63841E-05 0.03006  7.65075E-05 0.02999  3.35899E-06 0.38165 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  3.32865E-03 0.34296  0.00000E+00 0.0E+00  1.12902E-03 0.65346  6.03573E-04 0.75071  9.74892E-04 0.47580  6.21169E-04 0.72223  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  3.53212E-01 0.34895  0.00000E+00 0.0E+00  3.11983E-02 0.02006  1.09375E-01 1.5E-08  3.17116E-01 0.00040  1.11204E+00 0.21757  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  3.53935E-03 0.35462  0.00000E+00 0.0E+00  1.29440E-03 0.62647  7.03530E-04 0.78087  1.05801E-03 0.49480  4.83416E-04 0.72060  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  3.52738E-01 0.34960  0.00000E+00 0.0E+00  3.11983E-02 0.02006  1.09375E-01 1.5E-08  3.17116E-01 0.00040  1.11204E+00 0.21757  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -4.39982E+01 0.37817 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  9.51675E-05 0.00846 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  7.51987E-05 0.00568 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  5.28661E-03 0.06877 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -5.53372E+01 0.06720 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  9.39516E-07 0.00410 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.24184E-06 0.00434  3.24075E-06 0.00439  2.90102E-06 0.08315 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  8.25496E-05 0.00556  8.25614E-05 0.00555  6.73685E-05 0.09254 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.27243E-01 0.00267  7.28776E-01 0.00271  7.55293E-01 0.11124 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.04283E+01 0.20998 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.76131E+01 0.00338  5.31592E+01 0.00513 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.74646E+03 0.01987  1.49158E+04 0.01309  3.26829E+04 0.00900  3.83680E+04 0.01093  3.73263E+04 0.00949  3.84098E+04 0.01036  2.65407E+04 0.00544  2.26074E+04 0.01108  1.70068E+04 0.01067  1.39117E+04 0.00457  1.19434E+04 0.00989  1.09640E+04 0.00910  1.01114E+04 0.00703  9.55245E+03 0.00702  9.27748E+03 0.01250  8.14642E+03 0.00663  8.17710E+03 0.01084  8.04615E+03 0.00381  7.87198E+03 0.02010  1.55439E+04 0.00714  1.53322E+04 0.00925  1.10961E+04 0.01210  7.30301E+03 0.00530  8.56428E+03 0.00494  8.25170E+03 0.00845  7.18741E+03 0.01472  1.21786E+04 0.01017  2.66601E+03 0.03088  3.42636E+03 0.02204  3.14964E+03 0.01705  1.84646E+03 0.01204  3.24780E+03 0.02190  2.23372E+03 0.03470  1.72646E+03 0.02507  3.25266E+02 0.04199  2.84943E+02 0.05539  2.57744E+02 0.03650  2.69244E+02 0.04987  2.37076E+02 0.04511  2.61355E+02 0.02402  2.98589E+02 0.04838  2.98688E+02 0.04314  6.45017E+02 0.05719  9.71658E+02 0.03171  1.34956E+03 0.02088  3.53281E+03 0.01593  3.82816E+03 0.01443  4.25485E+03 0.00859  3.14841E+03 0.01186  2.54855E+03 0.03513  2.00067E+03 0.02033  2.37046E+03 0.01386  4.90805E+03 0.01064  7.12257E+03 0.00607  1.46708E+04 0.00929  2.40203E+04 0.00690  3.72676E+04 0.00696  2.41848E+04 0.00718  1.78634E+04 0.00534  1.29027E+04 0.00797  1.18574E+04 0.00826  1.16097E+04 0.00939  9.64958E+03 0.00798  6.69400E+03 0.00881  6.03391E+03 0.01474  5.52134E+03 0.00851  4.52565E+03 0.00934  3.61057E+03 0.00344  2.38642E+03 0.02066  8.77072E+02 0.01531 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  7.96464E-01 0.00412 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  3.47524E+18 0.00444  1.75963E+18 0.00507 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73191E-01 0.00077  1.19473E+00 0.00143 ];
INF_CAPT                  (idx, [1:   4]) = [  5.40611E-03 0.00703  2.04446E-02 0.00308 ];
INF_ABS                   (idx, [1:   4]) = [  6.16645E-03 0.00656  3.24910E-02 0.00372 ];
INF_FISS                  (idx, [1:   4]) = [  7.60336E-04 0.00506  1.20465E-02 0.00482 ];
INF_NSF                   (idx, [1:   4]) = [  2.05906E-03 0.00486  3.15090E-02 0.00483 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.70811E+00 0.00052  2.61562E+00 5.4E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.05593E+02 3.6E-05  2.04861E+02 1.0E-05 ];
INF_INVV                  (idx, [1:   4]) = [  6.15018E-08 0.00759  2.67482E-06 0.00040 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.66997E-01 0.00084  1.16224E+00 0.00150 ];
INF_SCATT1                (idx, [1:   4]) = [  2.21216E-01 0.00174  2.93220E-01 0.00207 ];
INF_SCATT2                (idx, [1:   4]) = [  8.81905E-02 0.00252  6.81983E-02 0.00456 ];
INF_SCATT3                (idx, [1:   4]) = [  6.28419E-03 0.02119  2.06184E-02 0.02353 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.46405E-03 0.00952 -6.96132E-03 0.05376 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.86829E-04 0.96971  4.60472E-03 0.05732 ];
INF_SCATT6                (idx, [1:   4]) = [  4.41377E-03 0.03279 -1.30415E-02 0.01549 ];
INF_SCATT7                (idx, [1:   4]) = [  6.12333E-04 0.21321  5.76777E-04 0.39261 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67021E-01 0.00084  1.16224E+00 0.00150 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.21219E-01 0.00174  2.93220E-01 0.00207 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.81882E-02 0.00251  6.81983E-02 0.00456 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.28455E-03 0.02117  2.06184E-02 0.02353 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.46499E-03 0.00956 -6.96132E-03 0.05376 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.86293E-04 0.97539  4.60472E-03 0.05732 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.41398E-03 0.03281 -1.30415E-02 0.01549 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.11912E-04 0.21340  5.76777E-04 0.39261 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95710E-01 0.00173  8.00503E-01 0.00158 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70322E+00 0.00172  4.16409E-01 0.00159 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.14253E-03 0.00713  3.24910E-02 0.00372 ];
INF_REMXS                 (idx, [1:   4]) = [  2.29154E-02 0.00188  3.30268E-02 0.00443 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50275E-01 0.00085  1.67220E-02 0.00267  5.43624E-04 0.05404  1.16170E+00 0.00152 ];
INF_S1                    (idx, [1:   8]) = [  2.16332E-01 0.00173  4.88457E-03 0.00913  2.65992E-04 0.06287  2.92954E-01 0.00208 ];
INF_S2                    (idx, [1:   8]) = [  8.96983E-02 0.00279 -1.50784E-03 0.03451  1.52895E-04 0.06857  6.80454E-02 0.00467 ];
INF_S3                    (idx, [1:   8]) = [  8.03121E-03 0.01841 -1.74702E-03 0.02116  5.82284E-05 0.18166  2.05602E-02 0.02363 ];
INF_S4                    (idx, [1:   8]) = [ -8.89170E-03 0.01005 -5.72350E-04 0.05010  1.23928E-05 0.60494 -6.97371E-03 0.05404 ];
INF_S5                    (idx, [1:   8]) = [ -2.04063E-04 0.82918  1.72338E-05 1.00000 -2.47869E-05 0.35161  4.62951E-03 0.05787 ];
INF_S6                    (idx, [1:   8]) = [  4.53673E-03 0.03252 -1.22965E-04 0.12088 -3.12868E-05 0.33475 -1.30102E-02 0.01587 ];
INF_S7                    (idx, [1:   8]) = [  7.61875E-04 0.17329 -1.49541E-04 0.17428 -2.15025E-05 0.21003  5.98279E-04 0.38103 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50299E-01 0.00085  1.67220E-02 0.00267  5.43624E-04 0.05404  1.16170E+00 0.00152 ];
INF_SP1                   (idx, [1:   8]) = [  2.16334E-01 0.00174  4.88457E-03 0.00913  2.65992E-04 0.06287  2.92954E-01 0.00208 ];
INF_SP2                   (idx, [1:   8]) = [  8.96960E-02 0.00277 -1.50784E-03 0.03451  1.52895E-04 0.06857  6.80454E-02 0.00467 ];
INF_SP3                   (idx, [1:   8]) = [  8.03157E-03 0.01839 -1.74702E-03 0.02116  5.82284E-05 0.18166  2.05602E-02 0.02363 ];
INF_SP4                   (idx, [1:   8]) = [ -8.89264E-03 0.01010 -5.72350E-04 0.05010  1.23928E-05 0.60494 -6.97371E-03 0.05404 ];
INF_SP5                   (idx, [1:   8]) = [ -2.03527E-04 0.83389  1.72338E-05 1.00000 -2.47869E-05 0.35161  4.62951E-03 0.05787 ];
INF_SP6                   (idx, [1:   8]) = [  4.53695E-03 0.03254 -1.22965E-04 0.12088 -3.12868E-05 0.33475 -1.30102E-02 0.01587 ];
INF_SP7                   (idx, [1:   8]) = [  7.61454E-04 0.17349 -1.49541E-04 0.17428 -2.15025E-05 0.21003  5.98279E-04 0.38103 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.01328E-01 0.00335  6.29081E-01 0.02726 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.02952E-01 0.00501  6.78652E-01 0.02326 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.02963E-01 0.00849  6.56563E-01 0.03079 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  1.98233E-01 0.00713  5.66992E-01 0.04571 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.65575E+00 0.00334  5.31440E-01 0.02708 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.64259E+00 0.00504  4.92263E-01 0.02387 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.64280E+00 0.00830  5.09601E-01 0.03040 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.68187E+00 0.00712  5.92456E-01 0.04220 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  5.68241E-03 0.09384  1.23058E-04 0.48116  5.45870E-04 0.22399  9.77612E-04 0.23050  2.49414E-03 0.12453  1.45356E-03 0.17755  8.81740E-05 0.70814 ];
LAMBDA                    (idx, [1:  14]) = [  7.22192E-01 0.21113  1.26272E-02 0.01100  3.11125E-02 0.00460  1.11111E-01 0.00454  3.20279E-01 0.00333  1.27925E+00 0.01944  9.50534E+00 0.03384 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:31 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  9.98847E-01  1.00478E+00  1.00314E+00  9.93228E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.04660E-01 0.00349  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  8.95340E-01 0.00041  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.97672E-01 0.00064  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.00922E-01 0.00063  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.14552E+00 0.00301  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.89595E+01 0.00311  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.89595E+01 0.00311  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  2.08899E+01 0.00328  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.32673E+00 0.00591  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50344 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.03440E+02 0.00985 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.03440E+02 0.00985 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  2.05780E+00 ;
RUNNING_TIME              (idx, 1)        =  9.97900E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  3.11667E-02  3.40000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.74367E-01  4.06167E-02  3.32833E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  8.44500E-02  8.43333E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  3.35000E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  9.97550E-01  1.28365E+00 ];
CPU_USAGE                 (idx, 1)        = 2.06213 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.97765E+00 0.00631 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  4.79357E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.45382E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.29278E+04 ;
TOT_SF_RATE               (idx, 1)        =  5.42550E+03 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  4.05890E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  3.76112E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.04793E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.91662E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  3.14096E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  3.79988E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.36379E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  9.95525E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.77717E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.80436E+07 ;
SR90_ACTIVITY             (idx, 1)        =  3.86599E+11 ;
TE132_ACTIVITY            (idx, 1)        =  6.99262E+14 ;
I131_ACTIVITY             (idx, 1)        =  2.06487E+14 ;
I132_ACTIVITY             (idx, 1)        =  9.44900E+14 ;
CS134_ACTIVITY            (idx, 1)        =  9.14927E+10 ;
CS137_ACTIVITY            (idx, 1)        =  4.68153E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.20224E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.99624E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  6.76574E+09 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.81739E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.97498E+14 0.00441  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 5 ;
BURNUP                     (idx, [1:  2])  = [  3.00000E+01  3.00411E+01 ];
BURN_DAYS                 (idx, 1)        =  5.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  1.16915E+00 0.01057 ];
U235_FISS                 (idx, [1:   4]) = [  8.74150E+15 0.01461  3.69212E-01 0.01187 ];
U238_FISS                 (idx, [1:   4]) = [  1.78027E+15 0.02899  7.53039E-02 0.02800 ];
PU239_FISS                (idx, [1:   4]) = [  8.07116E+15 0.01531  3.40565E-01 0.01233 ];
PU240_FISS                (idx, [1:   4]) = [  3.06691E+13 0.24144  1.28448E-03 0.24196 ];
PU241_FISS                (idx, [1:   4]) = [  4.83805E+15 0.02027  2.04451E-01 0.01888 ];
U235_CAPT                 (idx, [1:   4]) = [  1.65851E+15 0.03748  2.20658E-02 0.03669 ];
U238_CAPT                 (idx, [1:   4]) = [  2.67523E+16 0.00876  3.55550E-01 0.00665 ];
PU239_CAPT                (idx, [1:   4]) = [  4.27713E+15 0.02334  5.68204E-02 0.02249 ];
PU240_CAPT                (idx, [1:   4]) = [  7.36868E+15 0.01552  9.80300E-02 0.01508 ];
PU241_CAPT                (idx, [1:   4]) = [  1.84345E+15 0.02668  2.45219E-02 0.02639 ];
XE135_CAPT                (idx, [1:   4]) = [  1.70410E+15 0.03697  2.25656E-02 0.03529 ];
SM149_CAPT                (idx, [1:   4]) = [  8.41101E+13 0.13955  1.12478E-03 0.14024 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50344 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 7.95460E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50344 5.00795E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 38281 3.80828E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 12063 1.19967E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50344 5.00795E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -3.63798E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.42617E+16 0.00013  6.42617E+16 0.00013  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.36176E+16 1.6E-05  2.36176E+16 1.6E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  7.44400E+16 0.00265  5.87341E+16 0.00300  1.57059E+16 0.00436 ];
TOT_ABSRATE               (idx, [1:   6]) = [  9.80575E+16 0.00201  8.23517E+16 0.00214  1.57059E+16 0.00436 ];
TOT_SRCRATE               (idx, [1:   6]) = [  9.87490E+16 0.00441  9.87490E+16 0.00441  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  6.67740E+18 0.00346  1.10131E+18 0.00352  5.57609E+18 0.00364 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  9.80575E+16 0.00201 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  4.83760E+18 0.00312 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.26145E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.26145E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.01041E+00 0.00806 ];
SIX_FF_F                  (idx, [1:   2]) = [  7.94659E-01 0.00249 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.12820E-01 0.00285 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14134E+00 0.00355 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  6.52312E-01 0.00797 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  6.52312E-01 0.00797 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.72092E+00 0.00014 ];
FISSE                     (idx, [1:   2]) = [  2.06376E+02 1.6E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  6.51389E-01 0.00809  6.49337E-01 0.00790  2.97492E-03 0.13171 ];
IMP_KEFF                  (idx, [1:   2]) = [  6.56522E-01 0.00202 ];
COL_KEFF                  (idx, [1:   2]) = [  6.51995E-01 0.00436 ];
ABS_KEFF                  (idx, [1:   2]) = [  6.56522E-01 0.00202 ];
ABS_KINF                  (idx, [1:   2]) = [  6.56522E-01 0.00202 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.77168E+01 0.00229 ];
IMP_ALF                   (idx, [1:   2]) = [  1.77060E+01 0.00087 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  4.44658E-07 0.05388 ];
IMP_EALF                  (idx, [1:   2]) = [  4.13559E-07 0.01558 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  2.49235E-01 0.03231 ];
IMP_AFGE                  (idx, [1:   2]) = [  2.57722E-01 0.01384 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  7.76030E-03 0.06269  1.95984E-04 0.39914  1.26127E-03 0.16993  1.16953E-03 0.16568  3.39491E-03 0.09532  1.41913E-03 0.14490  3.19484E-04 0.28895 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.85549E-01 0.19917  7.49434E-04 0.39781  9.57413E-03 0.15003  3.41648E-02 0.15005  2.09107E-01 0.07385  4.73695E-01 0.12842  8.48127E-01 0.30828 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  4.99575E-03 0.08435  7.00925E-05 0.63635  1.00740E-03 0.22929  7.38157E-04 0.29314  2.00793E-03 0.13683  8.73153E-04 0.19312  2.99015E-04 0.49149 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  8.98408E-01 0.20768  1.24906E-02 8.2E-09  3.08776E-02 0.00521  1.10237E-01 0.00587  3.21720E-01 0.00444  1.20654E+00 0.02709  7.48336E+00 0.13298 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  1.18954E-04 0.01732  1.18966E-04 0.01745  3.33413E-05 0.25302 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  7.69147E-05 0.01464  7.69247E-05 0.01483  2.19667E-05 0.25524 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  4.27898E-03 0.13504  1.49554E-04 0.70425  5.01221E-04 0.37057  3.62141E-04 0.44281  1.82632E-03 0.20377  1.06091E-03 0.26444  3.78838E-04 0.44627 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  1.13352E+00 0.28361  1.24906E-02 0.0E+00  3.05327E-02 0.01100  1.09800E-01 0.01469  3.23978E-01 0.00879  1.23119E+00 0.04651  8.04672E+00 0.16109 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  1.15344E-04 0.03428  1.15044E-04 0.03461  1.36964E-05 0.48507 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  7.47502E-05 0.03359  7.45486E-05 0.03397  9.16954E-06 0.49474 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  5.24379E-03 0.37183  3.77478E-04 1.00000  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.05024E-03 0.53720  4.56611E-04 1.00000  1.35946E-03 0.70835 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  1.77032E+00 0.60548  1.24906E-02 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.17242E-01 0.00049  1.35238E+00 0.0E+00  6.49091E+00 0.53738 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  5.11031E-03 0.37813  3.78947E-04 1.00000  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  2.91879E-03 0.55073  4.05117E-04 1.00000  1.40745E-03 0.70940 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  1.77032E+00 0.60548  1.24906E-02 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.17242E-01 0.00049  1.35238E+00 0.0E+00  6.49091E+00 0.53738 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -4.90685E+01 0.35351 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  1.16539E-04 0.00912 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  7.54587E-05 0.00526 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  4.83265E-03 0.07891 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -4.15209E+01 0.07713 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  9.79784E-07 0.00398 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.21386E-06 0.00528  3.21379E-06 0.00531  2.84169E-06 0.07176 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  8.91552E-05 0.00508  8.91346E-05 0.00511  7.44333E-05 0.08675 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.13092E-01 0.00286  7.15039E-01 0.00298  4.91331E-01 0.10136 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  9.53355E+00 0.15031 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.89595E+01 0.00311  5.41456E+01 0.00680 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  4.13419E+03 0.02839  1.53716E+04 0.01291  3.20198E+04 0.00818  3.75302E+04 0.00862  3.67930E+04 0.00579  3.82319E+04 0.00484  2.62809E+04 0.00381  2.28511E+04 0.01003  1.71536E+04 0.00417  1.41837E+04 0.00802  1.22095E+04 0.00736  1.08298E+04 0.01129  1.01772E+04 0.00893  9.55157E+03 0.01617  9.41139E+03 0.00307  8.12533E+03 0.01246  8.14992E+03 0.01175  8.02504E+03 0.01888  7.82373E+03 0.01479  1.53455E+04 0.00998  1.50573E+04 0.00928  1.10472E+04 0.00668  7.17283E+03 0.00682  8.35929E+03 0.01226  7.99186E+03 0.00720  7.31890E+03 0.00723  1.22655E+04 0.00667  2.79336E+03 0.02628  3.47086E+03 0.01082  3.08085E+03 0.01400  1.92708E+03 0.02504  3.21311E+03 0.00965  2.11594E+03 0.01102  1.79893E+03 0.02963  3.24468E+02 0.04093  2.71230E+02 0.02665  2.55330E+02 0.06591  2.14092E+02 0.04291  2.46421E+02 0.05401  2.55996E+02 0.05526  2.90232E+02 0.02409  3.23609E+02 0.04485  6.20992E+02 0.04010  1.02424E+03 0.02509  1.30986E+03 0.02603  3.41730E+03 0.01415  3.60574E+03 0.01751  4.24670E+03 0.01166  3.16878E+03 0.01032  2.56988E+03 0.01954  2.04129E+03 0.01212  2.42956E+03 0.02535  5.17946E+03 0.01807  7.43373E+03 0.01227  1.53526E+04 0.00357  2.53154E+04 0.00691  3.93760E+04 0.00657  2.58410E+04 0.00794  1.88969E+04 0.00456  1.37814E+04 0.00785  1.23936E+04 0.01115  1.24528E+04 0.01105  1.04463E+04 0.00715  6.95507E+03 0.00733  6.46086E+03 0.01271  5.77976E+03 0.00931  4.93952E+03 0.01207  4.00234E+03 0.01840  2.64711E+03 0.01124  9.29756E+02 0.02353 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  6.51997E-01 0.00437 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  4.34852E+18 0.00412  2.33279E+18 0.00284 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.74193E-01 0.00138  1.19174E+00 0.00153 ];
INF_CAPT                  (idx, [1:   4]) = [  5.83167E-03 0.00392  2.10794E-02 0.00237 ];
INF_ABS                   (idx, [1:   4]) = [  6.48957E-03 0.00360  2.99960E-02 0.00273 ];
INF_FISS                  (idx, [1:   4]) = [  6.57907E-04 0.00331  8.91664E-03 0.00362 ];
INF_NSF                   (idx, [1:   4]) = [  1.81981E-03 0.00372  2.42060E-02 0.00363 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.76604E+00 0.00088  2.71470E+00 3.7E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.06252E+02 2.7E-05  2.06393E+02 7.9E-06 ];
INF_INVV                  (idx, [1:   4]) = [  6.13441E-08 0.00373  2.69318E-06 0.00134 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.67636E-01 0.00137  1.16156E+00 0.00158 ];
INF_SCATT1                (idx, [1:   4]) = [  2.21873E-01 0.00160  2.91378E-01 0.00214 ];
INF_SCATT2                (idx, [1:   4]) = [  8.85268E-02 0.00210  6.71071E-02 0.00479 ];
INF_SCATT3                (idx, [1:   4]) = [  6.33118E-03 0.03139  2.00559E-02 0.02303 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.53513E-03 0.02228 -6.94185E-03 0.03683 ];
INF_SCATT5                (idx, [1:   4]) = [ -2.91205E-04 0.52537  5.30347E-03 0.07225 ];
INF_SCATT6                (idx, [1:   4]) = [  4.33365E-03 0.04092 -1.29343E-02 0.02337 ];
INF_SCATT7                (idx, [1:   4]) = [  5.44022E-04 0.23863  1.81188E-04 1.00000 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67672E-01 0.00137  1.16156E+00 0.00158 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.21875E-01 0.00161  2.91378E-01 0.00214 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.85288E-02 0.00210  6.71071E-02 0.00479 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.32738E-03 0.03143  2.00559E-02 0.02303 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.53438E-03 0.02228 -6.94185E-03 0.03683 ];
INF_SCATTP5               (idx, [1:   4]) = [ -2.92041E-04 0.52307  5.30347E-03 0.07225 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.33440E-03 0.04102 -1.29343E-02 0.02337 ];
INF_SCATTP7               (idx, [1:   4]) = [  5.43952E-04 0.23739  1.81188E-04 1.00000 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95651E-01 0.00154  8.02444E-01 0.00107 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70373E+00 0.00154  4.15399E-01 0.00107 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.45345E-03 0.00347  2.99960E-02 0.00273 ];
INF_REMXS                 (idx, [1:   4]) = [  2.30003E-02 0.00156  3.06512E-02 0.00547 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.51193E-01 0.00138  1.64428E-02 0.00365  4.76216E-04 0.01471  1.16109E+00 0.00158 ];
INF_S1                    (idx, [1:   8]) = [  2.17074E-01 0.00170  4.79913E-03 0.00601  2.33140E-04 0.05995  2.91144E-01 0.00214 ];
INF_S2                    (idx, [1:   8]) = [  8.99635E-02 0.00208 -1.43672E-03 0.01251  1.06385E-04 0.04374  6.70007E-02 0.00482 ];
INF_S3                    (idx, [1:   8]) = [  8.00763E-03 0.02463 -1.67645E-03 0.01438  2.45284E-05 0.26082  2.00314E-02 0.02328 ];
INF_S4                    (idx, [1:   8]) = [ -8.99191E-03 0.02417 -5.43223E-04 0.04753 -8.85818E-06 1.00000 -6.93299E-03 0.03731 ];
INF_S5                    (idx, [1:   8]) = [ -3.16985E-04 0.49663  2.57806E-05 0.55513 -2.40784E-05 0.30757  5.32754E-03 0.07232 ];
INF_S6                    (idx, [1:   8]) = [  4.48835E-03 0.03893 -1.54696E-04 0.07942 -1.76348E-05 0.28189 -1.29166E-02 0.02343 ];
INF_S7                    (idx, [1:   8]) = [  7.13989E-04 0.16538 -1.69967E-04 0.07868 -8.60282E-06 0.48542  1.89791E-04 1.00000 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.51229E-01 0.00138  1.64428E-02 0.00365  4.76216E-04 0.01471  1.16109E+00 0.00158 ];
INF_SP1                   (idx, [1:   8]) = [  2.17076E-01 0.00171  4.79913E-03 0.00601  2.33140E-04 0.05995  2.91144E-01 0.00214 ];
INF_SP2                   (idx, [1:   8]) = [  8.99655E-02 0.00208 -1.43672E-03 0.01251  1.06385E-04 0.04374  6.70007E-02 0.00482 ];
INF_SP3                   (idx, [1:   8]) = [  8.00383E-03 0.02465 -1.67645E-03 0.01438  2.45284E-05 0.26082  2.00314E-02 0.02328 ];
INF_SP4                   (idx, [1:   8]) = [ -8.99116E-03 0.02417 -5.43223E-04 0.04753 -8.85818E-06 1.00000 -6.93299E-03 0.03731 ];
INF_SP5                   (idx, [1:   8]) = [ -3.17821E-04 0.49498  2.57806E-05 0.55513 -2.40784E-05 0.30757  5.32754E-03 0.07232 ];
INF_SP6                   (idx, [1:   8]) = [  4.48910E-03 0.03903 -1.54696E-04 0.07942 -1.76348E-05 0.28189 -1.29166E-02 0.02343 ];
INF_SP7                   (idx, [1:   8]) = [  7.13919E-04 0.16447 -1.69967E-04 0.07868 -8.60282E-06 0.48542  1.89791E-04 1.00000 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.02110E-01 0.00400  6.66355E-01 0.03530 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.03523E-01 0.00437  7.04577E-01 0.03812 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.04388E-01 0.00638  6.77461E-01 0.04925 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  1.98556E-01 0.00605  6.26066E-01 0.03813 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.64937E+00 0.00402  5.02847E-01 0.03687 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.63794E+00 0.00436  4.76177E-01 0.04246 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.63115E+00 0.00640  4.96667E-01 0.04740 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.67903E+00 0.00597  5.35697E-01 0.04014 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  4.99575E-03 0.08435  7.00925E-05 0.63635  1.00740E-03 0.22929  7.38157E-04 0.29314  2.00793E-03 0.13683  8.73153E-04 0.19312  2.99015E-04 0.49149 ];
LAMBDA                    (idx, [1:  14]) = [  8.98408E-01 0.20768  1.24906E-02 8.2E-09  3.08776E-02 0.00521  1.10237E-01 0.00587  3.21720E-01 0.00444  1.20654E+00 0.02709  7.48336E+00 0.13298 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:37 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.01036E+00  9.99550E-01  1.00209E+00  9.87997E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.05551E-01 0.00355  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  8.94449E-01 0.00042  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.97517E-01 0.00058  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.00741E-01 0.00058  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.14622E+00 0.00241  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.98907E+01 0.00365  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.98907E+01 0.00365  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  2.13034E+01 0.00348  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.55344E+00 0.00664  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50303 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.03030E+02 0.01115 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.03030E+02 0.01115 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  2.39026E+00 ;
RUNNING_TIME              (idx, 1)        =  1.09873E+00 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  3.85500E-02  3.51667E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  4.50450E-01  4.15500E-02  3.45333E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.01450E-01  8.45000E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  4.01667E-03  6.66670E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  1.09837E+00  1.29653E+00 ];
CPU_USAGE                 (idx, 1)        = 2.17547 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.99718E+00 0.00664 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  5.24726E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.63752E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.63944E+04 ;
TOT_SF_RATE               (idx, 1)        =  1.90662E+04 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  5.20539E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  5.04109E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.11698E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.13526E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  3.65276E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  4.14365E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.73665E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  1.22552E+07 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.91612E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.91813E+07 ;
SR90_ACTIVITY             (idx, 1)        =  4.33092E+11 ;
TE132_ACTIVITY            (idx, 1)        =  7.74664E+14 ;
I131_ACTIVITY             (idx, 1)        =  2.25493E+14 ;
I132_ACTIVITY             (idx, 1)        =  1.11839E+15 ;
CS134_ACTIVITY            (idx, 1)        =  1.73718E+11 ;
CS137_ACTIVITY            (idx, 1)        =  5.62040E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.33921E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.00940E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.75969E+10 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  2.07677E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  2.27765E+14 0.00471  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 6 ;
BURNUP                     (idx, [1:  2])  = [  3.60000E+01  3.60491E+01 ];
BURN_DAYS                 (idx, 1)        =  6.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  1.43949E+00 0.01083 ];
U235_FISS                 (idx, [1:   4]) = [  3.99644E+15 0.02554  1.70602E-01 0.02408 ];
U238_FISS                 (idx, [1:   4]) = [  2.19831E+15 0.03064  9.39032E-02 0.02902 ];
PU239_FISS                (idx, [1:   4]) = [  9.10022E+15 0.01558  3.88850E-01 0.01310 ];
PU240_FISS                (idx, [1:   4]) = [  4.19900E+13 0.24195  1.77291E-03 0.24840 ];
PU241_FISS                (idx, [1:   4]) = [  7.74227E+15 0.01660  3.30874E-01 0.01449 ];
U235_CAPT                 (idx, [1:   4]) = [  8.07214E+14 0.05405  8.90634E-03 0.05389 ];
U238_CAPT                 (idx, [1:   4]) = [  3.07911E+16 0.00841  3.39542E-01 0.00586 ];
PU239_CAPT                (idx, [1:   4]) = [  4.77808E+15 0.02133  5.27481E-02 0.02088 ];
PU240_CAPT                (idx, [1:   4]) = [  1.07715E+16 0.01534  1.18639E-01 0.01325 ];
PU241_CAPT                (idx, [1:   4]) = [  2.68998E+15 0.02567  2.97136E-02 0.02558 ];
XE135_CAPT                (idx, [1:   4]) = [  1.60427E+15 0.03577  1.76997E-02 0.03538 ];
SM149_CAPT                (idx, [1:   4]) = [  3.81262E+13 0.23513  4.29834E-04 0.23609 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50303 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 7.43302E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50303 5.00743E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 39960 3.97941E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 10343 1.02802E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50303 5.00743E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 7.27596E-12 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.60058E+16 0.00011  6.60058E+16 0.00011  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.34533E+16 1.2E-05  2.34533E+16 1.2E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  9.11558E+16 0.00292  7.25424E+16 0.00347  1.86135E+16 0.00432 ];
TOT_ABSRATE               (idx, [1:   6]) = [  1.14609E+17 0.00232  9.59957E+16 0.00263  1.86135E+16 0.00432 ];
TOT_SRCRATE               (idx, [1:   6]) = [  1.13882E+17 0.00471  1.13882E+17 0.00471  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  7.77765E+18 0.00345  1.28267E+18 0.00361  6.49498E+18 0.00362 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  1.14609E+17 0.00232 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  5.68488E+18 0.00314 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.25361E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.25361E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  8.97557E-01 0.00805 ];
SIX_FF_F                  (idx, [1:   2]) = [  7.90883E-01 0.00289 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.03990E-01 0.00295 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.15957E+00 0.00398 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  5.78400E-01 0.00781 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  5.78400E-01 0.00781 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.81435E+00 0.00012 ];
FISSE                     (idx, [1:   2]) = [  2.07822E+02 1.2E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  5.78978E-01 0.00806  5.74891E-01 0.00780  3.50869E-03 0.12838 ];
IMP_KEFF                  (idx, [1:   2]) = [  5.77052E-01 0.00235 ];
COL_KEFF                  (idx, [1:   2]) = [  5.80862E-01 0.00468 ];
ABS_KEFF                  (idx, [1:   2]) = [  5.77052E-01 0.00235 ];
ABS_KINF                  (idx, [1:   2]) = [  5.77052E-01 0.00235 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.73503E+01 0.00318 ];
IMP_ALF                   (idx, [1:   2]) = [  1.73811E+01 0.00098 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  6.82026E-07 0.06486 ];
IMP_EALF                  (idx, [1:   2]) = [  5.73617E-07 0.01676 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  3.10461E-01 0.03382 ];
IMP_AFGE                  (idx, [1:   2]) = [  3.07460E-01 0.01312 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  9.83861E-03 0.06188  1.96660E-04 0.40051  1.66380E-03 0.15070  1.65051E-03 0.14126  4.06785E-03 0.09614  1.75952E-03 0.14161  5.00261E-04 0.30677 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  6.62350E-01 0.14339  7.82498E-04 0.39819  1.11646E-02 0.13117  4.40974E-02 0.12581  2.22331E-01 0.06750  4.47667E-01 0.12487  1.02406E+00 0.28587 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  5.49683E-03 0.08932  9.22226E-05 0.63469  8.27427E-04 0.21651  1.07638E-03 0.21401  2.14512E-03 0.13155  1.09288E-03 0.18127  2.62795E-04 0.47612 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  6.52984E-01 0.18274  1.30416E-02 0.01911  3.01894E-02 0.00282  1.12782E-01 0.00585  3.22481E-01 0.00476  1.08577E+00 0.03334  8.24943E+00 0.09951 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  1.39217E-04 0.01822  1.39130E-04 0.01823  4.93119E-05 0.21144 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  8.00211E-05 0.01566  7.99737E-05 0.01570  2.85229E-05 0.20692 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  5.80669E-03 0.13390  8.69565E-05 1.00000  1.08218E-03 0.31578  6.98382E-04 0.43523  2.62042E-03 0.20368  1.07498E-03 0.26232  2.43773E-04 0.59136 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.53420E-01 0.29910  1.24811E-02 0.0E+00  3.02717E-02 0.00648  1.14138E-01 0.01421  3.25594E-01 0.00867  1.12237E+00 0.06016  7.44345E+00 0.30875 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  1.38828E-04 0.03826  1.38708E-04 0.03846  8.49899E-06 0.48323 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  8.00725E-05 0.03722  8.00028E-05 0.03742  4.92750E-06 0.48553 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  5.89890E-03 0.50760  0.00000E+00 0.0E+00  1.82469E-03 1.00000  3.03901E-04 1.00000  2.60699E-03 0.84855  1.16331E-03 0.80856  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  4.00557E-01 0.27504  0.00000E+00 0.0E+00  2.99660E-02 0.0E+00  1.16730E-01 0.0E+00  3.29390E-01 0.02119  8.70100E-01 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  5.94335E-03 0.49928  0.00000E+00 0.0E+00  1.89796E-03 1.00000  4.31177E-04 1.00000  2.40492E-03 0.86057  1.20930E-03 0.81836  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  4.00557E-01 0.27504  0.00000E+00 0.0E+00  2.99660E-02 0.0E+00  1.16730E-01 0.0E+00  3.29390E-01 0.02119  8.70100E-01 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -4.95114E+01 0.51159 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  1.40198E-04 0.00969 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  8.06843E-05 0.00614 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  6.48755E-03 0.07505 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -4.65562E+01 0.07602 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  9.96486E-07 0.00404 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.17080E-06 0.00447  3.17035E-06 0.00448  2.76697E-06 0.06960 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  9.32592E-05 0.00569  9.32475E-05 0.00577  8.12754E-05 0.08086 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.04184E-01 0.00294  7.07074E-01 0.00309  5.34658E-01 0.10236 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.10492E+01 0.17789 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.98907E+01 0.00365  5.47554E+01 0.00702 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  4.38377E+03 0.01770  1.54448E+04 0.02056  3.22947E+04 0.00390  3.80581E+04 0.01382  3.72984E+04 0.00783  3.77402E+04 0.00445  2.59083E+04 0.00868  2.26409E+04 0.00617  1.72856E+04 0.01071  1.39861E+04 0.00902  1.22475E+04 0.00274  1.09632E+04 0.01288  1.00332E+04 0.00746  9.79362E+03 0.00911  9.61410E+03 0.01118  8.30086E+03 0.00961  8.21080E+03 0.01630  8.14895E+03 0.00592  8.04991E+03 0.01393  1.54692E+04 0.00907  1.51376E+04 0.00790  1.09200E+04 0.00922  7.15302E+03 0.00421  8.35593E+03 0.01006  8.02144E+03 0.02039  7.31655E+03 0.01471  1.21442E+04 0.00640  2.82611E+03 0.01322  3.29222E+03 0.02163  3.12720E+03 0.02146  1.75849E+03 0.01614  3.18028E+03 0.01594  2.07169E+03 0.01564  1.68749E+03 0.02167  3.19622E+02 0.02809  2.61145E+02 0.06277  2.21883E+02 0.02919  2.10568E+02 0.07390  2.50971E+02 0.04728  2.17648E+02 0.02903  2.64367E+02 0.05458  2.65323E+02 0.06433  5.86259E+02 0.04014  9.41603E+02 0.02335  1.24459E+03 0.03263  3.35554E+03 0.01228  3.67177E+03 0.02334  4.16303E+03 0.02199  3.14096E+03 0.02322  2.57096E+03 0.01567  2.06942E+03 0.01813  2.54330E+03 0.01481  5.13123E+03 0.01661  7.53614E+03 0.01391  1.56899E+04 0.00701  2.55493E+04 0.01106  4.04105E+04 0.01120  2.68856E+04 0.01079  1.96393E+04 0.00809  1.43109E+04 0.01382  1.28947E+04 0.01695  1.27552E+04 0.01714  1.07171E+04 0.01451  7.17177E+03 0.01587  6.80638E+03 0.01735  5.97889E+03 0.01508  5.20931E+03 0.01130  3.99312E+03 0.00825  2.72934E+03 0.01291  9.65630E+02 0.02131 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  5.80823E-01 0.00656 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  5.02233E+18 0.00721  2.76143E+18 0.00337 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73742E-01 0.00063  1.19940E+00 0.00241 ];
INF_CAPT                  (idx, [1:   4]) = [  6.10493E-03 0.00384  2.19456E-02 0.00122 ];
INF_ABS                   (idx, [1:   4]) = [  6.72791E-03 0.00343  2.93230E-02 0.00112 ];
INF_FISS                  (idx, [1:   4]) = [  6.22985E-04 0.00720  7.37741E-03 0.00220 ];
INF_NSF                   (idx, [1:   4]) = [  1.75012E-03 0.00766  2.07684E-02 0.00224 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.80922E+00 0.00104  2.81513E+00 6.4E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.06727E+02 2.8E-05  2.07990E+02 1.3E-05 ];
INF_INVV                  (idx, [1:   4]) = [  5.99507E-08 0.00310  2.70129E-06 0.00162 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.66995E-01 0.00064  1.17036E+00 0.00254 ];
INF_SCATT1                (idx, [1:   4]) = [  2.21225E-01 0.00190  2.92892E-01 0.00473 ];
INF_SCATT2                (idx, [1:   4]) = [  8.84466E-02 0.00400  6.75605E-02 0.00536 ];
INF_SCATT3                (idx, [1:   4]) = [  6.37899E-03 0.01430  1.99419E-02 0.02276 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.49398E-03 0.00722 -7.51576E-03 0.03969 ];
INF_SCATT5                (idx, [1:   4]) = [ -2.09714E-04 0.58827  5.04415E-03 0.03662 ];
INF_SCATT6                (idx, [1:   4]) = [  4.16539E-03 0.02897 -1.28107E-02 0.02431 ];
INF_SCATT7                (idx, [1:   4]) = [  5.27133E-04 0.10151  6.22087E-04 0.90654 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67028E-01 0.00063  1.17036E+00 0.00254 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.21227E-01 0.00190  2.92892E-01 0.00473 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.84444E-02 0.00400  6.75605E-02 0.00536 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.38025E-03 0.01424  1.99419E-02 0.02276 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.49481E-03 0.00722 -7.51576E-03 0.03969 ];
INF_SCATTP5               (idx, [1:   4]) = [ -2.07023E-04 0.59343  5.04415E-03 0.03662 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.16477E-03 0.02898 -1.28107E-02 0.02431 ];
INF_SCATTP7               (idx, [1:   4]) = [  5.24441E-04 0.10281  6.22087E-04 0.90654 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95365E-01 0.00041  8.06618E-01 0.00284 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70621E+00 0.00041  4.13262E-01 0.00284 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.69422E-03 0.00294  2.93230E-02 0.00112 ];
INF_REMXS                 (idx, [1:   4]) = [  2.29729E-02 0.00090  2.95107E-02 0.00766 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50769E-01 0.00063  1.62254E-02 0.00202  4.76261E-04 0.02732  1.16989E+00 0.00254 ];
INF_S1                    (idx, [1:   8]) = [  2.16525E-01 0.00199  4.70053E-03 0.00264  2.38754E-04 0.07156  2.92654E-01 0.00478 ];
INF_S2                    (idx, [1:   8]) = [  8.98997E-02 0.00406 -1.45308E-03 0.01280  1.38887E-04 0.05386  6.74216E-02 0.00545 ];
INF_S3                    (idx, [1:   8]) = [  8.06531E-03 0.01448 -1.68632E-03 0.01673  4.75311E-05 0.11956  1.98944E-02 0.02289 ];
INF_S4                    (idx, [1:   8]) = [ -8.97527E-03 0.00807 -5.18716E-04 0.03403 -1.06181E-06 1.00000 -7.51470E-03 0.04050 ];
INF_S5                    (idx, [1:   8]) = [ -2.58969E-04 0.47688  4.92548E-05 0.36315 -2.14776E-05 0.29048  5.06563E-03 0.03548 ];
INF_S6                    (idx, [1:   8]) = [  4.29466E-03 0.02589 -1.29268E-04 0.25870 -1.84075E-05 0.41155 -1.27922E-02 0.02399 ];
INF_S7                    (idx, [1:   8]) = [  6.89866E-04 0.10088 -1.62733E-04 0.17430 -1.65641E-05 0.15479  6.38651E-04 0.88433 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50803E-01 0.00062  1.62254E-02 0.00202  4.76261E-04 0.02732  1.16989E+00 0.00254 ];
INF_SP1                   (idx, [1:   8]) = [  2.16527E-01 0.00199  4.70053E-03 0.00264  2.38754E-04 0.07156  2.92654E-01 0.00478 ];
INF_SP2                   (idx, [1:   8]) = [  8.98975E-02 0.00406 -1.45308E-03 0.01280  1.38887E-04 0.05386  6.74216E-02 0.00545 ];
INF_SP3                   (idx, [1:   8]) = [  8.06657E-03 0.01443 -1.68632E-03 0.01673  4.75311E-05 0.11956  1.98944E-02 0.02289 ];
INF_SP4                   (idx, [1:   8]) = [ -8.97610E-03 0.00809 -5.18716E-04 0.03403 -1.06181E-06 1.00000 -7.51470E-03 0.04050 ];
INF_SP5                   (idx, [1:   8]) = [ -2.56278E-04 0.47967  4.92548E-05 0.36315 -2.14776E-05 0.29048  5.06563E-03 0.03548 ];
INF_SP6                   (idx, [1:   8]) = [  4.29404E-03 0.02592 -1.29268E-04 0.25870 -1.84075E-05 0.41155 -1.27922E-02 0.02399 ];
INF_SP7                   (idx, [1:   8]) = [  6.87175E-04 0.10223 -1.62733E-04 0.17430 -1.65641E-05 0.15479  6.38651E-04 0.88433 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.01590E-01 0.00570  6.21327E-01 0.03274 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  1.98147E-01 0.01316  6.55688E-01 0.03892 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.06476E-01 0.00978  6.24615E-01 0.03262 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.00552E-01 0.01006  5.88893E-01 0.03588 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.65373E+00 0.00565  5.38854E-01 0.03358 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.68344E+00 0.01338  5.11581E-01 0.04030 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.61500E+00 0.00952  5.35875E-01 0.03164 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.66276E+00 0.01015  5.69107E-01 0.03766 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  5.49683E-03 0.08932  9.22226E-05 0.63469  8.27427E-04 0.21651  1.07638E-03 0.21401  2.14512E-03 0.13155  1.09288E-03 0.18127  2.62795E-04 0.47612 ];
LAMBDA                    (idx, [1:  14]) = [  6.52984E-01 0.18274  1.30416E-02 0.01911  3.01894E-02 0.00282  1.12782E-01 0.00585  3.22481E-01 0.00476  1.08577E+00 0.03334  8.24943E+00 0.09951 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:43 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.01463E+00  9.89121E-01  9.98785E-01  9.97465E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.05407E-01 0.00348  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  8.94593E-01 0.00041  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.96724E-01 0.00057  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.99983E-01 0.00056  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.15282E+00 0.00234  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.96408E+01 0.00356  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.96408E+01 0.00356  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  2.12761E+01 0.00372  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.50593E+00 0.00644  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50483 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.04830E+02 0.01430 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.04830E+02 0.01430 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  2.74584E+00 ;
RUNNING_TIME              (idx, 1)        =  1.20520E+00 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  4.57167E-02  3.58334E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  5.32300E-01  4.60000E-02  3.58500E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.18533E-01  8.51667E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  4.68334E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  1.20485E+00  1.30645E+00 ];
CPU_USAGE                 (idx, 1)        = 2.27833 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.99360E+00 0.00545 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  5.64650E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.72739E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.90412E+04 ;
TOT_SF_RATE               (idx, 1)        =  2.26106E+04 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  5.52396E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  5.40349E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.17499E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.36369E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  3.74589E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  4.21709E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.79934E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  1.26294E+07 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.94655E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.95415E+07 ;
SR90_ACTIVITY             (idx, 1)        =  4.39830E+11 ;
TE132_ACTIVITY            (idx, 1)        =  7.86743E+14 ;
I131_ACTIVITY             (idx, 1)        =  2.28095E+14 ;
I132_ACTIVITY             (idx, 1)        =  1.15414E+15 ;
CS134_ACTIVITY            (idx, 1)        =  1.88927E+11 ;
CS137_ACTIVITY            (idx, 1)        =  5.78005E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.40543E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.11484E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.03255E+10 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  2.17715E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  2.35465E+14 0.00520  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 7 ;
BURNUP                     (idx, [1:  2])  = [  3.70000E+01  3.70505E+01 ];
BURN_DAYS                 (idx, 1)        =  6.16667E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  1.47241E+00 0.01055 ];
U235_FISS                 (idx, [1:   4]) = [  3.47979E+15 0.02618  1.47715E-01 0.02354 ];
U238_FISS                 (idx, [1:   4]) = [  2.17201E+15 0.03529  9.19477E-02 0.03318 ];
PU239_FISS                (idx, [1:   4]) = [  9.51216E+15 0.01622  4.04537E-01 0.01377 ];
PU240_FISS                (idx, [1:   4]) = [  3.45414E+13 0.27197  1.45760E-03 0.27052 ];
PU241_FISS                (idx, [1:   4]) = [  7.92421E+15 0.01802  3.36824E-01 0.01526 ];
U235_CAPT                 (idx, [1:   4]) = [  6.36957E+14 0.06727  6.75175E-03 0.06645 ];
U238_CAPT                 (idx, [1:   4]) = [  3.16656E+16 0.00979  3.35633E-01 0.00790 ];
PU239_CAPT                (idx, [1:   4]) = [  5.08711E+15 0.02067  5.39937E-02 0.02080 ];
PU240_CAPT                (idx, [1:   4]) = [  1.14642E+16 0.01478  1.21495E-01 0.01360 ];
PU241_CAPT                (idx, [1:   4]) = [  2.85697E+15 0.03274  3.02411E-02 0.03166 ];
XE135_CAPT                (idx, [1:   4]) = [  1.64360E+15 0.03199  1.74712E-02 0.03247 ];
SM149_CAPT                (idx, [1:   4]) = [  5.85622E+13 0.20766  6.18282E-04 0.20424 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50483 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 6.63077E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50483 5.00663E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 40404 4.00619E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 10079 1.00044E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50483 5.00663E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -2.91038E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.62187E+16 0.00013  6.62187E+16 0.00013  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.34350E+16 1.1E-05  2.34350E+16 1.1E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  9.43561E+16 0.00331  7.51954E+16 0.00387  1.91607E+16 0.00406 ];
TOT_ABSRATE               (idx, [1:   6]) = [  1.17791E+17 0.00265  9.86304E+16 0.00295  1.91607E+16 0.00406 ];
TOT_SRCRATE               (idx, [1:   6]) = [  1.17733E+17 0.00520  1.17733E+17 0.00520  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  7.98684E+18 0.00377  1.31980E+18 0.00377  6.66704E+18 0.00391 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  1.17791E+17 0.00265 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  5.84208E+18 0.00328 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.25228E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.25228E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  8.79415E-01 0.00842 ];
SIX_FF_F                  (idx, [1:   2]) = [  7.92765E-01 0.00286 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.01149E-01 0.00288 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.15780E+00 0.00433 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  5.65500E-01 0.00947 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  5.65500E-01 0.00947 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.82564E+00 0.00013 ];
FISSE                     (idx, [1:   2]) = [  2.07985E+02 1.1E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  5.65402E-01 0.00954  5.62976E-01 0.00934  2.52389E-03 0.17940 ];
IMP_KEFF                  (idx, [1:   2]) = [  5.63455E-01 0.00267 ];
COL_KEFF                  (idx, [1:   2]) = [  5.63953E-01 0.00519 ];
ABS_KEFF                  (idx, [1:   2]) = [  5.63455E-01 0.00267 ];
ABS_KINF                  (idx, [1:   2]) = [  5.63455E-01 0.00267 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.73285E+01 0.00298 ];
IMP_ALF                   (idx, [1:   2]) = [  1.73232E+01 0.00109 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  6.88630E-07 0.06499 ];
IMP_EALF                  (idx, [1:   2]) = [  6.09691E-07 0.01834 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  3.20326E-01 0.02979 ];
IMP_AFGE                  (idx, [1:   2]) = [  3.19845E-01 0.01366 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  9.43834E-03 0.06341  2.57276E-04 0.36968  1.54041E-03 0.14480  1.59364E-03 0.16255  4.24041E-03 0.09123  1.42076E-03 0.17395  3.85839E-04 0.30738 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  5.18477E-01 0.14106  8.85140E-04 0.36652  1.11751E-02 0.13118  3.71994E-02 0.14334  2.25364E-01 0.06593  3.60646E-01 0.15619  6.57528E-01 0.33812 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  4.82037E-03 0.10403  2.51337E-04 0.56227  7.85588E-04 0.23051  7.38369E-04 0.22805  2.17776E-03 0.15469  7.26962E-04 0.20477  1.40352E-04 0.48479 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  5.48935E-01 0.15633  1.26449E-02 0.01258  3.01608E-02 0.00250  1.12546E-01 0.00638  3.21898E-01 0.00462  1.19731E+00 0.03075  6.56103E+00 0.15431 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  1.46740E-04 0.01860  1.46585E-04 0.01861  4.42486E-05 0.26784 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  8.21407E-05 0.01479  8.20548E-05 0.01487  2.53781E-05 0.26714 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  4.43110E-03 0.17100  2.67121E-04 0.59122  5.46503E-04 0.40864  8.81440E-04 0.35418  1.91599E-03 0.27552  7.19367E-04 0.41172  1.00671E-04 1.00000 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  3.76768E-01 0.20472  1.28537E-02 0.02899  3.00592E-02 0.00206  1.13358E-01 0.01332  3.20955E-01 0.01168  1.14223E+00 0.08465  3.00280E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  1.51600E-04 0.04159  1.50782E-04 0.04099  1.27954E-05 0.73443 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  8.45447E-05 0.03872  8.41094E-05 0.03819  7.04947E-06 0.71539 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  2.04373E-03 0.75237  1.47736E-03 1.00000  3.58256E-04 1.00000  0.00000E+00 0.0E+00  2.08110E-04 0.75128  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  1.42788E-01 0.70692  1.24811E-02 0.0E+00  2.99660E-02 0.0E+00  0.00000E+00 0.0E+00  3.29548E-01 0.03620  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  1.96604E-03 0.67335  1.16601E-03 1.00000  4.87013E-04 1.00000  0.00000E+00 0.0E+00  3.13020E-04 0.71385  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  1.48161E-01 0.66987  1.24811E-02 0.0E+00  2.99660E-02 0.0E+00  0.00000E+00 0.0E+00  3.29548E-01 0.03620  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.15372E+01 0.67240 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  1.47943E-04 0.01227 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  8.28758E-05 0.00707 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  2.94353E-03 0.10893 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -2.00541E+01 0.10763 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  9.97214E-07 0.00395 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.16030E-06 0.00526  3.15782E-06 0.00527  3.16096E-06 0.10046 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  9.30048E-05 0.00543  9.30229E-05 0.00547  7.13768E-05 0.08677 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.01557E-01 0.00289  7.04442E-01 0.00306  5.31807E-01 0.13205 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  7.70141E+00 0.12695 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.96408E+01 0.00356  5.48431E+01 0.00734 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  4.23516E+03 0.01579  1.54210E+04 0.00402  3.17306E+04 0.00863  3.78681E+04 0.00545  3.63381E+04 0.00968  3.82150E+04 0.00652  2.59080E+04 0.00790  2.26552E+04 0.00495  1.71141E+04 0.00795  1.39391E+04 0.00983  1.22381E+04 0.01131  1.07966E+04 0.00562  1.03326E+04 0.00782  9.50666E+03 0.01661  9.42709E+03 0.01577  8.05705E+03 0.00957  8.01575E+03 0.00871  8.11831E+03 0.01402  7.87705E+03 0.01206  1.54332E+04 0.00689  1.50901E+04 0.02243  1.09546E+04 0.01532  7.08934E+03 0.01167  8.45306E+03 0.00855  8.03618E+03 0.01501  7.28637E+03 0.01132  1.21961E+04 0.00327  2.72327E+03 0.01664  3.34238E+03 0.01853  3.17000E+03 0.01659  1.78855E+03 0.01560  3.10901E+03 0.00187  2.07479E+03 0.02270  1.75164E+03 0.01810  3.18771E+02 0.05375  2.47919E+02 0.04040  2.40145E+02 0.03821  2.24293E+02 0.04456  2.10120E+02 0.05670  2.10236E+02 0.03329  2.63605E+02 0.05914  2.87061E+02 0.05581  5.12787E+02 0.03232  9.03484E+02 0.03664  1.21462E+03 0.02578  3.30716E+03 0.01558  3.61182E+03 0.01420  4.22088E+03 0.02042  3.15533E+03 0.01311  2.53967E+03 0.02328  2.00427E+03 0.01552  2.46014E+03 0.02960  5.00942E+03 0.01662  7.45574E+03 0.01841  1.54941E+04 0.01151  2.57925E+04 0.00579  4.02353E+04 0.00623  2.64059E+04 0.00958  1.92888E+04 0.00933  1.40864E+04 0.01073  1.27017E+04 0.01121  1.27071E+04 0.01375  1.06645E+04 0.00937  7.25539E+03 0.01002  6.77684E+03 0.00950  6.09489E+03 0.01876  5.12768E+03 0.01075  4.12177E+03 0.01588  2.66842E+03 0.01499  9.65133E+02 0.01935 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  5.63977E-01 0.00705 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  5.15956E+18 0.00827  2.83485E+18 0.00229 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.74990E-01 0.00075  1.19910E+00 0.00284 ];
INF_CAPT                  (idx, [1:   4]) = [  6.22026E-03 0.00564  2.20083E-02 0.00315 ];
INF_ABS                   (idx, [1:   4]) = [  6.83989E-03 0.00512  2.91680E-02 0.00293 ];
INF_FISS                  (idx, [1:   4]) = [  6.19632E-04 0.00629  7.15968E-03 0.00232 ];
INF_NSF                   (idx, [1:   4]) = [  1.74539E-03 0.00620  2.02407E-02 0.00228 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.81682E+00 0.00026  2.82704E+00 5.5E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.06762E+02 1.6E-05  2.08178E+02 1.1E-05 ];
INF_INVV                  (idx, [1:   4]) = [  5.99965E-08 0.00621  2.70406E-06 0.00033 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.68141E-01 0.00077  1.16998E+00 0.00279 ];
INF_SCATT1                (idx, [1:   4]) = [  2.22309E-01 0.00081  2.93559E-01 0.00239 ];
INF_SCATT2                (idx, [1:   4]) = [  8.85833E-02 0.00111  6.78664E-02 0.00513 ];
INF_SCATT3                (idx, [1:   4]) = [  6.41725E-03 0.02450  1.99064E-02 0.01502 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.25385E-03 0.01693 -6.86866E-03 0.03892 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.39863E-04 0.97341  5.43718E-03 0.06962 ];
INF_SCATT6                (idx, [1:   4]) = [  4.37886E-03 0.03490 -1.27054E-02 0.03677 ];
INF_SCATT7                (idx, [1:   4]) = [  6.81311E-04 0.13462  6.61694E-04 0.68226 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.68171E-01 0.00078  1.16998E+00 0.00279 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.22309E-01 0.00081  2.93559E-01 0.00239 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.85828E-02 0.00112  6.78664E-02 0.00513 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.41537E-03 0.02442  1.99064E-02 0.01502 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.25266E-03 0.01692 -6.86866E-03 0.03892 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.39493E-04 0.97577  5.43718E-03 0.06962 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.37867E-03 0.03498 -1.27054E-02 0.03677 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.81077E-04 0.13519  6.61694E-04 0.68226 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.95055E-01 0.00209  8.06655E-01 0.00249 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.70895E+00 0.00209  4.13239E-01 0.00248 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.80961E-03 0.00469  2.91680E-02 0.00293 ];
INF_REMXS                 (idx, [1:   4]) = [  2.31143E-02 0.00194  2.96028E-02 0.00707 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.51876E-01 0.00073  1.62655E-02 0.00264  4.83757E-04 0.05460  1.16949E+00 0.00280 ];
INF_S1                    (idx, [1:   8]) = [  2.17584E-01 0.00077  4.72537E-03 0.00959  2.41530E-04 0.04684  2.93318E-01 0.00241 ];
INF_S2                    (idx, [1:   8]) = [  9.00300E-02 0.00129 -1.44674E-03 0.01607  1.24223E-04 0.03923  6.77422E-02 0.00515 ];
INF_S3                    (idx, [1:   8]) = [  8.07779E-03 0.01732 -1.66054E-03 0.02386  4.09538E-05 0.19443  1.98655E-02 0.01507 ];
INF_S4                    (idx, [1:   8]) = [ -8.70927E-03 0.01630 -5.44577E-04 0.05067 -1.70187E-06 1.00000 -6.86696E-03 0.03908 ];
INF_S5                    (idx, [1:   8]) = [ -1.29232E-04 1.00000 -1.06309E-05 1.00000 -1.57484E-05 0.46594  5.45292E-03 0.07057 ];
INF_S6                    (idx, [1:   8]) = [  4.54181E-03 0.03161 -1.62950E-04 0.10568 -2.31138E-05 0.24148 -1.26823E-02 0.03715 ];
INF_S7                    (idx, [1:   8]) = [  8.48969E-04 0.10749 -1.67658E-04 0.10183 -1.75754E-05 0.38813  6.79270E-04 0.66686 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.51906E-01 0.00074  1.62655E-02 0.00264  4.83757E-04 0.05460  1.16949E+00 0.00280 ];
INF_SP1                   (idx, [1:   8]) = [  2.17583E-01 0.00077  4.72537E-03 0.00959  2.41530E-04 0.04684  2.93318E-01 0.00241 ];
INF_SP2                   (idx, [1:   8]) = [  9.00296E-02 0.00129 -1.44674E-03 0.01607  1.24223E-04 0.03923  6.77422E-02 0.00515 ];
INF_SP3                   (idx, [1:   8]) = [  8.07591E-03 0.01725 -1.66054E-03 0.02386  4.09538E-05 0.19443  1.98655E-02 0.01507 ];
INF_SP4                   (idx, [1:   8]) = [ -8.70808E-03 0.01627 -5.44577E-04 0.05067 -1.70187E-06 1.00000 -6.86696E-03 0.03908 ];
INF_SP5                   (idx, [1:   8]) = [ -1.28862E-04 1.00000 -1.06309E-05 1.00000 -1.57484E-05 0.46594  5.45292E-03 0.07057 ];
INF_SP6                   (idx, [1:   8]) = [  4.54162E-03 0.03169 -1.62950E-04 0.10568 -2.31138E-05 0.24148 -1.26823E-02 0.03715 ];
INF_SP7                   (idx, [1:   8]) = [  8.48735E-04 0.10792 -1.67658E-04 0.10183 -1.75754E-05 0.38813  6.79270E-04 0.66686 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.00101E-01 0.00574  6.53310E-01 0.03906 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  1.98895E-01 0.00916  6.62187E-01 0.04060 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.04251E-01 0.00387  6.85191E-01 0.06242 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  1.97329E-01 0.00719  6.20793E-01 0.03211 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.66605E+00 0.00577  5.13450E-01 0.04030 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.67649E+00 0.00919  5.06740E-01 0.04087 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.63208E+00 0.00385  4.94269E-01 0.06322 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.68958E+00 0.00724  5.39341E-01 0.03459 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  4.82037E-03 0.10403  2.51337E-04 0.56227  7.85588E-04 0.23051  7.38369E-04 0.22805  2.17776E-03 0.15469  7.26962E-04 0.20477  1.40352E-04 0.48479 ];
LAMBDA                    (idx, [1:  14]) = [  5.48935E-01 0.15633  1.26449E-02 0.01258  3.01608E-02 0.00250  1.12546E-01 0.00638  3.21898E-01 0.00462  1.19731E+00 0.03075  6.56103E+00 0.15431 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 09:11:31 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 09:12:50 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550239891 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  9.70792E-01  1.01529E+00  1.02090E+00  9.93016E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.05255E-01 0.00391  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  8.94745E-01 0.00046  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.97310E-01 0.00061  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.00569E-01 0.00060  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.16524E+00 0.00274  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.94899E+01 0.00408  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.94899E+01 0.00408  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  2.11501E+01 0.00398  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.46530E+00 0.00762  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50465 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.04650E+02 0.01249 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.04650E+02 0.01249 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  3.10583E+00 ;
RUNNING_TIME              (idx, 1)        =  1.31318E+00 ;
INIT_TIME                 (idx, [1:  2])  = [  5.06017E-01  5.06017E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  5.34000E-02  3.78333E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  6.15133E-01  4.55000E-02  3.73333E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.35617E-01  8.53333E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  5.35001E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  1.31282E+00  1.31282E+00 ];
CPU_USAGE                 (idx, 1)        = 2.36512 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.96360E+00 0.00591 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  5.98266E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 6565.14;
MEMSIZE                   (idx, 1)        = 6492.74;
XS_MEMSIZE                (idx, 1)        = 6423.05;
MAT_MEMSIZE               (idx, 1)        = 38.73;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 72.41;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 288994 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 221 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1342 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 289 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8155 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.75625E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.95870E+04 ;
TOT_SF_RATE               (idx, 1)        =  2.67173E+04 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  5.70095E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  5.60920E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.18614E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.39769E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  3.83453E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  4.27627E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.86281E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  1.29701E+07 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.97172E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.97926E+07 ;
SR90_ACTIVITY             (idx, 1)        =  4.46364E+11 ;
TE132_ACTIVITY            (idx, 1)        =  7.98560E+14 ;
I131_ACTIVITY             (idx, 1)        =  2.30678E+14 ;
I132_ACTIVITY             (idx, 1)        =  1.18328E+15 ;
CS134_ACTIVITY            (idx, 1)        =  2.04967E+11 ;
CS137_ACTIVITY            (idx, 1)        =  5.94040E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.42595E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.11802E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.34519E+10 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  2.21615E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  2.39991E+14 0.00527  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 8 ;
BURNUP                     (idx, [1:  2])  = [  3.80000E+01  3.80519E+01 ];
BURN_DAYS                 (idx, 1)        =  6.33333E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  1.55403E+00 0.01131 ];
U235_FISS                 (idx, [1:   4]) = [  2.96703E+15 0.02759  1.28533E-01 0.02464 ];
U238_FISS                 (idx, [1:   4]) = [  2.12645E+15 0.03049  9.23664E-02 0.02864 ];
PU239_FISS                (idx, [1:   4]) = [  9.54153E+15 0.01347  4.15951E-01 0.01214 ];
PU240_FISS                (idx, [1:   4]) = [  2.31360E+13 0.33732  1.01232E-03 0.34113 ];
PU241_FISS                (idx, [1:   4]) = [  7.91936E+15 0.01663  3.44538E-01 0.01443 ];
U235_CAPT                 (idx, [1:   4]) = [  5.75337E+14 0.06210  5.92560E-03 0.06192 ];
U238_CAPT                 (idx, [1:   4]) = [  3.24868E+16 0.01008  3.34138E-01 0.00742 ];
PU239_CAPT                (idx, [1:   4]) = [  5.00476E+15 0.02352  5.16524E-02 0.02393 ];
PU240_CAPT                (idx, [1:   4]) = [  1.21902E+16 0.01503  1.25442E-01 0.01364 ];
PU241_CAPT                (idx, [1:   4]) = [  2.93273E+15 0.03157  3.01806E-02 0.03143 ];
XE135_CAPT                (idx, [1:   4]) = [  1.58905E+15 0.03791  1.63583E-02 0.03774 ];
SM149_CAPT                (idx, [1:   4]) = [  3.50526E+13 0.25960  3.70983E-04 0.26257 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50465 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 7.38747E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50465 5.00739E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 40780 4.04826E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 9685 9.59130E+03 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50465 5.00739E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 3.63798E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.64040E+16 0.00012  6.64040E+16 0.00012  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.34166E+16 1.2E-05  2.34166E+16 1.2E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  9.66739E+16 0.00326  7.73092E+16 0.00384  1.93647E+16 0.00419 ];
TOT_ABSRATE               (idx, [1:   6]) = [  1.20090E+17 0.00263  1.00726E+17 0.00295  1.93647E+16 0.00419 ];
TOT_SRCRATE               (idx, [1:   6]) = [  1.19995E+17 0.00527  1.19995E+17 0.00527  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  8.15261E+18 0.00364  1.34734E+18 0.00373  6.80527E+18 0.00378 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  1.20090E+17 0.00263 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  5.93791E+18 0.00313 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.25095E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.25095E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  8.50906E-01 0.00798 ];
SIX_FF_F                  (idx, [1:   2]) = [  7.90372E-01 0.00228 ];
SIX_FF_P                  (idx, [1:   2]) = [  6.97626E-01 0.00312 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.15948E+00 0.00413 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  5.43429E-01 0.00858 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  5.43429E-01 0.00858 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.83576E+00 0.00012 ];
FISSE                     (idx, [1:   2]) = [  2.08148E+02 1.2E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  5.43382E-01 0.00858  5.41003E-01 0.00866  2.42675E-03 0.17587 ];
IMP_KEFF                  (idx, [1:   2]) = [  5.54211E-01 0.00265 ];
COL_KEFF                  (idx, [1:   2]) = [  5.54906E-01 0.00526 ];
ABS_KEFF                  (idx, [1:   2]) = [  5.54211E-01 0.00265 ];
ABS_KINF                  (idx, [1:   2]) = [  5.54211E-01 0.00265 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.73099E+01 0.00309 ];
IMP_ALF                   (idx, [1:   2]) = [  1.72612E+01 0.00105 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  7.05507E-07 0.06222 ];
IMP_EALF                  (idx, [1:   2]) = [  6.48089E-07 0.01811 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  3.11928E-01 0.03019 ];
IMP_AFGE                  (idx, [1:   2]) = [  3.23985E-01 0.01337 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  9.61584E-03 0.06411  2.66712E-04 0.36742  1.79675E-03 0.14419  1.23092E-03 0.19220  4.34259E-03 0.09760  1.61182E-03 0.15082  3.67048E-04 0.30348 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  6.40362E-01 0.19580  8.96298E-04 0.36664  1.15084E-02 0.12841  3.28570E-02 0.15741  2.29497E-01 0.06282  4.16016E-01 0.13750  7.68884E-01 0.32802 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  4.97171E-03 0.10843  8.37447E-05 0.62545  1.02467E-03 0.22262  5.51691E-04 0.30367  2.14991E-03 0.17277  9.47499E-04 0.21637  2.14195E-04 0.38010 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  6.81595E-01 0.19936  1.28043E-02 0.01603  3.02450E-02 0.00307  1.13361E-01 0.00698  3.19303E-01 0.00462  1.15885E+00 0.03164  7.68884E+00 0.13548 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  1.44702E-04 0.01974  1.44770E-04 0.01985  3.03520E-05 0.26911 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  7.79018E-05 0.01644  7.79390E-05 0.01657  1.61965E-05 0.26492 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  4.62798E-03 0.17326  0.00000E+00 0.0E+00  9.77345E-04 0.36420  4.06784E-04 0.50262  2.12943E-03 0.22895  8.31665E-04 0.35241  2.82759E-04 0.57588 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.82341E-01 0.28298  0.00000E+00 0.0E+00  3.05650E-02 0.00961  1.13940E-01 0.01992  3.16696E-01 0.00922  1.16329E+00 0.07391  7.65362E+00 0.30383 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  1.41737E-04 0.04789  1.41729E-04 0.04787  5.26488E-06 0.60962 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  7.66204E-05 0.04729  7.66142E-05 0.04727  3.09491E-06 0.61117 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  3.01544E-03 0.83322  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  2.94885E-04 1.00000  2.72056E-03 0.91835  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  8.46490E-01 0.35337  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.16990E-01 0.0E+00  1.11124E+00 0.21700  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  2.76113E-03 0.76912  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  4.83559E-04 1.00000  2.27757E-03 0.91028  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  8.46490E-01 0.35337  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  3.16990E-01 0.0E+00  1.11124E+00 0.21700  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -2.80292E+01 0.88509 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  1.45338E-04 0.01347 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  7.83089E-05 0.00901 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  3.94929E-03 0.09455 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -2.77101E+01 0.09061 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  9.88510E-07 0.00462 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.15423E-06 0.00518  3.15268E-06 0.00513  3.09053E-06 0.09595 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  9.27290E-05 0.00626  9.26877E-05 0.00639  8.27920E-05 0.09675 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  6.97957E-01 0.00314  7.00948E-01 0.00318  5.10649E-01 0.12562 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  9.27230E+00 0.13236 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.94899E+01 0.00408  5.37352E+01 0.00780 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  4.30418E+03 0.03480  1.54805E+04 0.01439  3.23352E+04 0.00836  3.78910E+04 0.01009  3.70731E+04 0.00768  3.88700E+04 0.00557  2.57607E+04 0.00691  2.24332E+04 0.00501  1.69951E+04 0.01042  1.41084E+04 0.00951  1.21284E+04 0.00592  1.07460E+04 0.01190  9.97682E+03 0.01639  9.67689E+03 0.01476  9.61420E+03 0.01367  8.28862E+03 0.00789  8.09021E+03 0.01578  8.21178E+03 0.01257  7.96561E+03 0.01900  1.54679E+04 0.00904  1.50712E+04 0.00517  1.10176E+04 0.00739  7.31116E+03 0.00592  8.32896E+03 0.01273  8.13202E+03 0.01054  7.28089E+03 0.01610  1.22022E+04 0.00507  2.69590E+03 0.02052  3.31445E+03 0.02225  2.94786E+03 0.01189  1.84064E+03 0.01775  3.15216E+03 0.03272  2.07536E+03 0.01499  1.68585E+03 0.01324  3.31630E+02 0.01501  2.61513E+02 0.03985  2.22682E+02 0.05991  2.23949E+02 0.03401  2.19576E+02 0.03771  2.19739E+02 0.01196  2.77017E+02 0.04142  2.87740E+02 0.05490  5.80016E+02 0.03042  9.35882E+02 0.01637  1.18042E+03 0.03507  3.31667E+03 0.02159  3.55316E+03 0.01651  4.27374E+03 0.01208  3.20458E+03 0.00579  2.53535E+03 0.02578  2.07671E+03 0.02299  2.47648E+03 0.01012  4.99106E+03 0.01148  7.36158E+03 0.01257  1.54960E+04 0.00671  2.53025E+04 0.00971  4.01551E+04 0.01070  2.65792E+04 0.01144  1.92974E+04 0.01101  1.40836E+04 0.01490  1.25969E+04 0.01055  1.27767E+04 0.01370  1.05828E+04 0.00939  7.11663E+03 0.01253  6.61720E+03 0.01001  5.84206E+03 0.01286  5.02174E+03 0.01504  4.05451E+03 0.00371  2.70761E+03 0.01881  9.28254E+02 0.02669 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  5.54939E-01 0.00534 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  5.28621E+18 0.00560  2.87502E+18 0.00414 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  4.73865E-01 0.00081  1.19740E+00 0.00080 ];
INF_CAPT                  (idx, [1:   4]) = [  6.29527E-03 0.00611  2.20995E-02 0.00188 ];
INF_ABS                   (idx, [1:   4]) = [  6.91244E-03 0.00560  2.91313E-02 0.00219 ];
INF_FISS                  (idx, [1:   4]) = [  6.17173E-04 0.00273  7.03183E-03 0.00325 ];
INF_NSF                   (idx, [1:   4]) = [  1.73861E-03 0.00233  1.99619E-02 0.00325 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.81707E+00 0.00067  2.83879E+00 1.8E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.06808E+02 1.6E-05  2.08365E+02 2.5E-06 ];
INF_INVV                  (idx, [1:   4]) = [  5.96994E-08 0.00699  2.69851E-06 0.00120 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  4.66969E-01 0.00085  1.16828E+00 0.00095 ];
INF_SCATT1                (idx, [1:   4]) = [  2.21622E-01 0.00122  2.92704E-01 0.00142 ];
INF_SCATT2                (idx, [1:   4]) = [  8.83970E-02 0.00127  6.71719E-02 0.00283 ];
INF_SCATT3                (idx, [1:   4]) = [  5.99372E-03 0.02757  1.99942E-02 0.01647 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.52418E-03 0.01308 -7.29133E-03 0.06679 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.76981E-04 0.63723  5.03838E-03 0.08958 ];
INF_SCATT6                (idx, [1:   4]) = [  4.51061E-03 0.01248 -1.24471E-02 0.02181 ];
INF_SCATT7                (idx, [1:   4]) = [  8.71876E-04 0.19875  6.58837E-04 0.28007 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  4.67003E-01 0.00085  1.16828E+00 0.00095 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.21620E-01 0.00122  2.92704E-01 0.00142 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.83979E-02 0.00127  6.71719E-02 0.00283 ];
INF_SCATTP3               (idx, [1:   4]) = [  5.99511E-03 0.02755  1.99942E-02 0.01647 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.52425E-03 0.01315 -7.29133E-03 0.06679 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.75760E-04 0.64835  5.03838E-03 0.08958 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.51043E-03 0.01254 -1.24471E-02 0.02181 ];
INF_SCATTP7               (idx, [1:   4]) = [  8.72727E-04 0.19784  6.58837E-04 0.28007 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  1.94645E-01 0.00076  8.05369E-01 0.00152 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.71252E+00 0.00076  4.13893E-01 0.00152 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.87890E-03 0.00575  2.91313E-02 0.00219 ];
INF_REMXS                 (idx, [1:   4]) = [  2.29863E-02 0.00154  2.95858E-02 0.00678 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.50879E-01 0.00079  1.60903E-02 0.00397  4.67257E-04 0.04566  1.16782E+00 0.00096 ];
INF_S1                    (idx, [1:   8]) = [  2.16902E-01 0.00118  4.71979E-03 0.01008  2.10834E-04 0.09600  2.92493E-01 0.00143 ];
INF_S2                    (idx, [1:   8]) = [  8.97860E-02 0.00156 -1.38900E-03 0.03221  1.16008E-04 0.13164  6.70559E-02 0.00283 ];
INF_S3                    (idx, [1:   8]) = [  7.62979E-03 0.02223 -1.63608E-03 0.01282  3.73395E-05 0.38330  1.99569E-02 0.01682 ];
INF_S4                    (idx, [1:   8]) = [ -9.02159E-03 0.01377 -5.02587E-04 0.05887  4.20073E-06 1.00000 -7.29553E-03 0.06657 ];
INF_S5                    (idx, [1:   8]) = [ -1.91795E-04 0.57939  1.48139E-05 0.83347 -1.61801E-05 0.49788  5.05456E-03 0.08894 ];
INF_S6                    (idx, [1:   8]) = [  4.67811E-03 0.00988 -1.67500E-04 0.06387 -2.26321E-05 0.38896 -1.24245E-02 0.02170 ];
INF_S7                    (idx, [1:   8]) = [  1.03999E-03 0.16705 -1.68110E-04 0.14788 -2.84952E-05 0.28803  6.87332E-04 0.26556 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.50913E-01 0.00078  1.60903E-02 0.00397  4.67257E-04 0.04566  1.16782E+00 0.00096 ];
INF_SP1                   (idx, [1:   8]) = [  2.16901E-01 0.00118  4.71979E-03 0.01008  2.10834E-04 0.09600  2.92493E-01 0.00143 ];
INF_SP2                   (idx, [1:   8]) = [  8.97869E-02 0.00156 -1.38900E-03 0.03221  1.16008E-04 0.13164  6.70559E-02 0.00283 ];
INF_SP3                   (idx, [1:   8]) = [  7.63119E-03 0.02222 -1.63608E-03 0.01282  3.73395E-05 0.38330  1.99569E-02 0.01682 ];
INF_SP4                   (idx, [1:   8]) = [ -9.02166E-03 0.01387 -5.02587E-04 0.05887  4.20073E-06 1.00000 -7.29553E-03 0.06657 ];
INF_SP5                   (idx, [1:   8]) = [ -1.90574E-04 0.58912  1.48139E-05 0.83347 -1.61801E-05 0.49788  5.05456E-03 0.08894 ];
INF_SP6                   (idx, [1:   8]) = [  4.67793E-03 0.00993 -1.67500E-04 0.06387 -2.26321E-05 0.38896 -1.24245E-02 0.02170 ];
INF_SP7                   (idx, [1:   8]) = [  1.04084E-03 0.16633 -1.68110E-04 0.14788 -2.84952E-05 0.28803  6.87332E-04 0.26556 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.00681E-01 0.00701  6.45581E-01 0.02404 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.03245E-01 0.01102  6.52293E-01 0.02455 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  1.99969E-01 0.00856  6.68163E-01 0.03428 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  1.98953E-01 0.00679  6.19590E-01 0.02170 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.66134E+00 0.00704  5.17536E-01 0.02422 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.64085E+00 0.01101  5.12239E-01 0.02429 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.66742E+00 0.00856  5.01389E-01 0.03654 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.67574E+00 0.00682  5.38978E-01 0.02113 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  4.97171E-03 0.10843  8.37447E-05 0.62545  1.02467E-03 0.22262  5.51691E-04 0.30367  2.14991E-03 0.17277  9.47499E-04 0.21637  2.14195E-04 0.38010 ];
LAMBDA                    (idx, [1:  14]) = [  6.81595E-01 0.19936  1.28043E-02 0.01603  3.02450E-02 0.00307  1.13361E-01 0.00698  3.19303E-01 0.00462  1.15885E+00 0.03164  7.68884E+00 0.13548 ];

