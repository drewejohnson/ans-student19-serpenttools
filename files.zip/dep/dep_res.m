
% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:12 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00766E+00  1.01983E+00  9.76217E-01  9.96295E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 3.5E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.61051E-02 0.00838  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.83895E-01 0.00014  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.89733E-01 0.00085  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.90713E-01 0.00084  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.95967E+00 0.00271  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.15524E+01 0.00277  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.15524E+01 0.00277  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.86130E+01 0.00420  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.91959E-01 0.00890  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50084 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.00840E+02 0.00593 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.00840E+02 0.00593 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  5.22859E-01 ;
RUNNING_TIME              (idx, 1)        =  4.13450E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  3.83333E-04  3.83333E-04 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.61333E-02  3.61333E-02  0.00000E+00 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  4.13083E-01  0.00000E+00 ];
CPU_USAGE                 (idx, 1)        = 1.26462 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.97692E+00 0.00859 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  8.54194E-02 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.32680E+06 ;
TOT_DECAY_HEAT            (idx, 1)        =  7.09528E-06 ;
TOT_SF_RATE               (idx, 1)        =  8.56119E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  9.32680E+06 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  7.09528E-06 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  0.00000E+00 ;
INHALATION_TOXICITY       (idx, 1)        =  8.51863E+01 ;
INGESTION_TOXICITY        (idx, 1)        =  4.50096E-01 ;
ACTINIDE_INH_TOX          (idx, 1)        =  8.51863E+01 ;
ACTINIDE_ING_TOX          (idx, 1)        =  4.50096E-01 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  0.00000E+00 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  0.00000E+00 ;
SR90_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
TE132_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
I131_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
I132_ACTIVITY             (idx, 1)        =  0.00000E+00 ;
CS134_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
CS137_ACTIVITY            (idx, 1)        =  0.00000E+00 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.24909E+06 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  9.32204E+06 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  3.88066E+06 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  8.81088E+13 0.00426  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 0 ;
BURNUP                     (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
BURN_DAYS                 (idx, 1)        =  0.00000E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.43567E-01 0.01124 ];
U235_FISS                 (idx, [1:   4]) = [  2.34853E+16 0.00416  9.65992E-01 0.00119 ];
U238_FISS                 (idx, [1:   4]) = [  8.27286E+14 0.03553  3.39004E-02 0.03390 ];
U235_CAPT                 (idx, [1:   4]) = [  4.52997E+15 0.01416  2.29097E-01 0.01233 ];
U238_CAPT                 (idx, [1:   4]) = [  9.56408E+15 0.01082  4.83442E-01 0.00703 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50084 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 4.33498E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50084 5.00433E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 22443 2.24263E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 27641 2.76170E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50084 5.00433E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -2.91038E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  5.89746E+16 5.6E-05  5.89746E+16 5.6E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.40779E+16 6.4E-06  2.40779E+16 6.4E-06  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  1.99184E+16 0.00322  1.42869E+16 0.00399  5.63147E+15 0.00411 ];
TOT_ABSRATE               (idx, [1:   6]) = [  4.39963E+16 0.00146  3.83648E+16 0.00148  5.63147E+15 0.00411 ];
TOT_SRCRATE               (idx, [1:   6]) = [  4.40544E+16 0.00426  4.40544E+16 0.00426  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  2.59225E+18 0.00348  4.27512E+17 0.00376  2.16474E+18 0.00358 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  4.39963E+16 0.00146 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.83052E+18 0.00298 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.30153E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.84527E+00 0.00311 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.62969E-01 0.00189 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.43316E-01 0.00257 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14350E+00 0.00215 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.35288E+00 0.00386 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.35288E+00 0.00386 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.44933E+00 6.1E-05 ];
FISSE                     (idx, [1:   2]) = [  2.02431E+02 6.4E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.35413E+00 0.00420  1.34531E+00 0.00389  7.56433E-03 0.07601 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.34213E+00 0.00147 ];
COL_KEFF                  (idx, [1:   2]) = [  1.34111E+00 0.00432 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.34213E+00 0.00147 ];
ABS_KINF                  (idx, [1:   2]) = [  1.34213E+00 0.00147 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83802E+01 0.00124 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83844E+01 0.00043 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.13747E-07 0.02343 ];
IMP_EALF                  (idx, [1:   2]) = [  2.08039E-07 0.00801 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.13588E-01 0.03695 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.13248E-01 0.01032 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  4.71653E-03 0.05601  1.77986E-04 0.31608  7.46693E-04 0.13120  5.99338E-04 0.14585  2.28344E-03 0.08774  7.06688E-04 0.14676  2.02390E-04 0.24995 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.53035E-01 0.13712  1.24906E-03 0.30151  1.29851E-02 0.12058  3.85438E-02 0.13700  2.49803E-01 0.05344  4.99206E-01 0.13115  1.22252E+00 0.24932 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  5.66488E-03 0.07555  1.58032E-04 0.40964  6.32171E-04 0.21284  9.45639E-04 0.19440  2.88997E-03 0.12277  6.46176E-04 0.22259  3.92887E-04 0.30749 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  9.23411E-01 0.16044  1.24906E-02 6.8E-09  3.16828E-02 0.00219  1.10125E-01 0.00325  3.19762E-01 0.00261  1.34924E+00 0.00148  8.72589E+00 0.01026 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.65151E-05 0.00923  3.65254E-05 0.00920  2.77366E-05 0.10291 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.93581E-05 0.00814  4.93709E-05 0.00808  3.77381E-05 0.10488 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  5.71741E-03 0.07932  1.57760E-04 0.45843  7.89533E-04 0.21632  8.40929E-04 0.19805  2.91636E-03 0.12514  6.37515E-04 0.24098  3.75311E-04 0.30212 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  9.91796E-01 0.21480  1.24906E-02 0.0E+00  3.15763E-02 0.00427  1.10231E-01 0.00427  3.19646E-01 0.00316  1.34956E+00 0.00224  8.63638E+00 6.8E-09 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.63775E-05 0.01960  3.64077E-05 0.01953  6.27883E-06 0.24633 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.91649E-05 0.01903  4.92065E-05 0.01896  8.53793E-06 0.24542 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  4.55427E-03 0.24227  6.30011E-04 0.91079  1.21301E-03 0.43795  4.66585E-04 0.83465  1.62197E-03 0.37367  0.00000E+00 0.0E+00  6.22689E-04 0.73244 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  8.54487E-01 0.53554  1.24906E-02 0.0E+00  3.18241E-02 0.0E+00  1.11563E-01 0.01961  3.20757E-01 0.00795  0.00000E+00 0.0E+00  8.63638E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  4.42626E-03 0.23601  5.46158E-04 0.90350  1.08878E-03 0.42708  6.22389E-04 0.81836  1.66888E-03 0.34097  0.00000E+00 0.0E+00  5.00052E-04 0.72098 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  7.97982E-01 0.53075  1.24906E-02 0.0E+00  3.18241E-02 5.8E-09  1.11563E-01 0.01961  3.20757E-01 0.00795  0.00000E+00 0.0E+00  8.63638E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.30813E+02 0.24154 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.63400E-05 0.00571 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.91199E-05 0.00374 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  5.58366E-03 0.05049 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.55160E+02 0.05239 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.10298E-07 0.00419 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.34481E-06 0.00449  3.34649E-06 0.00450  2.90739E-06 0.07651 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.26409E-05 0.00555  5.26459E-05 0.00557  4.85001E-05 0.07419 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.43618E-01 0.00256  7.42533E-01 0.00259  1.29888E+00 0.10057 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.04309E+01 0.14677 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.15524E+01 0.00277  4.57375E+01 0.00362 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.24555E+03 0.05312  1.43476E+04 0.01465  3.18920E+04 0.01048  3.73087E+04 0.00750  3.62324E+04 0.00717  3.80421E+04 0.00486  2.62574E+04 0.00681  2.25315E+04 0.00900  1.72464E+04 0.00865  1.41894E+04 0.01005  1.20283E+04 0.00491  1.09861E+04 0.00920  9.90565E+03 0.01372  9.44480E+03 0.00366  9.14586E+03 0.00510  8.18871E+03 0.00864  7.86182E+03 0.01338  7.87552E+03 0.00892  7.90035E+03 0.00511  1.52955E+04 0.01107  1.48261E+04 0.00505  1.09715E+04 0.00668  7.11679E+03 0.01248  8.23212E+03 0.01566  7.94316E+03 0.01519  7.33225E+03 0.00434  1.22020E+04 0.00883  2.72936E+03 0.01993  3.44123E+03 0.01146  3.20486E+03 0.01970  1.77396E+03 0.01143  3.09098E+03 0.01054  2.16792E+03 0.01841  1.84944E+03 0.03382  3.97353E+02 0.01008  3.51782E+02 0.04119  3.52105E+02 0.00741  3.58235E+02 0.04815  3.65056E+02 0.03863  3.70511E+02 0.03555  3.70204E+02 0.03008  3.62556E+02 0.03321  6.68879E+02 0.02065  1.10025E+03 0.01691  1.33984E+03 0.01801  3.63082E+03 0.00727  3.79767E+03 0.01568  4.30569E+03 0.01191  2.95428E+03 0.01984  2.22925E+03 0.00911  1.77881E+03 0.01435  2.07598E+03 0.01889  3.99097E+03 0.00676  5.49395E+03 0.00567  1.05746E+04 0.00714  1.64737E+04 0.00492  2.45404E+04 0.00600  1.58664E+04 0.01023  1.13182E+04 0.00508  8.24581E+03 0.01136  7.36592E+03 0.00765  7.18392E+03 0.00890  6.02298E+03 0.01318  4.08473E+03 0.00998  3.74295E+03 0.01098  3.35182E+03 0.01119  2.74750E+03 0.01406  2.18271E+03 0.01252  1.45052E+03 0.00921  4.94855E+02 0.01876 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.34111E+00 0.00313 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.92291E+18 0.00566  6.70815E+17 0.00475 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.16986E-01 0.00113  1.24918E+00 0.00185 ];
INF_CAPT                  (idx, [1:   4]) = [  4.33085E-03 0.00724  1.73124E-02 0.00280 ];
INF_ABS                   (idx, [1:   4]) = [  5.83194E-03 0.00438  4.89693E-02 0.00388 ];
INF_FISS                  (idx, [1:   4]) = [  1.50109E-03 0.00495  3.16569E-02 0.00448 ];
INF_NSF                   (idx, [1:   4]) = [  3.81602E-03 0.00481  7.71383E-02 0.00448 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54218E+00 0.00046  2.43670E+00 0.0E+00 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03615E+02 7.5E-05  2.02270E+02 0.0E+00 ];
INF_INVV                  (idx, [1:   4]) = [  6.35410E-08 0.00182  2.56494E-06 0.00108 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.11085E-01 0.00112  1.20036E+00 0.00193 ];
INF_SCATT1                (idx, [1:   4]) = [  2.22800E-01 0.00187  3.01329E-01 0.00210 ];
INF_SCATT2                (idx, [1:   4]) = [  8.93580E-02 0.00362  7.14866E-02 0.00467 ];
INF_SCATT3                (idx, [1:   4]) = [  7.34071E-03 0.04492  2.06741E-02 0.02694 ];
INF_SCATT4                (idx, [1:   4]) = [ -8.48621E-03 0.02524 -6.72779E-03 0.09259 ];
INF_SCATT5                (idx, [1:   4]) = [  5.11260E-05 1.00000  4.87055E-03 0.06022 ];
INF_SCATT6                (idx, [1:   4]) = [  4.46737E-03 0.01651 -1.27547E-02 0.02823 ];
INF_SCATT7                (idx, [1:   4]) = [  5.95052E-04 0.23817  5.38422E-04 0.64954 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.11105E-01 0.00112  1.20036E+00 0.00193 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.22801E-01 0.00187  3.01329E-01 0.00210 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.93586E-02 0.00361  7.14866E-02 0.00467 ];
INF_SCATTP3               (idx, [1:   4]) = [  7.33954E-03 0.04499  2.06741E-02 0.02694 ];
INF_SCATTP4               (idx, [1:   4]) = [ -8.48616E-03 0.02518 -6.72779E-03 0.09259 ];
INF_SCATTP5               (idx, [1:   4]) = [  5.22949E-05 1.00000  4.87055E-03 0.06022 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.46741E-03 0.01660 -1.27547E-02 0.02823 ];
INF_SCATTP7               (idx, [1:   4]) = [  5.95819E-04 0.23685  5.38422E-04 0.64954 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.26491E-01 0.00286  8.39768E-01 0.00268 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.47178E+00 0.00286  3.96946E-01 0.00267 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.81209E-03 0.00445  4.89693E-02 0.00388 ];
INF_REMXS                 (idx, [1:   4]) = [  2.32633E-02 0.00317  4.97710E-02 0.00597 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.93723E-01 0.00107  1.73622E-02 0.00282  9.50783E-04 0.03020  1.19941E+00 0.00194 ];
INF_S1                    (idx, [1:   8]) = [  2.17764E-01 0.00176  5.03540E-03 0.00864  3.78728E-04 0.05750  3.00951E-01 0.00212 ];
INF_S2                    (idx, [1:   8]) = [  9.08354E-02 0.00336 -1.47735E-03 0.01664  2.09139E-04 0.07189  7.12774E-02 0.00454 ];
INF_S3                    (idx, [1:   8]) = [  9.10214E-03 0.03361 -1.76142E-03 0.01717  8.22778E-05 0.08811  2.05918E-02 0.02715 ];
INF_S4                    (idx, [1:   8]) = [ -7.88086E-03 0.02413 -6.05343E-04 0.05552  3.30726E-06 1.00000 -6.73110E-03 0.09297 ];
INF_S5                    (idx, [1:   8]) = [  7.49355E-05 1.00000 -2.38095E-05 1.00000 -4.65384E-05 0.13391  4.91709E-03 0.06035 ];
INF_S6                    (idx, [1:   8]) = [  4.61367E-03 0.01598 -1.46304E-04 0.08928 -5.11629E-05 0.21190 -1.27035E-02 0.02779 ];
INF_S7                    (idx, [1:   8]) = [  6.95291E-04 0.19590 -1.00239E-04 0.24806 -4.41218E-05 0.10278  5.82544E-04 0.60746 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.93743E-01 0.00107  1.73622E-02 0.00282  9.50783E-04 0.03020  1.19941E+00 0.00194 ];
INF_SP1                   (idx, [1:   8]) = [  2.17765E-01 0.00176  5.03540E-03 0.00864  3.78728E-04 0.05750  3.00951E-01 0.00212 ];
INF_SP2                   (idx, [1:   8]) = [  9.08359E-02 0.00336 -1.47735E-03 0.01664  2.09139E-04 0.07189  7.12774E-02 0.00454 ];
INF_SP3                   (idx, [1:   8]) = [  9.10097E-03 0.03367 -1.76142E-03 0.01717  8.22778E-05 0.08811  2.05918E-02 0.02715 ];
INF_SP4                   (idx, [1:   8]) = [ -7.88082E-03 0.02408 -6.05343E-04 0.05552  3.30726E-06 1.00000 -6.73110E-03 0.09297 ];
INF_SP5                   (idx, [1:   8]) = [  7.61043E-05 1.00000 -2.38095E-05 1.00000 -4.65384E-05 0.13391  4.91709E-03 0.06035 ];
INF_SP6                   (idx, [1:   8]) = [  4.61372E-03 0.01607 -1.46304E-04 0.08928 -5.11629E-05 0.21190 -1.27035E-02 0.02779 ];
INF_SP7                   (idx, [1:   8]) = [  6.96057E-04 0.19484 -1.00239E-04 0.24806 -4.41218E-05 0.10278  5.82544E-04 0.60746 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37875E-01 0.00539  7.01882E-01 0.02782 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.35272E-01 0.01058  7.28341E-01 0.02860 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.37419E-01 0.00858  6.88517E-01 0.01635 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.41170E-01 0.00843  6.93044E-01 0.04785 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40146E+00 0.00540  4.76344E-01 0.02703 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.41743E+00 0.01052  4.59120E-01 0.02782 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.40440E+00 0.00868  4.84666E-01 0.01683 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.38255E+00 0.00856  4.85247E-01 0.04617 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  5.66488E-03 0.07555  1.58032E-04 0.40964  6.32171E-04 0.21284  9.45639E-04 0.19440  2.88997E-03 0.12277  6.46176E-04 0.22259  3.92887E-04 0.30749 ];
LAMBDA                    (idx, [1:  14]) = [  9.23411E-01 0.16044  1.24906E-02 6.8E-09  3.16828E-02 0.00219  1.10125E-01 0.00325  3.19762E-01 0.00261  1.34924E+00 0.00148  8.72589E+00 0.01026 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:17 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  9.94945E-01  1.01000E+00  1.00223E+00  9.92817E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 3.0E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.59031E-02 0.01001  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.84097E-01 0.00016  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.89027E-01 0.00078  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.90000E-01 0.00077  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.96006E+00 0.00224  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.17177E+01 0.00273  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.17177E+01 0.00273  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.87466E+01 0.00375  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  7.85225E-01 0.01154  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50104 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.01040E+02 0.00676 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.01040E+02 0.00676 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  8.11822E-01 ;
RUNNING_TIME              (idx, 1)        =  5.01667E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  4.20000E-03  1.93333E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  1.02017E-01  3.59833E-02  2.99000E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  1.81500E-02  9.08333E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  7.00001E-04  7.00001E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  5.01317E-01  9.41650E-01 ];
CPU_USAGE                 (idx, 1)        = 1.61825 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.98280E+00 0.00758 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  2.41130E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.07494E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.29121E+04 ;
TOT_SF_RATE               (idx, 1)        =  8.56437E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.01202E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  7.47787E+02 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  9.73741E+16 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.21641E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  3.31487E+06 ;
INGESTION_TOXICITY        (idx, 1)        =  6.26791E+06 ;
ACTINIDE_INH_TOX          (idx, 1)        =  6.31012E+05 ;
ACTINIDE_ING_TOX          (idx, 1)        =  5.79677E+05 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  2.68386E+06 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  5.68823E+06 ;
SR90_ACTIVITY             (idx, 1)        =  1.47821E+10 ;
TE132_ACTIVITY            (idx, 1)        =  3.64238E+13 ;
I131_ACTIVITY             (idx, 1)        =  6.66363E+12 ;
I132_ACTIVITY             (idx, 1)        =  1.87532E+13 ;
CS134_ACTIVITY            (idx, 1)        =  4.28731E+05 ;
CS137_ACTIVITY            (idx, 1)        =  1.52836E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.59154E+16 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.75025E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.27834E+07 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.06955E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  9.12251E+13 0.00454  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 1 ;
BURNUP                     (idx, [1:  2])  = [  1.00000E+00  1.00125E+00 ];
BURN_DAYS                 (idx, 1)        =  1.66667E-01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.59548E-01 0.01178 ];
U235_FISS                 (idx, [1:   4]) = [  2.31865E+16 0.00469  9.63476E-01 0.00128 ];
U238_FISS                 (idx, [1:   4]) = [  8.53326E+14 0.03485  3.53670E-02 0.03418 ];
PU239_FISS                (idx, [1:   4]) = [  2.03978E+13 0.22417  8.55461E-04 0.22365 ];
U235_CAPT                 (idx, [1:   4]) = [  4.69720E+15 0.01344  2.17599E-01 0.01134 ];
U238_CAPT                 (idx, [1:   4]) = [  9.94871E+15 0.01140  4.60615E-01 0.00774 ];
PU239_CAPT                (idx, [1:   4]) = [  5.54515E+12 0.39973  2.65483E-04 0.39949 ];
PU240_CAPT                (idx, [1:   4]) = [  5.31406E+12 0.46958  2.55099E-04 0.46397 ];
XE135_CAPT                (idx, [1:   4]) = [  6.21748E+14 0.03291  2.89136E-02 0.03310 ];
SM149_CAPT                (idx, [1:   4]) = [  4.35549E+12 0.43881  2.12284E-04 0.43834 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50104 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.30264E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50104 5.00530E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 23667 2.36476E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 26437 2.64055E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50104 5.00530E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.91038E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  5.89889E+16 6.7E-05  5.89889E+16 6.7E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.40772E+16 7.7E-06  2.40772E+16 7.7E-06  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  2.13767E+16 0.00347  1.54882E+16 0.00450  5.88848E+15 0.00489 ];
TOT_ABSRATE               (idx, [1:   6]) = [  4.54538E+16 0.00163  3.95653E+16 0.00176  5.88848E+15 0.00489 ];
TOT_SRCRATE               (idx, [1:   6]) = [  4.56126E+16 0.00454  4.56126E+16 0.00454  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  2.68743E+18 0.00401  4.42653E+17 0.00467  2.24478E+18 0.00404 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  4.54538E+16 0.00163 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.90286E+18 0.00355 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.30018E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.30018E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.77279E+00 0.00315 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.58864E-01 0.00219 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.43778E-01 0.00267 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14304E+00 0.00255 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.29387E+00 0.00436 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.29387E+00 0.00436 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.44999E+00 7.3E-05 ];
FISSE                     (idx, [1:   2]) = [  2.02437E+02 7.7E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.29311E+00 0.00458  1.28525E+00 0.00443  8.61613E-03 0.08303 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.29956E+00 0.00161 ];
COL_KEFF                  (idx, [1:   2]) = [  1.29587E+00 0.00450 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.29956E+00 0.00161 ];
ABS_KINF                  (idx, [1:   2]) = [  1.29956E+00 0.00161 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83721E+01 0.00141 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83664E+01 0.00052 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.17326E-07 0.02783 ];
IMP_EALF                  (idx, [1:   2]) = [  2.12089E-07 0.00951 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.16279E-01 0.03666 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.16634E-01 0.01216 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.09576E-03 0.06294  1.39879E-04 0.32012  6.61860E-04 0.15096  7.40116E-04 0.15044  2.58575E-03 0.08959  6.26703E-04 0.15362  3.41454E-04 0.22539 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  8.98785E-01 0.15352  1.12415E-03 0.31958  1.11070E-02 0.13697  4.07204E-02 0.13117  2.61993E-01 0.04714  4.57703E-01 0.14004  1.66776E+00 0.20780 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  6.86801E-03 0.08637  1.80281E-04 0.50144  8.47598E-04 0.18101  8.29317E-04 0.20406  3.78574E-03 0.13524  7.38105E-04 0.19938  4.86970E-04 0.27185 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  1.13153E+00 0.17652  1.24906E-02 5.6E-09  3.17699E-02 0.00143  1.09823E-01 0.00246  3.19255E-01 0.00222  1.34613E+00 0.00186  8.77064E+00 0.01054 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.83455E-05 0.00839  3.83364E-05 0.00838  2.95243E-05 0.10975 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  4.94989E-05 0.00752  4.94897E-05 0.00757  3.77352E-05 0.10984 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.71835E-03 0.08683  6.19952E-05 0.73266  9.78340E-04 0.19688  8.54342E-04 0.22848  3.46755E-03 0.11249  9.24175E-04 0.21565  4.31951E-04 0.30134 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  1.01202E+00 0.20178  1.24906E-02 0.0E+00  3.16876E-02 0.00253  1.09721E-01 0.00315  3.19425E-01 0.00270  1.34332E+00 0.00263  8.75844E+00 0.01394 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.89453E-05 0.01958  3.88810E-05 0.01967  9.88563E-06 0.26025 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  5.03036E-05 0.01942  5.02205E-05 0.01953  1.27495E-05 0.26032 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  4.46030E-03 0.26639  3.33142E-04 0.71001  3.62081E-04 0.71528  9.11752E-04 0.58230  1.72868E-03 0.37659  8.91885E-04 0.54271  2.32755E-04 0.87533 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  1.18759E+00 0.46153  1.24906E-02 0.0E+00  3.18241E-02 0.0E+00  1.09375E-01 0.0E+00  3.19216E-01 0.00697  1.33631E+00 0.00764  8.63638E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  4.45667E-03 0.24692  3.30739E-04 0.71462  4.19343E-04 0.72114  9.14017E-04 0.53932  1.69090E-03 0.35783  8.73828E-04 0.52515  2.27834E-04 0.83925 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  1.18980E+00 0.46045  1.24906E-02 0.0E+00  3.18241E-02 0.0E+00  1.09375E-01 0.0E+00  3.19216E-01 0.00697  1.33631E+00 0.00764  8.63638E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.16363E+02 0.25817 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.86647E-05 0.00591 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.98957E-05 0.00385 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  5.74639E-03 0.05079 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.48367E+02 0.04945 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.16782E-07 0.00405 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.39014E-06 0.00458  3.39250E-06 0.00460  2.99316E-06 0.06450 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.30882E-05 0.00510  5.30963E-05 0.00508  4.93949E-05 0.06754 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.44123E-01 0.00267  7.42502E-01 0.00272  1.36513E+00 0.09111 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  9.76666E+00 0.17225 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.17177E+01 0.00273  4.58131E+01 0.00343 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.28118E+03 0.02160  1.44783E+04 0.01993  3.07119E+04 0.00757  3.75970E+04 0.01012  3.59999E+04 0.00926  3.77388E+04 0.00326  2.61015E+04 0.00537  2.22952E+04 0.00477  1.72817E+04 0.00871  1.40693E+04 0.00317  1.20081E+04 0.00456  1.09913E+04 0.00588  1.00360E+04 0.00703  9.57682E+03 0.00436  9.13811E+03 0.00933  8.19360E+03 0.01216  8.09487E+03 0.01815  8.02355E+03 0.00947  7.92247E+03 0.00826  1.53698E+04 0.00678  1.46635E+04 0.00598  1.09524E+04 0.00773  7.19158E+03 0.00988  8.19545E+03 0.01035  7.85745E+03 0.00912  7.07910E+03 0.01187  1.23726E+04 0.00895  2.75219E+03 0.01288  3.37650E+03 0.01230  3.12576E+03 0.01312  1.88217E+03 0.03034  3.16195E+03 0.02196  2.17938E+03 0.03073  1.88385E+03 0.02054  3.54042E+02 0.03220  3.56008E+02 0.01548  3.67071E+02 0.04092  3.65716E+02 0.02471  3.59655E+02 0.02628  3.60287E+02 0.02846  3.75017E+02 0.03592  3.54097E+02 0.02531  6.22413E+02 0.04776  1.07607E+03 0.03877  1.38195E+03 0.03165  3.65549E+03 0.02402  3.81970E+03 0.02473  4.24230E+03 0.01185  2.94788E+03 0.01180  2.26586E+03 0.01076  1.67748E+03 0.02617  2.16646E+03 0.01496  4.06375E+03 0.01015  5.53910E+03 0.01682  1.09014E+04 0.01203  1.67248E+04 0.00887  2.54823E+04 0.01265  1.60755E+04 0.01055  1.14580E+04 0.00767  8.18506E+03 0.00669  7.37264E+03 0.00934  7.20078E+03 0.00442  5.93891E+03 0.01344  4.07138E+03 0.00688  3.78182E+03 0.00847  3.30133E+03 0.01542  2.81016E+03 0.01032  2.21416E+03 0.01780  1.46901E+03 0.01838  5.03508E+02 0.03004 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.29587E+00 0.00661 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  1.98516E+18 0.00765  7.03269E+17 0.00172 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.18249E-01 0.00152  1.24476E+00 0.00165 ];
INF_CAPT                  (idx, [1:   4]) = [  4.39436E-03 0.00552  1.80196E-02 0.00123 ];
INF_ABS                   (idx, [1:   4]) = [  5.85874E-03 0.00496  4.81863E-02 0.00176 ];
INF_FISS                  (idx, [1:   4]) = [  1.46438E-03 0.00512  3.01668E-02 0.00212 ];
INF_NSF                   (idx, [1:   4]) = [  3.72676E-03 0.00525  7.35153E-02 0.00212 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54494E+00 0.00076  2.43696E+00 5.0E-07 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03639E+02 7.3E-05  2.02272E+02 7.7E-08 ];
INF_INVV                  (idx, [1:   4]) = [  6.37909E-08 0.00775  2.56056E-06 0.00145 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.12337E-01 0.00159  1.19652E+00 0.00154 ];
INF_SCATT1                (idx, [1:   4]) = [  2.23529E-01 0.00182  2.98375E-01 0.00430 ];
INF_SCATT2                (idx, [1:   4]) = [  8.90697E-02 0.00373  7.07568E-02 0.00821 ];
INF_SCATT3                (idx, [1:   4]) = [  6.95518E-03 0.02010  2.16117E-02 0.02598 ];
INF_SCATT4                (idx, [1:   4]) = [ -8.81804E-03 0.02046 -6.24130E-03 0.03119 ];
INF_SCATT5                (idx, [1:   4]) = [  1.77390E-04 0.67812  5.38638E-03 0.11971 ];
INF_SCATT6                (idx, [1:   4]) = [  4.56279E-03 0.02967 -1.24648E-02 0.03814 ];
INF_SCATT7                (idx, [1:   4]) = [  7.70522E-04 0.17741  4.36897E-04 0.75675 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.12362E-01 0.00159  1.19652E+00 0.00154 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.23528E-01 0.00182  2.98375E-01 0.00430 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.90710E-02 0.00372  7.07568E-02 0.00821 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.95586E-03 0.02004  2.16117E-02 0.02598 ];
INF_SCATTP4               (idx, [1:   4]) = [ -8.81681E-03 0.02046 -6.24130E-03 0.03119 ];
INF_SCATTP5               (idx, [1:   4]) = [  1.76269E-04 0.68427  5.38638E-03 0.11971 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.56359E-03 0.02962 -1.24648E-02 0.03814 ];
INF_SCATTP7               (idx, [1:   4]) = [  7.68765E-04 0.17710  4.36897E-04 0.75675 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27096E-01 0.00245  8.38518E-01 0.00235 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46784E+00 0.00245  3.97536E-01 0.00233 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.83437E-03 0.00522  4.81863E-02 0.00176 ];
INF_REMXS                 (idx, [1:   4]) = [  2.33397E-02 0.00163  4.91954E-02 0.00852 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.94909E-01 0.00154  1.74280E-02 0.00391  9.53940E-04 0.04536  1.19556E+00 0.00154 ];
INF_S1                    (idx, [1:   8]) = [  2.18389E-01 0.00199  5.13985E-03 0.01287  3.37699E-04 0.04499  2.98037E-01 0.00427 ];
INF_S2                    (idx, [1:   8]) = [  9.05295E-02 0.00405 -1.45973E-03 0.03225  1.80193E-04 0.12910  7.05766E-02 0.00798 ];
INF_S3                    (idx, [1:   8]) = [  8.74396E-03 0.01660 -1.78878E-03 0.02371  6.36974E-05 0.24897  2.15480E-02 0.02568 ];
INF_S4                    (idx, [1:   8]) = [ -8.20039E-03 0.01873 -6.17645E-04 0.04842  5.32466E-06 1.00000 -6.24663E-03 0.03150 ];
INF_S5                    (idx, [1:   8]) = [  1.94858E-04 0.51815 -1.74674E-05 1.00000 -5.04186E-05 0.14070  5.43680E-03 0.11737 ];
INF_S6                    (idx, [1:   8]) = [  4.72215E-03 0.02811 -1.59359E-04 0.06254 -4.49666E-05 0.09671 -1.24199E-02 0.03816 ];
INF_S7                    (idx, [1:   8]) = [  9.35610E-04 0.14310 -1.65088E-04 0.14044 -2.78488E-05 0.12077  4.64745E-04 0.70788 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.94934E-01 0.00154  1.74280E-02 0.00391  9.53940E-04 0.04536  1.19556E+00 0.00154 ];
INF_SP1                   (idx, [1:   8]) = [  2.18388E-01 0.00198  5.13985E-03 0.01287  3.37699E-04 0.04499  2.98037E-01 0.00427 ];
INF_SP2                   (idx, [1:   8]) = [  9.05307E-02 0.00405 -1.45973E-03 0.03225  1.80193E-04 0.12910  7.05766E-02 0.00798 ];
INF_SP3                   (idx, [1:   8]) = [  8.74464E-03 0.01658 -1.78878E-03 0.02371  6.36974E-05 0.24897  2.15480E-02 0.02568 ];
INF_SP4                   (idx, [1:   8]) = [ -8.19917E-03 0.01873 -6.17645E-04 0.04842  5.32466E-06 1.00000 -6.24663E-03 0.03150 ];
INF_SP5                   (idx, [1:   8]) = [  1.93736E-04 0.52255 -1.74674E-05 1.00000 -5.04186E-05 0.14070  5.43680E-03 0.11737 ];
INF_SP6                   (idx, [1:   8]) = [  4.72295E-03 0.02805 -1.59359E-04 0.06254 -4.49666E-05 0.09671 -1.24199E-02 0.03816 ];
INF_SP7                   (idx, [1:   8]) = [  9.33853E-04 0.14280 -1.65088E-04 0.14044 -2.78488E-05 0.12077  4.64745E-04 0.70788 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37746E-01 0.00304  7.50559E-01 0.05603 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.40004E-01 0.01041  7.62866E-01 0.07796 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.38752E-01 0.00761  7.50968E-01 0.02860 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.34725E-01 0.00712  7.45318E-01 0.07237 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40211E+00 0.00304  4.49603E-01 0.05479 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.38947E+00 0.01036  4.46429E-01 0.06877 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.39647E+00 0.00760  4.45350E-01 0.02905 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.42039E+00 0.00714  4.57029E-01 0.07447 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  6.86801E-03 0.08637  1.80281E-04 0.50144  8.47598E-04 0.18101  8.29317E-04 0.20406  3.78574E-03 0.13524  7.38105E-04 0.19938  4.86970E-04 0.27185 ];
LAMBDA                    (idx, [1:  14]) = [  1.13153E+00 0.17652  1.24906E-02 5.6E-09  3.17699E-02 0.00143  1.09823E-01 0.00246  3.19255E-01 0.00222  1.34613E+00 0.00186  8.77064E+00 0.01054 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:23 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00352E+00  1.01007E+00  9.98988E-01  9.87429E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.62011E-02 0.00795  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.83799E-01 0.00013  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.89119E-01 0.00074  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.90112E-01 0.00074  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.97122E+00 0.00269  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.20332E+01 0.00279  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.20332E+01 0.00279  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.88801E+01 0.00398  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  8.05331E-01 0.00875  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50081 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.00810E+02 0.00575 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.00810E+02 0.00575 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.10441E+00 ;
RUNNING_TIME              (idx, 1)        =  5.91283E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  8.63334E-03  2.21667E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  1.68683E-01  3.63167E-02  3.03500E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  3.63000E-02  9.11667E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  1.36667E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  5.90933E-01  9.46933E-01 ];
CPU_USAGE                 (idx, 1)        = 1.86782 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.98554E+00 0.00756 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  3.51862E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.13427E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.42105E+04 ;
TOT_SF_RATE               (idx, 1)        =  8.59266E+01 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  1.10545E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  8.27174E+02 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.02372E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  4.33831E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  5.36045E+06 ;
INGESTION_TOXICITY        (idx, 1)        =  9.89629E+06 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.09977E+06 ;
ACTINIDE_ING_TOX          (idx, 1)        =  9.56291E+05 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  4.26067E+06 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  8.94000E+06 ;
SR90_ACTIVITY             (idx, 1)        =  2.98436E+10 ;
TE132_ACTIVITY            (idx, 1)        =  7.20534E+13 ;
I131_ACTIVITY             (idx, 1)        =  1.58267E+13 ;
I132_ACTIVITY             (idx, 1)        =  5.26112E+13 ;
CS134_ACTIVITY            (idx, 1)        =  2.55790E+06 ;
CS137_ACTIVITY            (idx, 1)        =  3.09414E+10 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  9.05407E+16 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  2.75034E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.58921E+07 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.13891E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  9.33523E+13 0.00462  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 2 ;
BURNUP                     (idx, [1:  2])  = [  2.00000E+00  2.00265E+00 ];
BURN_DAYS                 (idx, 1)        =  3.33333E-01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  3.63753E-01 0.01011 ];
U235_FISS                 (idx, [1:   4]) = [  2.31972E+16 0.00562  9.62027E-01 0.00121 ];
U238_FISS                 (idx, [1:   4]) = [  8.29350E+14 0.03255  3.43736E-02 0.03178 ];
PU239_FISS                (idx, [1:   4]) = [  7.70847E+13 0.10742  3.21832E-03 0.10808 ];
PU241_FISS                (idx, [1:   4]) = [  1.90199E+12 0.70453  7.94903E-05 0.70409 ];
U235_CAPT                 (idx, [1:   4]) = [  4.67590E+15 0.01497  2.06851E-01 0.01327 ];
U238_CAPT                 (idx, [1:   4]) = [  1.00561E+16 0.00997  4.45243E-01 0.00840 ];
PU239_CAPT                (idx, [1:   4]) = [  2.29204E+13 0.20604  9.76356E-04 0.20389 ];
PU240_CAPT                (idx, [1:   4]) = [  2.52419E+13 0.18855  1.12499E-03 0.18972 ];
XE135_CAPT                (idx, [1:   4]) = [  9.59192E+14 0.03030  4.26558E-02 0.03103 ];
SM149_CAPT                (idx, [1:   4]) = [  1.67926E+13 0.25759  7.47038E-04 0.25708 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50081 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 4.62398E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50081 5.00462E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 24226 2.42073E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 25855 2.58389E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50081 5.00462E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -4.36557E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  5.90174E+16 7.3E-05  5.90174E+16 7.3E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.40750E+16 8.8E-06  2.40750E+16 8.8E-06  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  2.24863E+16 0.00365  1.63612E+16 0.00466  6.12503E+15 0.00385 ];
TOT_ABSRATE               (idx, [1:   6]) = [  4.65613E+16 0.00176  4.04362E+16 0.00188  6.12503E+15 0.00385 ];
TOT_SRCRATE               (idx, [1:   6]) = [  4.66761E+16 0.00462  4.66761E+16 0.00462  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  2.76013E+18 0.00364  4.55793E+17 0.00435  2.30434E+18 0.00367 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  4.65613E+16 0.00176 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  1.96205E+18 0.00322 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.29883E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.29883E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.73321E+00 0.00330 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.54911E-01 0.00240 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.45905E-01 0.00247 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.14682E+00 0.00239 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  1.26673E+00 0.00401 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  1.26673E+00 0.00401 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.45139E+00 8.0E-05 ];
FISSE                     (idx, [1:   2]) = [  2.02455E+02 8.8E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  1.26831E+00 0.00409  1.25869E+00 0.00404  8.04313E-03 0.07545 ];
IMP_KEFF                  (idx, [1:   2]) = [  1.26930E+00 0.00174 ];
COL_KEFF                  (idx, [1:   2]) = [  1.26704E+00 0.00457 ];
ABS_KEFF                  (idx, [1:   2]) = [  1.26930E+00 0.00174 ];
ABS_KINF                  (idx, [1:   2]) = [  1.26930E+00 0.00174 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.83488E+01 0.00127 ];
IMP_ALF                   (idx, [1:   2]) = [  1.83389E+01 0.00057 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  2.20630E-07 0.02291 ];
IMP_EALF                  (idx, [1:   2]) = [  2.18243E-07 0.01082 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.17296E-01 0.03524 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.20978E-01 0.01297 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  5.51290E-03 0.04761  2.06173E-04 0.26054  8.72032E-04 0.12494  9.16238E-04 0.12424  2.62734E-03 0.07575  6.43331E-04 0.15513  2.47777E-04 0.23066 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.32646E-01 0.14341  1.62377E-03 0.26000  1.39398E-02 0.11340  4.94375E-02 0.11114  2.65217E-01 0.04553  4.57585E-01 0.14004  1.43553E+00 0.23086 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  7.02799E-03 0.07878  2.99915E-04 0.38477  1.36589E-03 0.15754  1.29923E-03 0.18243  3.04355E-03 0.11357  7.97317E-04 0.18589  2.22088E-04 0.34294 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  6.37576E-01 0.20116  1.24906E-02 5.5E-09  3.16814E-02 0.00217  1.09901E-01 0.00247  3.19844E-01 0.00238  1.34455E+00 0.00203  8.97204E+00 0.01673 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  3.97454E-05 0.00890  3.97338E-05 0.00894  2.87265E-05 0.11589 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  5.03303E-05 0.00800  5.03166E-05 0.00807  3.61568E-05 0.11588 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  6.44595E-03 0.07722  1.99788E-04 0.43887  1.15996E-03 0.17231  1.09235E-03 0.18423  2.83431E-03 0.11532  8.84039E-04 0.19087  2.75497E-04 0.36638 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.35826E-01 0.21393  1.24906E-02 0.0E+00  3.17120E-02 0.00245  1.09585E-01 0.00235  3.18573E-01 0.00217  1.34595E+00 0.00240  9.01999E+00 0.02745 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  3.95571E-05 0.01980  3.95644E-05 0.01996  1.22972E-05 0.26983 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  5.00898E-05 0.01944  5.00988E-05 0.01957  1.55944E-05 0.27058 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  7.09764E-03 0.21610  6.65630E-04 0.78103  2.17946E-03 0.48011  1.05264E-04 0.71467  3.88059E-03 0.28161  2.66687E-04 0.70356  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  2.90374E-01 0.21364  1.24906E-02 0.0E+00  3.18241E-02 0.0E+00  1.09375E-01 0.0E+00  3.20051E-01 0.00653  1.35398E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  7.10104E-03 0.21757  6.46499E-04 0.79724  2.33547E-03 0.47329  1.20623E-04 0.73216  3.78792E-03 0.27875  2.10527E-04 0.70830  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  2.90597E-01 0.21343  1.24906E-02 1.5E-08  3.18241E-02 0.0E+00  1.09375E-01 0.0E+00  3.20051E-01 0.00653  1.35398E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -1.84637E+02 0.23866 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  3.92974E-05 0.00586 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  4.97531E-05 0.00388 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  7.18319E-03 0.03874 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.82424E+02 0.03829 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  7.26121E-07 0.00396 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.37092E-06 0.00448  3.37239E-06 0.00452  3.04819E-06 0.05440 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.38518E-05 0.00483  5.38104E-05 0.00484  5.27819E-05 0.07004 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.46270E-01 0.00246  7.45219E-01 0.00256  1.16286E+00 0.08918 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.21019E+01 0.17397 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.20332E+01 0.00279  4.59940E+01 0.00330 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.46579E+03 0.04472  1.45014E+04 0.00745  3.16602E+04 0.00645  3.73760E+04 0.00720  3.56966E+04 0.00890  3.76870E+04 0.00614  2.58855E+04 0.01370  2.24889E+04 0.00246  1.69935E+04 0.00939  1.38980E+04 0.00391  1.19332E+04 0.00834  1.08170E+04 0.01082  1.01033E+04 0.00937  9.59553E+03 0.01118  9.36509E+03 0.00716  8.09942E+03 0.01340  7.88974E+03 0.01135  8.01911E+03 0.00786  8.02670E+03 0.01066  1.52869E+04 0.00805  1.48629E+04 0.00794  1.09002E+04 0.00835  6.97215E+03 0.00878  8.46550E+03 0.01479  7.99373E+03 0.00791  7.21726E+03 0.01645  1.21303E+04 0.01211  2.71899E+03 0.01292  3.45444E+03 0.01087  3.14273E+03 0.01513  1.81806E+03 0.02042  3.21002E+03 0.01091  2.22880E+03 0.01630  1.87143E+03 0.01845  3.63742E+02 0.03050  3.44948E+02 0.04264  3.50599E+02 0.04810  3.73290E+02 0.05513  3.59883E+02 0.05142  3.49394E+02 0.06563  3.84605E+02 0.03293  3.49759E+02 0.03936  6.60639E+02 0.03339  1.05065E+03 0.01941  1.35130E+03 0.01052  3.71832E+03 0.01369  3.82246E+03 0.01832  4.17746E+03 0.01326  2.95377E+03 0.00745  2.25253E+03 0.01029  1.77027E+03 0.01253  2.17239E+03 0.01131  4.06002E+03 0.02017  5.56547E+03 0.00494  1.10061E+04 0.00154  1.68872E+04 0.00988  2.54248E+04 0.00643  1.63869E+04 0.00611  1.17137E+04 0.01085  8.44172E+03 0.00526  7.46568E+03 0.01068  7.42311E+03 0.00418  6.14195E+03 0.00656  4.13111E+03 0.01481  3.80909E+03 0.00752  3.46956E+03 0.01225  2.90310E+03 0.01353  2.25366E+03 0.01128  1.50407E+03 0.01093  5.38599E+02 0.03081 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  1.26704E+00 0.00311 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  2.03241E+18 0.00265  7.29408E+17 0.00268 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.17934E-01 0.00134  1.24918E+00 0.00123 ];
INF_CAPT                  (idx, [1:   4]) = [  4.41000E-03 0.01036  1.85733E-02 0.00135 ];
INF_ABS                   (idx, [1:   4]) = [  5.85908E-03 0.00764  4.76107E-02 0.00176 ];
INF_FISS                  (idx, [1:   4]) = [  1.44908E-03 0.00854  2.90374E-02 0.00207 ];
INF_NSF                   (idx, [1:   4]) = [  3.69219E-03 0.00822  7.07913E-02 0.00207 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.54799E+00 0.00046  2.43794E+00 1.7E-06 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.03676E+02 3.4E-05  2.02285E+02 3.0E-07 ];
INF_INVV                  (idx, [1:   4]) = [  6.39049E-08 0.00150  2.57220E-06 0.00142 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.12077E-01 0.00138  1.20145E+00 0.00123 ];
INF_SCATT1                (idx, [1:   4]) = [  2.22943E-01 0.00239  3.00767E-01 0.00262 ];
INF_SCATT2                (idx, [1:   4]) = [  8.88595E-02 0.00221  7.17029E-02 0.00808 ];
INF_SCATT3                (idx, [1:   4]) = [  6.67706E-03 0.03047  2.12049E-02 0.02235 ];
INF_SCATT4                (idx, [1:   4]) = [ -8.90684E-03 0.01430 -7.07945E-03 0.08879 ];
INF_SCATT5                (idx, [1:   4]) = [  2.09926E-04 0.84832  4.67590E-03 0.07180 ];
INF_SCATT6                (idx, [1:   4]) = [  4.78051E-03 0.03089 -1.27720E-02 0.02519 ];
INF_SCATT7                (idx, [1:   4]) = [  8.73239E-04 0.15745  6.43029E-05 1.00000 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.12098E-01 0.00138  1.20145E+00 0.00123 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.22942E-01 0.00238  3.00767E-01 0.00262 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.88592E-02 0.00221  7.17029E-02 0.00808 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.67716E-03 0.03067  2.12049E-02 0.02235 ];
INF_SCATTP4               (idx, [1:   4]) = [ -8.90550E-03 0.01431 -7.07945E-03 0.08879 ];
INF_SCATTP5               (idx, [1:   4]) = [  2.09997E-04 0.85065  4.67590E-03 0.07180 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.77987E-03 0.03092 -1.27720E-02 0.02519 ];
INF_SCATTP7               (idx, [1:   4]) = [  8.73176E-04 0.15752  6.43029E-05 1.00000 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.27087E-01 0.00311  8.40348E-01 0.00156 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.46792E+00 0.00311  3.96665E-01 0.00156 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  5.83784E-03 0.00779  4.76107E-02 0.00176 ];
INF_REMXS                 (idx, [1:   4]) = [  2.32977E-02 0.00149  4.85978E-02 0.00297 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.94636E-01 0.00137  1.74410E-02 0.00196  8.65939E-04 0.03808  1.20058E+00 0.00126 ];
INF_S1                    (idx, [1:   8]) = [  2.17877E-01 0.00241  5.06586E-03 0.01330  3.53015E-04 0.07065  3.00414E-01 0.00259 ];
INF_S2                    (idx, [1:   8]) = [  9.03403E-02 0.00210 -1.48076E-03 0.02279  2.03711E-04 0.09140  7.14992E-02 0.00795 ];
INF_S3                    (idx, [1:   8]) = [  8.43729E-03 0.01910 -1.76024E-03 0.03085  6.75713E-05 0.09407  2.11374E-02 0.02240 ];
INF_S4                    (idx, [1:   8]) = [ -8.27257E-03 0.01461 -6.34276E-04 0.04543  5.16254E-07 1.00000 -7.07997E-03 0.08849 ];
INF_S5                    (idx, [1:   8]) = [  2.11604E-04 0.81142 -1.67815E-06 1.00000 -5.46226E-05 0.21490  4.73052E-03 0.06943 ];
INF_S6                    (idx, [1:   8]) = [  4.90206E-03 0.02978 -1.21557E-04 0.16431 -5.00545E-05 0.18430 -1.27219E-02 0.02593 ];
INF_S7                    (idx, [1:   8]) = [  9.89077E-04 0.13143 -1.15837E-04 0.17262 -4.32225E-05 0.37662  1.07525E-04 1.00000 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.94657E-01 0.00137  1.74410E-02 0.00196  8.65939E-04 0.03808  1.20058E+00 0.00126 ];
INF_SP1                   (idx, [1:   8]) = [  2.17876E-01 0.00240  5.06586E-03 0.01330  3.53015E-04 0.07065  3.00414E-01 0.00259 ];
INF_SP2                   (idx, [1:   8]) = [  9.03400E-02 0.00209 -1.48076E-03 0.02279  2.03711E-04 0.09140  7.14992E-02 0.00795 ];
INF_SP3                   (idx, [1:   8]) = [  8.43740E-03 0.01927 -1.76024E-03 0.03085  6.75713E-05 0.09407  2.11374E-02 0.02240 ];
INF_SP4                   (idx, [1:   8]) = [ -8.27123E-03 0.01463 -6.34276E-04 0.04543  5.16254E-07 1.00000 -7.07997E-03 0.08849 ];
INF_SP5                   (idx, [1:   8]) = [  2.11675E-04 0.81381 -1.67815E-06 1.00000 -5.46226E-05 0.21490  4.73052E-03 0.06943 ];
INF_SP6                   (idx, [1:   8]) = [  4.90143E-03 0.02981 -1.21557E-04 0.16431 -5.00545E-05 0.18430 -1.27219E-02 0.02593 ];
INF_SP7                   (idx, [1:   8]) = [  9.89013E-04 0.13143 -1.15837E-04 0.17262 -4.32225E-05 0.37662  1.07525E-04 1.00000 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.37660E-01 0.00370  7.24896E-01 0.02970 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.36184E-01 0.00692  7.37544E-01 0.02939 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.40020E-01 0.00613  7.16236E-01 0.03100 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.36899E-01 0.00697  7.22996E-01 0.03739 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.40264E+00 0.00370  4.61384E-01 0.02827 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.41160E+00 0.00688  4.53468E-01 0.02850 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.38898E+00 0.00616  4.67101E-01 0.02947 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.40734E+00 0.00691  4.63583E-01 0.03666 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  7.02799E-03 0.07878  2.99915E-04 0.38477  1.36589E-03 0.15754  1.29923E-03 0.18243  3.04355E-03 0.11357  7.97317E-04 0.18589  2.22088E-04 0.34294 ];
LAMBDA                    (idx, [1:  14]) = [  6.37576E-01 0.20116  1.24906E-02 5.5E-09  3.16814E-02 0.00217  1.09901E-01 0.00247  3.19844E-01 0.00238  1.34455E+00 0.00203  8.97204E+00 0.01673 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:31 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  9.37935E-01  1.03927E+00  1.00693E+00  1.01587E+00  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.75272E-02 0.00737  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.82473E-01 0.00013  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.78538E-01 0.00074  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.79581E-01 0.00073  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  3.00706E+00 0.00258  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.73467E+01 0.00324  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.73467E+01 0.00324  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  2.23299E+01 0.00423  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  1.01327E+00 0.00893  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50149 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.01490E+02 0.00860 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.01490E+02 0.00860 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.55297E+00 ;
RUNNING_TIME              (idx, 1)        =  7.28200E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  1.87167E-02  5.68333E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  2.72683E-01  4.89000E-02  5.51000E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  5.87667E-02  1.26500E-02 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  2.06667E-03  7.00001E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  7.27883E-01  1.11213E+00 ];
CPU_USAGE                 (idx, 1)        = 2.13262 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  4.00037E+00 0.00648 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  4.68278E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.94126E+16 ;
TOT_DECAY_HEAT            (idx, 1)        =  2.97632E+04 ;
TOT_SF_RATE               (idx, 1)        =  4.42576E+03 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  2.47735E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  2.12157E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  7.46388E+16 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  2.76414E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  2.58405E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  2.97068E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.10764E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  7.68907E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  1.47641E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.20178E+07 ;
SR90_ACTIVITY             (idx, 1)        =  3.61438E+11 ;
TE132_ACTIVITY            (idx, 1)        =  5.93396E+14 ;
I131_ACTIVITY             (idx, 1)        =  1.94896E+14 ;
I132_ACTIVITY             (idx, 1)        =  7.12751E+14 ;
CS134_ACTIVITY            (idx, 1)        =  8.57139E+10 ;
CS137_ACTIVITY            (idx, 1)        =  4.36845E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.51227E+16 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.40016E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  5.87767E+09 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.28612E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.62707E+14 0.00491  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 3 ;
BURNUP                     (idx, [1:  2])  = [  3.20000E+01  3.20465E+01 ];
BURN_DAYS                 (idx, 1)        =  5.33333E+00 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  8.18991E-01 0.00998 ];
U235_FISS                 (idx, [1:   4]) = [  9.22760E+15 0.01237  3.92430E-01 0.00995 ];
U238_FISS                 (idx, [1:   4]) = [  1.49858E+15 0.03279  6.36074E-02 0.03121 ];
PU239_FISS                (idx, [1:   4]) = [  8.46419E+15 0.01299  3.60315E-01 0.01144 ];
PU240_FISS                (idx, [1:   4]) = [  1.37325E+13 0.32052  5.90475E-04 0.32035 ];
PU241_FISS                (idx, [1:   4]) = [  4.16573E+15 0.01887  1.77065E-01 0.01685 ];
U235_CAPT                 (idx, [1:   4]) = [  1.84459E+15 0.02969  3.18491E-02 0.02911 ];
U238_CAPT                 (idx, [1:   4]) = [  1.98996E+16 0.00971  3.43323E-01 0.00733 ];
PU239_CAPT                (idx, [1:   4]) = [  4.43796E+15 0.01846  7.67991E-02 0.01886 ];
PU240_CAPT                (idx, [1:   4]) = [  4.34706E+15 0.01978  7.49779E-02 0.01872 ];
PU241_CAPT                (idx, [1:   4]) = [  1.63789E+15 0.03274  2.81766E-02 0.03119 ];
XE135_CAPT                (idx, [1:   4]) = [  1.78462E+15 0.02761  3.08870E-02 0.02794 ];
SM149_CAPT                (idx, [1:   4]) = [  1.21252E+14 0.10055  2.08463E-03 0.09924 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50149 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.71164E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50149 5.00571E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 35672 3.56071E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 14477 1.44500E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50149 5.00571E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.18279E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.40414E+16 0.00011  6.40414E+16 0.00011  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.36402E+16 1.8E-05  2.36402E+16 1.8E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  5.78165E+16 0.00318  4.45586E+16 0.00360  1.32579E+16 0.00449 ];
TOT_ABSRATE               (idx, [1:   6]) = [  8.14567E+16 0.00226  6.81988E+16 0.00235  1.32579E+16 0.00449 ];
TOT_SRCRATE               (idx, [1:   6]) = [  8.13536E+16 0.00491  8.13536E+16 0.00491  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  5.15840E+18 0.00398  8.52003E+17 0.00381  4.30640E+18 0.00416 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  8.14567E+16 0.00226 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  3.85144E+18 0.00354 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.26414E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.26414E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.19851E+00 0.00627 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.07755E-01 0.00233 ];
SIX_FF_P                  (idx, [1:   2]) = [  7.14808E-01 0.00271 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.13212E+00 0.00321 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  7.82272E-01 0.00567 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  7.82272E-01 0.00567 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.70901E+00 0.00013 ];
FISSE                     (idx, [1:   2]) = [  2.06179E+02 1.8E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  7.82521E-01 0.00579  7.78163E-01 0.00562  4.10974E-03 0.12441 ];
IMP_KEFF                  (idx, [1:   2]) = [  7.87559E-01 0.00230 ];
COL_KEFF                  (idx, [1:   2]) = [  7.89052E-01 0.00485 ];
ABS_KEFF                  (idx, [1:   2]) = [  7.87559E-01 0.00230 ];
ABS_KINF                  (idx, [1:   2]) = [  7.87559E-01 0.00230 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.79111E+01 0.00218 ];
IMP_ALF                   (idx, [1:   2]) = [  1.79020E+01 0.00072 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  3.59195E-07 0.04100 ];
IMP_EALF                  (idx, [1:   2]) = [  3.38766E-07 0.01308 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  2.02270E-01 0.03514 ];
IMP_AFGE                  (idx, [1:   2]) = [  2.11449E-01 0.01253 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  7.03120E-03 0.06242  1.56674E-04 0.46408  1.13927E-03 0.13695  1.13262E-03 0.15623  3.31095E-03 0.08488  9.59755E-04 0.17806  3.31929E-04 0.26150 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  7.00904E-01 0.18099  6.46555E-04 0.43850  1.19936E-02 0.12578  3.78312E-02 0.14012  2.36676E-01 0.05969  3.60285E-01 0.15960  1.02085E+00 0.27736 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  5.01970E-03 0.11363  1.54428E-05 0.73558  8.16314E-04 0.21615  7.12312E-04 0.23746  2.41329E-03 0.13941  8.01298E-04 0.22168  2.61044E-04 0.37521 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  8.30183E-01 0.22097  1.29303E-02 0.02111  3.07715E-02 0.00482  1.11164E-01 0.00524  3.19705E-01 0.00407  1.23530E+00 0.02986  7.67553E+00 0.10838 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  8.49558E-05 0.01451  8.48359E-05 0.01422  3.93314E-05 0.22152 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  6.62055E-05 0.01253  6.61151E-05 0.01225  3.06881E-05 0.21878 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  5.18889E-03 0.12629  0.00000E+00 0.0E+00  9.41803E-04 0.28223  5.15730E-04 0.37420  2.68051E-03 0.18312  7.58124E-04 0.29817  2.92730E-04 0.49537 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  7.25547E-01 0.27471  0.00000E+00 0.0E+00  3.06777E-02 0.00858  1.12921E-01 0.01368  3.19494E-01 0.00689  1.20712E+00 0.05418  7.22798E+00 0.19485 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  8.14488E-05 0.03041  8.12727E-05 0.03024  1.33800E-05 0.49797 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  6.34789E-05 0.02982  6.33364E-05 0.02961  1.06423E-05 0.49600 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  5.29471E-03 0.29519  0.00000E+00 0.0E+00  2.09954E-03 0.49856  0.00000E+00 0.0E+00  2.72150E-03 0.42344  4.22392E-04 1.00000  5.12732E-05 1.00000 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  9.25970E-01 0.70178  0.00000E+00 0.0E+00  3.10770E-02 0.01472  0.00000E+00 0.0E+00  3.15310E-01 0.00533  1.35398E+00 0.0E+00  8.63638E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  5.14934E-03 0.29520  0.00000E+00 0.0E+00  2.01688E-03 0.51709  0.00000E+00 0.0E+00  2.64884E-03 0.41193  4.28266E-04 1.00000  5.53506E-05 1.00000 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  9.25970E-01 0.70178  0.00000E+00 0.0E+00  3.10770E-02 0.01472  0.00000E+00 0.0E+00  3.15310E-01 0.00533  1.35398E+00 0.0E+00  8.63638E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -8.87558E+01 0.34052 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  8.43503E-05 0.00852 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  6.57457E-05 0.00496 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  5.10042E-03 0.07945 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -6.09390E+01 0.08006 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  8.74894E-07 0.00408 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.21364E-06 0.00466  3.21315E-06 0.00475  2.81722E-06 0.08244 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  7.40157E-05 0.00565  7.40108E-05 0.00563  6.36108E-05 0.10916 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  7.15123E-01 0.00273  7.16221E-01 0.00283  7.10614E-01 0.11504 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.00632E+01 0.23092 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.73467E+01 0.00324  5.25414E+01 0.00565 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  3.87092E+03 0.01521  1.50310E+04 0.00857  3.12109E+04 0.01213  3.75313E+04 0.00552  3.60036E+04 0.00455  3.75137E+04 0.00597  2.63410E+04 0.00400  2.23344E+04 0.01084  1.68812E+04 0.00844  1.42953E+04 0.00494  1.20142E+04 0.00538  1.10005E+04 0.01213  1.00053E+04 0.00647  9.65408E+03 0.00308  9.17925E+03 0.01471  8.06281E+03 0.00774  8.00669E+03 0.01061  8.16262E+03 0.01028  7.94582E+03 0.01993  1.53915E+04 0.00277  1.49277E+04 0.00369  1.08103E+04 0.01198  7.14915E+03 0.01888  8.32081E+03 0.00762  8.04635E+03 0.01806  7.28367E+03 0.01645  1.20616E+04 0.00978  2.75774E+03 0.00891  3.46654E+03 0.01609  3.10027E+03 0.02670  1.79920E+03 0.02982  3.09451E+03 0.01414  2.17105E+03 0.01613  1.74769E+03 0.02252  3.35281E+02 0.07490  2.91896E+02 0.04375  2.61662E+02 0.04388  2.57850E+02 0.04211  2.58956E+02 0.03141  2.79789E+02 0.05023  3.09285E+02 0.04262  3.18159E+02 0.02322  6.04818E+02 0.02771  1.00235E+03 0.02679  1.24664E+03 0.01352  3.35442E+03 0.01509  3.69813E+03 0.01285  4.19629E+03 0.01901  3.02312E+03 0.00959  2.30463E+03 0.01512  1.85583E+03 0.01569  2.16412E+03 0.01345  4.47625E+03 0.01209  6.36383E+03 0.01897  1.30031E+04 0.00433  2.12914E+04 0.00369  3.31199E+04 0.00980  2.15819E+04 0.00269  1.56504E+04 0.00383  1.12395E+04 0.00544  1.02598E+04 0.01033  1.01370E+04 0.00193  8.53843E+03 0.00854  5.75663E+03 0.01024  5.33892E+03 0.00953  4.72567E+03 0.01093  4.03429E+03 0.01412  3.14126E+03 0.00730  2.12323E+03 0.01072  7.65763E+02 0.01724 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  7.89052E-01 0.00365 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  3.54449E+18 0.00331  1.61716E+18 0.00451 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.19272E-01 0.00112  1.24602E+00 0.00225 ];
INF_CAPT                  (idx, [1:   4]) = [  5.82641E-03 0.00623  2.30270E-02 0.00316 ];
INF_ABS                   (idx, [1:   4]) = [  6.58237E-03 0.00578  3.60230E-02 0.00349 ];
INF_FISS                  (idx, [1:   4]) = [  7.55955E-04 0.00743  1.29960E-02 0.00412 ];
INF_NSF                   (idx, [1:   4]) = [  2.07484E-03 0.00782  3.51475E-02 0.00412 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.74463E+00 0.00040  2.70447E+00 8.3E-05 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.06125E+02 4.6E-05  2.06186E+02 1.5E-05 ];
INF_INVV                  (idx, [1:   4]) = [  6.14049E-08 0.00631  2.65927E-06 0.00105 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.12700E-01 0.00120  1.21006E+00 0.00219 ];
INF_SCATT1                (idx, [1:   4]) = [  2.23506E-01 0.00156  2.96131E-01 0.00387 ];
INF_SCATT2                (idx, [1:   4]) = [  8.89850E-02 0.00249  6.87944E-02 0.00900 ];
INF_SCATT3                (idx, [1:   4]) = [  6.69352E-03 0.01429  2.12229E-02 0.00704 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.09997E-03 0.01134 -6.31643E-03 0.08963 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.09198E-04 1.00000  5.04490E-03 0.06844 ];
INF_SCATT6                (idx, [1:   4]) = [  4.42217E-03 0.02612 -1.32245E-02 0.02086 ];
INF_SCATT7                (idx, [1:   4]) = [  6.17003E-04 0.30052  2.86892E-04 0.47427 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.12726E-01 0.00121  1.21006E+00 0.00219 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.23506E-01 0.00155  2.96131E-01 0.00387 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.89834E-02 0.00250  6.87944E-02 0.00900 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.69252E-03 0.01420  2.12229E-02 0.00704 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.10079E-03 0.01141 -6.31643E-03 0.08963 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.10032E-04 1.00000  5.04490E-03 0.06844 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.42257E-03 0.02604 -1.32245E-02 0.02086 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.16038E-04 0.30018  2.86892E-04 0.47427 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.26663E-01 0.00113  8.50386E-01 0.00250 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.47062E+00 0.00113  3.91989E-01 0.00251 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  6.55616E-03 0.00553  3.60230E-02 0.00349 ];
INF_REMXS                 (idx, [1:   4]) = [  2.32873E-02 0.00113  3.66380E-02 0.00416 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.95985E-01 0.00116  1.67153E-02 0.00271  6.77036E-04 0.05519  1.20938E+00 0.00220 ];
INF_S1                    (idx, [1:   8]) = [  2.18584E-01 0.00155  4.92107E-03 0.00692  2.70061E-04 0.04639  2.95861E-01 0.00388 ];
INF_S2                    (idx, [1:   8]) = [  9.04458E-02 0.00213 -1.46082E-03 0.02562  1.50744E-04 0.13990  6.86437E-02 0.00912 ];
INF_S3                    (idx, [1:   8]) = [  8.43784E-03 0.01074 -1.74432E-03 0.01843  5.44418E-05 0.25200  2.11685E-02 0.00740 ];
INF_S4                    (idx, [1:   8]) = [ -8.51924E-03 0.01499 -5.80734E-04 0.06034  1.88068E-07 1.00000 -6.31661E-03 0.08913 ];
INF_S5                    (idx, [1:   8]) = [ -1.34945E-04 0.96258  2.57474E-05 1.00000 -2.08244E-05 0.38973  5.06572E-03 0.06727 ];
INF_S6                    (idx, [1:   8]) = [  4.53206E-03 0.02411 -1.09898E-04 0.08840 -3.73336E-05 0.15460 -1.31872E-02 0.02121 ];
INF_S7                    (idx, [1:   8]) = [  7.70519E-04 0.23161 -1.53515E-04 0.09351 -4.43545E-05 0.21200  3.31246E-04 0.42178 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.96011E-01 0.00117  1.67153E-02 0.00271  6.77036E-04 0.05519  1.20938E+00 0.00220 ];
INF_SP1                   (idx, [1:   8]) = [  2.18585E-01 0.00154  4.92107E-03 0.00692  2.70061E-04 0.04639  2.95861E-01 0.00388 ];
INF_SP2                   (idx, [1:   8]) = [  9.04443E-02 0.00213 -1.46082E-03 0.02562  1.50744E-04 0.13990  6.86437E-02 0.00912 ];
INF_SP3                   (idx, [1:   8]) = [  8.43684E-03 0.01069 -1.74432E-03 0.01843  5.44418E-05 0.25200  2.11685E-02 0.00740 ];
INF_SP4                   (idx, [1:   8]) = [ -8.52006E-03 0.01508 -5.80734E-04 0.06034  1.88068E-07 1.00000 -6.31661E-03 0.08913 ];
INF_SP5                   (idx, [1:   8]) = [ -1.35780E-04 0.95964  2.57474E-05 1.00000 -2.08244E-05 0.38973  5.06572E-03 0.06727 ];
INF_SP6                   (idx, [1:   8]) = [  4.53247E-03 0.02403 -1.09898E-04 0.08840 -3.73336E-05 0.15460 -1.31872E-02 0.02121 ];
INF_SP7                   (idx, [1:   8]) = [  7.69553E-04 0.23126 -1.53515E-04 0.09351 -4.43545E-05 0.21200  3.31246E-04 0.42178 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.35915E-01 0.00164  7.39545E-01 0.03316 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.37515E-01 0.00699  7.70420E-01 0.03218 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.35387E-01 0.00892  7.38046E-01 0.03986 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.34998E-01 0.00530  7.13855E-01 0.03395 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.41295E+00 0.00164  4.52688E-01 0.03266 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.40370E+00 0.00703  4.34440E-01 0.03177 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.41655E+00 0.00875  4.54575E-01 0.04051 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.41862E+00 0.00536  4.69048E-01 0.03299 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  5.01970E-03 0.11363  1.54428E-05 0.73558  8.16314E-04 0.21615  7.12312E-04 0.23746  2.41329E-03 0.13941  8.01298E-04 0.22168  2.61044E-04 0.37521 ];
LAMBDA                    (idx, [1:  14]) = [  8.30183E-01 0.22097  1.29303E-02 0.02111  3.07715E-02 0.00482  1.11164E-01 0.00524  3.19705E-01 0.00407  1.23530E+00 0.02986  7.67553E+00 0.10838 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:35 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  0.00000E+00  0.00000E+00  0.00000E+00  0.00000E+00  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50430 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  0.00000E+00 0.00000 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  0.00000E+00 0.00000 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.72237E+00 ;
RUNNING_TIME              (idx, 1)        =  7.87383E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  2.23833E-02  1.66655E-05 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.08450E-01  4.89000E-02  3.57667E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  7.81667E-02  9.05000E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  2.73333E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  7.78317E-01  1.11142E+00 ];
CPU_USAGE                 (idx, 1)        = 2.18746 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  5.06763E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  1.58193E+17 ;
TOT_DECAY_HEAT            (idx, 1)        =  4.44389E+04 ;
TOT_SF_RATE               (idx, 1)        =  1.69847E+05 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  4.87192E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  4.63003E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  1.09473E+17 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.98083E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  4.76491E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  4.33309E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  2.59143E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  1.33604E+07 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  2.17348E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.99705E+07 ;
SR90_ACTIVITY             (idx, 1)        =  5.37165E+11 ;
TE132_ACTIVITY            (idx, 1)        =  8.50452E+14 ;
I131_ACTIVITY             (idx, 1)        =  2.73655E+14 ;
I132_ACTIVITY             (idx, 1)        =  1.17806E+15 ;
CS134_ACTIVITY            (idx, 1)        =  6.11222E+11 ;
CS137_ACTIVITY            (idx, 1)        =  8.58350E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  1.31393E+17 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  1.80024E+14 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.28720E+11 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  2.06615E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 4 ;
BURNUP                     (idx, [1:  2])  = [  6.20000E+01  6.20887E+01 ];
BURN_DAYS                 (idx, 1)        =  1.03333E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 0 0.00000E+00 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 0 0.00000E+00 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 0.00000E+00 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_ABSRATE               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_SRCRATE               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.22920E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.22920E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_F                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_P                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_LF                 (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
FISSE                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
IMP_KEFF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
COL_KEFF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ABS_KEFF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ABS_KINF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
IMP_ALF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
IMP_EALF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
IMP_AFGE                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CAPT                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_ABS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_FISS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_NSF                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_NUBAR                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_KAPPA                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_INVV                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATT7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP1               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP2               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP3               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP4               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP5               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP6               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SCATTP7               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_REMXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_S7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP1                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP2                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP3                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP4                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP5                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP6                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SP7                   (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
LAMBDA                    (idx, [1:  14]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:37 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00784E+00  1.00176E+00  9.97473E-01  9.92922E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 1.9E-09  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.64456E-02 0.00977  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.83554E-01 0.00016  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  7.03426E-01 0.00075  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  7.04429E-01 0.00075  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.87142E+00 0.00275  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  3.25005E+01 0.00226  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  3.25005E+01 0.00226  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.36398E+01 0.00346  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  6.12993E-01 0.01058  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50182 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.01820E+02 0.00931 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.01820E+02 0.00931 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  1.85951E+00 ;
RUNNING_TIME              (idx, 1)        =  8.24167E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  2.56333E-02  3.25000E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  3.41667E-01  3.32167E-02  3.57667E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  7.84500E-02  2.83337E-04 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  2.73333E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  8.23767E-01  9.54800E-01 ];
CPU_USAGE                 (idx, 1)        = 2.25623 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.96692E+00 0.00822 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  5.26734E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  3.29375E+15 ;
TOT_DECAY_HEAT            (idx, 1)        =  3.90719E+02 ;
TOT_SF_RATE               (idx, 1)        =  1.73024E+05 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  8.56587E+14 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  5.62819E+01 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  2.43717E+15 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  3.34437E+02 ;
INHALATION_TOXICITY       (idx, 1)        =  1.99090E+07 ;
INGESTION_TOXICITY        (idx, 1)        =  6.63525E+06 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.08970E+07 ;
ACTINIDE_ING_TOX          (idx, 1)        =  7.03920E+05 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  9.01204E+06 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  5.93133E+06 ;
SR90_ACTIVITY             (idx, 1)        =  5.36906E+11 ;
TE132_ACTIVITY            (idx, 1)        =  9.78013E+13 ;
I131_ACTIVITY             (idx, 1)        =  1.23687E+14 ;
I132_ACTIVITY             (idx, 1)        =  1.00810E+14 ;
CS134_ACTIVITY            (idx, 1)        =  6.09086E+11 ;
CS137_ACTIVITY            (idx, 1)        =  8.58146E+11 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  3.69178E+15 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  0.00000E+00 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  1.36176E+11 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  6.88999E+15 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  1.45641E+14 0.00403  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 5 ;
BURNUP                     (idx, [1:  2])  = [  6.20000E+01  6.20887E+01 ];
BURN_DAYS                 (idx, 1)        =  2.03333E+01 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  5.21291E-01 0.01056 ];
U235_FISS                 (idx, [1:   4]) = [  9.33286E+13 0.12643  3.98219E-03 0.12581 ];
U238_FISS                 (idx, [1:   4]) = [  1.24675E+15 0.03734  5.35586E-02 0.03698 ];
PU239_FISS                (idx, [1:   4]) = [  1.97653E+16 0.00706  8.49037E-01 0.00301 ];
PU240_FISS                (idx, [1:   4]) = [  2.11839E+13 0.25635  9.12230E-04 0.25886 ];
PU241_FISS                (idx, [1:   4]) = [  2.07519E+15 0.02662  8.91035E-02 0.02553 ];
U235_CAPT                 (idx, [1:   4]) = [  2.56613E+13 0.21623  5.33271E-04 0.21606 ];
U238_CAPT                 (idx, [1:   4]) = [  1.22322E+16 0.01145  2.46396E-01 0.00979 ];
PU239_CAPT                (idx, [1:   4]) = [  1.08622E+16 0.01064  2.18914E-01 0.00933 ];
PU240_CAPT                (idx, [1:   4]) = [  5.20054E+15 0.01922  1.04657E-01 0.01757 ];
PU241_CAPT                (idx, [1:   4]) = [  7.60161E+14 0.04956  1.52925E-02 0.04865 ];
SM149_CAPT                (idx, [1:   4]) = [  4.71903E+15 0.01725  9.52247E-02 0.01711 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50182 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 5.96245E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50182 5.00596E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 34150 3.40658E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 16032 1.59939E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50182 5.00596E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 -5.82077E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.72860E+16 5.4E-05  6.72860E+16 5.4E-05  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.34209E+16 4.0E-06  2.34209E+16 4.0E-06  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  4.95163E+16 0.00294  4.39329E+16 0.00312  5.58341E+15 0.00574 ];
TOT_ABSRATE               (idx, [1:   6]) = [  7.29372E+16 0.00200  6.73538E+16 0.00203  5.58341E+15 0.00574 ];
TOT_SRCRATE               (idx, [1:   6]) = [  7.28207E+16 0.00403  7.28207E+16 0.00403  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  3.72274E+18 0.00359  6.11975E+17 0.00404  3.11076E+18 0.00374 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  7.29372E+16 0.00200 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  2.36810E+18 0.00326 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  1.22927E-01 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  1.22927E-01 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.28235E+00 0.00599 ];
SIX_FF_F                  (idx, [1:   2]) = [  9.24719E-01 0.00142 ];
SIX_FF_P                  (idx, [1:   2]) = [  6.67903E-01 0.00299 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.16140E+00 0.00330 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  9.18907E-01 0.00610 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  9.18907E-01 0.00610 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.87291E+00 5.3E-05 ];
FISSE                     (idx, [1:   2]) = [  2.08110E+02 4.1E-06 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  9.19362E-01 0.00626  9.16142E-01 0.00604  2.76514E-03 0.15568 ];
IMP_KEFF                  (idx, [1:   2]) = [  9.24139E-01 0.00199 ];
COL_KEFF                  (idx, [1:   2]) = [  9.25480E-01 0.00403 ];
ABS_KEFF                  (idx, [1:   2]) = [  9.24139E-01 0.00199 ];
ABS_KINF                  (idx, [1:   2]) = [  9.24139E-01 0.00199 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.75000E+01 0.00218 ];
IMP_ALF                   (idx, [1:   2]) = [  1.74412E+01 0.00063 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  5.42063E-07 0.04286 ];
IMP_EALF                  (idx, [1:   2]) = [  5.35846E-07 0.01111 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  1.87238E-01 0.04142 ];
IMP_AFGE                  (idx, [1:   2]) = [  1.99649E-01 0.01128 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  3.49094E-03 0.07468  6.32021E-05 0.57354  7.73649E-04 0.16972  6.66330E-04 0.20230  1.21147E-03 0.13287  7.30008E-04 0.18577  4.62757E-05 0.70354 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  3.91799E-01 0.18774  3.74433E-04 0.57149  8.98931E-03 0.15352  2.65487E-02 0.17900  1.35330E-01 0.11822  3.24186E-01 0.17172  2.06702E-01 0.70395 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  3.03046E-03 0.10600  7.08324E-05 0.97615  6.85500E-04 0.22409  5.13830E-04 0.27875  1.15799E-03 0.17727  5.97516E-04 0.24067  4.79772E-06 1.00000 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  5.03558E-01 0.25092  1.24811E-02 9.1E-09  2.99693E-02 0.00048  1.10256E-01 0.00751  3.22240E-01 0.00566  1.25879E+00 0.02747  9.97903E+00 0.0E+00 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  2.84524E-05 0.01403  2.84594E-05 0.01408  5.59793E-06 0.26139 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  2.60311E-05 0.01174  2.60379E-05 0.01180  5.22920E-06 0.26364 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  2.89492E-03 0.15554  6.96864E-05 1.00000  7.83943E-04 0.29308  4.30654E-04 0.42076  9.74992E-04 0.23435  6.35646E-04 0.30316  0.00000E+00 0.0E+00 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  3.93745E-01 0.17371  1.24811E-02 0.0E+00  2.99483E-02 5.4E-05  1.09665E-01 0.01477  3.20754E-01 0.00849  1.24242E+00 0.05011  0.00000E+00 0.0E+00 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  2.68624E-05 0.02762  2.68813E-05 0.02761  8.00275E-07 0.53764 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  2.46054E-05 0.02718  2.46244E-05 0.02720  7.96162E-07 0.54557 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  1.82447E-03 0.53988  0.00000E+00 0.0E+00  1.27489E-03 0.72615  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  5.49577E-04 0.64933  0.00000E+00 0.0E+00 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  6.85538E-01 0.42774  0.00000E+00 0.0E+00  2.99467E-02 1.3E-08  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  1.34113E+00 0.00839  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  2.15635E-03 0.51949  0.00000E+00 0.0E+00  1.50741E-03 0.69436  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  6.48945E-04 0.65216  0.00000E+00 0.0E+00 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  6.85538E-01 0.42774  0.00000E+00 0.0E+00  2.99467E-02 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  1.34113E+00 0.00839  0.00000E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -7.67268E+01 0.53125 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  2.82145E-05 0.00849 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  2.58343E-05 0.00541 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  2.99576E-03 0.09234 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -1.04149E+02 0.08802 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  4.24578E-07 0.00520 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  3.04084E-06 0.00440  3.04108E-06 0.00445  1.83804E-06 0.10482 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  2.88017E-05 0.00626  2.88111E-05 0.00626  1.69188E-05 0.12849 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  6.68425E-01 0.00300  6.68577E-01 0.00306  6.58653E-01 0.11038 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  9.59515E+00 0.15670 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  3.25005E+01 0.00226  3.47255E+01 0.00405 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  4.22970E+03 0.03261  1.56482E+04 0.01711  3.21201E+04 0.01096  3.82273E+04 0.00845  3.59928E+04 0.00793  3.80183E+04 0.00700  2.55449E+04 0.00445  2.22586E+04 0.00717  1.71743E+04 0.00952  1.37872E+04 0.00470  1.20320E+04 0.00649  1.09714E+04 0.00952  1.01756E+04 0.00888  9.61727E+03 0.01333  9.40698E+03 0.01031  8.14469E+03 0.00953  7.91771E+03 0.00652  7.77562E+03 0.01172  7.70463E+03 0.00689  1.52879E+04 0.00756  1.49539E+04 0.00397  1.08236E+04 0.01007  6.92160E+03 0.00807  8.14160E+03 0.00832  7.94012E+03 0.00693  7.00625E+03 0.00590  1.16440E+04 0.01305  2.79036E+03 0.01766  3.18791E+03 0.02250  3.01285E+03 0.01742  1.73885E+03 0.02892  2.99948E+03 0.01883  2.00230E+03 0.01769  1.62479E+03 0.02478  2.70662E+02 0.04276  2.43349E+02 0.01983  2.23656E+02 0.04611  2.11898E+02 0.03636  2.18951E+02 0.03946  2.19036E+02 0.04354  2.48145E+02 0.03243  2.61959E+02 0.04063  5.30580E+02 0.04030  8.46133E+02 0.02436  1.17487E+03 0.01994  3.10184E+03 0.02286  3.21814E+03 0.01554  3.41757E+03 0.01462  1.99787E+03 0.01810  1.30451E+03 0.01459  9.03396E+02 0.02042  1.05540E+03 0.01317  1.94430E+03 0.02326  2.71382E+03 0.01443  5.21387E+03 0.00823  8.15990E+03 0.01173  1.18815E+04 0.00439  7.56170E+03 0.00797  5.39671E+03 0.00363  3.88313E+03 0.00671  3.46564E+03 0.01205  3.39809E+03 0.01348  2.84657E+03 0.00986  1.92258E+03 0.00917  1.79396E+03 0.01276  1.59870E+03 0.00993  1.35709E+03 0.01028  1.05396E+03 0.02671  6.88320E+02 0.02131  2.64233E+02 0.03171 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  9.25480E-01 0.00383 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  3.16310E+18 0.00380  5.61012E+17 0.00367 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.17498E-01 0.00059  1.30556E+00 0.00053 ];
INF_CAPT                  (idx, [1:   4]) = [  6.62475E-03 0.00428  5.09794E-02 0.00272 ];
INF_ABS                   (idx, [1:   4]) = [  7.68195E-03 0.00411  8.68330E-02 0.00321 ];
INF_FISS                  (idx, [1:   4]) = [  1.05721E-03 0.00326  3.58536E-02 0.00397 ];
INF_NSF                   (idx, [1:   4]) = [  3.02757E-03 0.00306  1.03058E-01 0.00397 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.86375E+00 0.00033  2.87441E+00 7.6E-06 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.07790E+02 1.5E-05  2.08163E+02 1.6E-06 ];
INF_INVV                  (idx, [1:   4]) = [  5.83512E-08 0.00550  2.48997E-06 0.00216 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.09825E-01 0.00058  1.21887E+00 0.00055 ];
INF_SCATT1                (idx, [1:   4]) = [  2.21076E-01 0.00146  3.15048E-01 0.00197 ];
INF_SCATT2                (idx, [1:   4]) = [  8.81359E-02 0.00408  7.54113E-02 0.00342 ];
INF_SCATT3                (idx, [1:   4]) = [  6.72336E-03 0.02511  2.23110E-02 0.01056 ];
INF_SCATT4                (idx, [1:   4]) = [ -8.75715E-03 0.03281 -5.34552E-03 0.03471 ];
INF_SCATT5                (idx, [1:   4]) = [  3.96788E-04 0.53884  4.96668E-03 0.10514 ];
INF_SCATT6                (idx, [1:   4]) = [  4.61902E-03 0.03584 -1.32850E-02 0.03429 ];
INF_SCATT7                (idx, [1:   4]) = [  6.40325E-04 0.23667 -8.14320E-04 0.47229 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.09852E-01 0.00058  1.21887E+00 0.00055 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.21076E-01 0.00147  3.15048E-01 0.00197 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.81371E-02 0.00409  7.54113E-02 0.00342 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.72421E-03 0.02520  2.23110E-02 0.01056 ];
INF_SCATTP4               (idx, [1:   4]) = [ -8.75597E-03 0.03289 -5.34552E-03 0.03471 ];
INF_SCATTP5               (idx, [1:   4]) = [  3.95375E-04 0.54086  4.96668E-03 0.10514 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.61927E-03 0.03567 -1.32850E-02 0.03429 ];
INF_SCATTP7               (idx, [1:   4]) = [  6.40182E-04 0.23676 -8.14320E-04 0.47229 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.24967E-01 0.00238  8.83479E-01 0.00225 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.48173E+00 0.00238  3.77304E-01 0.00226 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  7.65453E-03 0.00408  8.68330E-02 0.00321 ];
INF_REMXS                 (idx, [1:   4]) = [  2.33444E-02 0.00269  8.83567E-02 0.00303 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  4.94154E-01 0.00051  1.56712E-02 0.00341  1.66136E-03 0.03706  1.21720E+00 0.00054 ];
INF_S1                    (idx, [1:   8]) = [  2.16591E-01 0.00145  4.48483E-03 0.00513  6.53012E-04 0.05408  3.14395E-01 0.00204 ];
INF_S2                    (idx, [1:   8]) = [  8.96178E-02 0.00425 -1.48185E-03 0.02655  3.97225E-04 0.07847  7.50141E-02 0.00359 ];
INF_S3                    (idx, [1:   8]) = [  8.35915E-03 0.02265 -1.63579E-03 0.01315  1.40539E-04 0.19535  2.21704E-02 0.01052 ];
INF_S4                    (idx, [1:   8]) = [ -8.29922E-03 0.03386 -4.57930E-04 0.02783 -3.31637E-05 0.61450 -5.31236E-03 0.03199 ];
INF_S5                    (idx, [1:   8]) = [  3.40963E-04 0.62654  5.58251E-05 0.14469 -6.55817E-05 0.32319  5.03226E-03 0.10145 ];
INF_S6                    (idx, [1:   8]) = [  4.76565E-03 0.03035 -1.46628E-04 0.17536 -7.36331E-05 0.29252 -1.32114E-02 0.03528 ];
INF_S7                    (idx, [1:   8]) = [  8.15318E-04 0.17776 -1.74993E-04 0.12549 -6.68965E-05 0.15942 -7.47423E-04 0.50706 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  4.94181E-01 0.00051  1.56712E-02 0.00341  1.66136E-03 0.03706  1.21720E+00 0.00054 ];
INF_SP1                   (idx, [1:   8]) = [  2.16591E-01 0.00145  4.48483E-03 0.00513  6.53012E-04 0.05408  3.14395E-01 0.00204 ];
INF_SP2                   (idx, [1:   8]) = [  8.96190E-02 0.00427 -1.48185E-03 0.02655  3.97225E-04 0.07847  7.50141E-02 0.00359 ];
INF_SP3                   (idx, [1:   8]) = [  8.36000E-03 0.02273 -1.63579E-03 0.01315  1.40539E-04 0.19535  2.21704E-02 0.01052 ];
INF_SP4                   (idx, [1:   8]) = [ -8.29804E-03 0.03393 -4.57930E-04 0.02783 -3.31637E-05 0.61450 -5.31236E-03 0.03199 ];
INF_SP5                   (idx, [1:   8]) = [  3.39550E-04 0.62932  5.58251E-05 0.14469 -6.55817E-05 0.32319  5.03226E-03 0.10145 ];
INF_SP6                   (idx, [1:   8]) = [  4.76590E-03 0.03019 -1.46628E-04 0.17536 -7.36331E-05 0.29252 -1.32114E-02 0.03528 ];
INF_SP7                   (idx, [1:   8]) = [  8.15175E-04 0.17771 -1.74993E-04 0.12549 -6.68965E-05 0.15942 -7.47423E-04 0.50706 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.33620E-01 0.00627  7.39375E-01 0.04347 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.35118E-01 0.00670  7.21582E-01 0.05923 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.33758E-01 0.00653  8.36453E-01 0.01896 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.32034E-01 0.00779  6.90320E-01 0.08072 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.42704E+00 0.00633  4.54335E-01 0.04453 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.41798E+00 0.00667  4.68231E-01 0.05703 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.42622E+00 0.00661  3.99073E-01 0.01867 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.43692E+00 0.00781  4.95702E-01 0.08061 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  3.03046E-03 0.10600  7.08324E-05 0.97615  6.85500E-04 0.22409  5.13830E-04 0.27875  1.15799E-03 0.17727  5.97516E-04 0.24067  4.79772E-06 1.00000 ];
LAMBDA                    (idx, [1:  14]) = [  5.03558E-01 0.25092  1.24811E-02 9.1E-09  2.99693E-02 0.00048  1.10256E-01 0.00751  3.22240E-01 0.00566  1.25879E+00 0.02747  9.97903E+00 0.0E+00 ];


% Increase counter:

if (exist('idx', 'var'));
  idx = idx + 1;
else;
  idx = 1;
end;

% Version, title and date:

VERSION                   (idx, [1: 14])  = 'Serpent 2.1.30' ;
COMPILE_DATE              (idx, [1: 20])  = 'Dec  5 2018 10:05:57' ;
DEBUG                     (idx, 1)        = 0 ;
TITLE                     (idx, [1:  8])  = 'Untitled' ;
CONFIDENTIAL_DATA         (idx, 1)        = 0 ;
INPUT_FILE_NAME           (idx, [1:  3])  = 'dep' ;
WORKING_DIRECTORY         (idx, [1: 55])  = '/home/ajohnson400/github/ans-student19-serpenttools/dep' ;
HOSTNAME                  (idx, [1: 14])  = 'ME04L0358GRD04' ;
CPU_TYPE                  (idx, [1: 40])  = 'Intel(R) Core(TM) i7-6700T CPU @ 2.80GHz' ;
CPU_MHZ                   (idx, 1)        = 198.0 ;
START_DATE                (idx, [1: 24])  = 'Fri Feb 15 11:15:47 2019' ;
COMPLETE_DATE             (idx, [1: 24])  = 'Fri Feb 15 11:16:43 2019' ;

% Run parameters:

POP                       (idx, 1)        = 500 ;
CYCLES                    (idx, 1)        = 100 ;
SKIP                      (idx, 1)        = 50 ;
BATCH_INTERVAL            (idx, 1)        = 1 ;
SRC_NORM_MODE             (idx, 1)        = 2 ;
SEED                      (idx, 1)        = 1550247347 ;
UFS_MODE                  (idx, 1)        = 0 ;
UFS_ORDER                 (idx, 1)        = 1.00000;
NEUTRON_TRANSPORT_MODE    (idx, 1)        = 1 ;
PHOTON_TRANSPORT_MODE     (idx, 1)        = 0 ;
GROUP_CONSTANT_GENERATION (idx, 1)        = 1 ;
B1_CALCULATION            (idx, [1:  3])  = [ 0 0 0 ];
B1_BURNUP_CORRECTION      (idx, 1)        = 0 ;
IMPLICIT_REACTION_RATES   (idx, 1)        = 1 ;

% Optimization:

OPTIMIZATION_MODE         (idx, 1)        = 4 ;
RECONSTRUCT_MICROXS       (idx, 1)        = 1 ;
RECONSTRUCT_MACROXS       (idx, 1)        = 1 ;
DOUBLE_INDEXING           (idx, 1)        = 0 ;
MG_MAJORANT_MODE          (idx, 1)        = 0 ;
SPECTRUM_COLLAPSE         (idx, 1)        = 1 ;

% Parallelization:

MPI_TASKS                 (idx, 1)        = 1 ;
OMP_THREADS               (idx, 1)        = 4 ;
MPI_REPRODUCIBILITY       (idx, 1)        = 0 ;
OMP_REPRODUCIBILITY       (idx, 1)        = 1 ;
OMP_HISTORY_PROFILE       (idx, [1:   4]) = [  1.00230E+00  1.01072E+00  1.00087E+00  9.86099E-01  ];
SHARE_BUF_ARRAY           (idx, 1)        = 0 ;
SHARE_RES2_ARRAY          (idx, 1)        = 1 ;

% File paths:

XS_DATA_FILE_PATH         (idx, [1: 64])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7u.xsdata' ;
DECAY_DATA_FILE_PATH      (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.dec' ;
SFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
NFY_DATA_FILE_PATH        (idx, [1: 60])  = '/home/ajohnson400/codes/serpent/xsdata/endfb7/sss_endfb7.nfy' ;
BRA_DATA_FILE_PATH        (idx, [1:  3])  = 'N/A' ;

% Collision and reaction sampling (neutrons/photons):

MIN_MACROXS               (idx, [1:   4]) = [  5.00000E-02 0.0E+00  0.00000E+00 0.0E+00 ];
DT_THRESH                 (idx, [1:  2])  = [  9.00000E-01  9.00000E-01 ];
ST_FRAC                   (idx, [1:   4]) = [  1.64820E-02 0.00714  0.00000E+00 0.0E+00 ];
DT_FRAC                   (idx, [1:   4]) = [  9.83518E-01 0.00012  0.00000E+00 0.0E+00 ];
DT_EFF                    (idx, [1:   4]) = [  6.84766E-01 0.00094  0.00000E+00 0.0E+00 ];
REA_SAMPLING_EFF          (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
REA_SAMPLING_FAIL         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_COL_EFF               (idx, [1:   4]) = [  6.85726E-01 0.00094  0.00000E+00 0.0E+00 ];
AVG_TRACKING_LOOPS        (idx, [1:   8]) = [  2.95301E+00 0.00271  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
AVG_TRACKS                (idx, [1:   4]) = [  4.06222E+01 0.00313  0.00000E+00 0.0E+00 ];
AVG_REAL_COL              (idx, [1:   4]) = [  4.06222E+01 0.00313  0.00000E+00 0.0E+00 ];
AVG_VIRT_COL              (idx, [1:   4]) = [  1.86223E+01 0.00429  0.00000E+00 0.0E+00 ];
AVG_SURF_CROSS            (idx, [1:   4]) = [  8.09830E-01 0.00864  0.00000E+00 0.0E+00 ];
LOST_PARTICLES            (idx, 1)        = 0 ;

% Run statistics:

CYCLE_IDX                 (idx, 1)        = 100 ;
SOURCE_POPULATION         (idx, 1)        = 50360 ;
MEAN_POP_SIZE             (idx, [1:  2])  = [  5.03600E+02 0.01227 ];
MEAN_POP_WGT              (idx, [1:  2])  = [  5.03600E+02 0.01227 ];
SIMULATION_COMPLETED      (idx, 1)        = 1 ;

% Running times:

TOT_CPU_TIME              (idx, 1)        =  2.19176E+00 ;
RUNNING_TIME              (idx, 1)        =  9.26133E-01 ;
INIT_TIME                 (idx, [1:  2])  = [  3.76933E-01  3.76933E-01 ];
PROCESS_TIME              (idx, [1:  2])  = [  3.34000E-02  3.81667E-03 ];
TRANSPORT_CYCLE_TIME      (idx, [1:  3])  = [  4.17433E-01  4.23333E-02  3.34333E-02 ];
BURNUP_CYCLE_TIME         (idx, [1:  2])  = [  9.65000E-02  9.00000E-03 ];
BATEMAN_SOLUTION_TIME     (idx, [1:  2])  = [  3.40000E-03  6.66666E-04 ];
MPI_OVERHEAD_TIME         (idx, [1:  2])  = [  0.00000E+00  0.00000E+00 ];
ESTIMATED_RUNNING_TIME    (idx, [1:  2])  = [  9.25750E-01  9.72000E-01 ];
CPU_USAGE                 (idx, 1)        = 2.36657 ;
TRANSPORT_CPU_USAGE       (idx, [1:   2]) = [  3.99257E+00 0.00658 ];
OMP_PARALLEL_FRAC         (idx, 1)        =  5.75457E-01 ;

% Memory usage:

AVAIL_MEM                 (idx, 1)        = 15927.25 ;
ALLOC_MEMSIZE             (idx, 1)        = 5976.31;
MEMSIZE                   (idx, 1)        = 5902.47;
XS_MEMSIZE                (idx, 1)        = 5835.04;
MAT_MEMSIZE               (idx, 1)        = 36.48;
RES_MEMSIZE               (idx, 1)        = 4.67;
MISC_MEMSIZE              (idx, 1)        = 26.29;
UNKNOWN_MEMSIZE           (idx, 1)        = 0.00;
UNUSED_MEMSIZE            (idx, 1)        = 73.83;

% Geometry parameters:

TOT_CELLS                 (idx, 1)        = 3 ;
UNION_CELLS               (idx, 1)        = 0 ;

% Neutron energy grid:

NEUTRON_ERG_TOL           (idx, 1)        =  5.00000E-05 ;
NEUTRON_ERG_NE            (idx, 1)        = 271766 ;
NEUTRON_EMIN              (idx, 1)        =  1.00000E-11 ;
NEUTRON_EMAX              (idx, 1)        =  2.00000E+01 ;

% Unresolved resonance probability table sampling:

URES_DILU_CUT             (idx, 1)        =  1.00000E-09 ;
URES_EMIN                 (idx, 1)        =  1.00000E+37 ;
URES_EMAX                 (idx, 1)        = -1.00000E+37 ;
URES_AVAIL                (idx, 1)        = 222 ;
URES_USED                 (idx, 1)        = 0 ;

% Nuclides and reaction channels:

TOT_NUCLIDES              (idx, 1)        = 1339 ;
TOT_TRANSPORT_NUCLIDES    (idx, 1)        = 286 ;
TOT_DOSIMETRY_NUCLIDES    (idx, 1)        = 0 ;
TOT_DECAY_NUCLIDES        (idx, 1)        = 1053 ;
TOT_PHOTON_NUCLIDES       (idx, 1)        = 0 ;
TOT_REA_CHANNELS          (idx, 1)        = 8192 ;
TOT_TRANSMU_REA           (idx, 1)        = 2675 ;

% Neutron physics options:

USE_DELNU                 (idx, 1)        = 1 ;
USE_URES                  (idx, 1)        = 0 ;
USE_DBRC                  (idx, 1)        = 0 ;
IMPL_CAPT                 (idx, 1)        = 0 ;
IMPL_NXN                  (idx, 1)        = 1 ;
IMPL_FISS                 (idx, 1)        = 0 ;
DOPPLER_PREPROCESSOR      (idx, 1)        = 0 ;
TMS_MODE                  (idx, 1)        = 0 ;
SAMPLE_FISS               (idx, 1)        = 1 ;
SAMPLE_CAPT               (idx, 1)        = 1 ;
SAMPLE_SCATT              (idx, 1)        = 1 ;

% Radioactivity data:

TOT_ACTIVITY              (idx, 1)        =  9.86259E+16 ;
TOT_DECAY_HEAT            (idx, 1)        =  2.63075E+04 ;
TOT_SF_RATE               (idx, 1)        =  3.89062E+06 ;
ACTINIDE_ACTIVITY         (idx, 1)        =  2.44537E+16 ;
ACTINIDE_DECAY_HEAT       (idx, 1)        =  2.07895E+03 ;
FISSION_PRODUCT_ACTIVITY  (idx, 1)        =  7.41716E+16 ;
FISSION_PRODUCT_DECAY_HEAT(idx, 1)        =  2.42279E+04 ;
INHALATION_TOXICITY       (idx, 1)        =  1.69929E+08 ;
INGESTION_TOXICITY        (idx, 1)        =  3.71116E+07 ;
ACTINIDE_INH_TOX          (idx, 1)        =  1.30457E+08 ;
ACTINIDE_ING_TOX          (idx, 1)        =  7.60529E+06 ;
FISSION_PRODUCT_INH_TOX   (idx, 1)        =  3.94721E+07 ;
FISSION_PRODUCT_ING_TOX   (idx, 1)        =  2.95063E+07 ;
SR90_ACTIVITY             (idx, 1)        =  2.01256E+12 ;
TE132_ACTIVITY            (idx, 1)        =  5.96696E+14 ;
I131_ACTIVITY             (idx, 1)        =  2.97199E+14 ;
I132_ACTIVITY             (idx, 1)        =  7.61799E+14 ;
CS134_ACTIVITY            (idx, 1)        =  7.69294E+12 ;
CS137_ACTIVITY            (idx, 1)        =  5.67207E+12 ;
PHOTON_DECAY_SOURCE       (idx, 1)        =  8.07189E+16 ;
NEUTRON_DECAY_SOURCE      (idx, 1)        =  9.79352E+13 ;
ALPHA_DECAY_SOURCE        (idx, 1)        =  2.12075E+12 ;
ELECTRON_DECAY_SOURCE     (idx, 1)        =  1.30731E+17 ;

% Normalization coefficient:

NORM_COEF                 (idx, [1:   4]) = [  2.27563E+14 0.00573  0.00000E+00 0.0E+00 ];

% Parameters for burnup calculation:

BURN_MATERIALS            (idx, 1)        = 1 ;
BURN_MODE                 (idx, 1)        = 2 ;
BURN_STEP                 (idx, 1)        = 6 ;
BURNUP                     (idx, [1:  2])  = [  5.40000E+02  5.40743E+02 ];
BURN_DAYS                 (idx, 1)        =  1.00000E+02 ;

% Analog reaction rate estimators:

CONVERSION_RATIO          (idx, [1:   2]) = [  9.42739E-01 0.01421 ];
U238_FISS                 (idx, [1:   4]) = [  1.30513E+15 0.04355  5.57843E-02 0.04253 ];
PU239_FISS                (idx, [1:   4]) = [  1.09110E+16 0.01375  4.68688E-01 0.01064 ];
PU240_FISS                (idx, [1:   4]) = [  3.69417E+13 0.23256  1.56047E-03 0.23233 ];
PU241_FISS                (idx, [1:   4]) = [  8.01888E+15 0.01561  3.44779E-01 0.01369 ];
U238_CAPT                 (idx, [1:   4]) = [  1.71199E+16 0.01257  1.88846E-01 0.01009 ];
PU239_CAPT                (idx, [1:   4]) = [  5.76849E+15 0.01677  6.38751E-02 0.01738 ];
PU240_CAPT                (idx, [1:   4]) = [  8.63882E+15 0.01901  9.53956E-02 0.01820 ];
PU241_CAPT                (idx, [1:   4]) = [  2.84216E+15 0.02791  3.14446E-02 0.02774 ];
XE135_CAPT                (idx, [1:   4]) = [  1.88298E+15 0.03128  2.07547E-02 0.02990 ];
SM149_CAPT                (idx, [1:   4]) = [  2.60013E+14 0.09300  2.84955E-03 0.09265 ];

% Neutron balance (particles/weight):

BALA_SRC_NEUTRON_SRC     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_FISS    (idx, [1:  2])  = [ 50360 5.00000E+04 ];
BALA_SRC_NEUTRON_NXN     (idx, [1:  2])  = [ 0 4.42699E+01 ];
BALA_SRC_NEUTRON_VR      (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_SRC_NEUTRON_TOT     (idx, [1:  2])  = [ 50360 5.00443E+04 ];

BALA_LOSS_NEUTRON_CAPT    (idx, [1:  2])  = [ 40056 3.98024E+04 ];
BALA_LOSS_NEUTRON_FISS    (idx, [1:  2])  = [ 10304 1.02418E+04 ];
BALA_LOSS_NEUTRON_LEAK    (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_CUT     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_ERR     (idx, [1:  2])  = [ 0 0.00000E+00 ];
BALA_LOSS_NEUTRON_TOT     (idx, [1:  2])  = [ 50360 5.00443E+04 ];

BALA_NEUTRON_DIFF         (idx, [1:  2])  = [ 0 2.18279E-11 ];

% Normalized total reaction rates (neutrons):

TOT_POWER                 (idx, [1:   6]) = [  7.80918E+05 0.0E+00  7.80918E+05 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_POWDENS               (idx, [1:   6]) = [  6.00000E+00 0.0E+00  6.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_GENRATE               (idx, [1:   6]) = [  6.93756E+16 0.00011  6.93756E+16 0.00011  0.00000E+00 0.0E+00 ];
TOT_FISSRATE              (idx, [1:   6]) = [  2.33149E+16 1.1E-05  2.33149E+16 1.1E-05  0.00000E+00 0.0E+00 ];
TOT_CAPTRATE              (idx, [1:   6]) = [  9.02668E+16 0.00360  7.63987E+16 0.00399  1.38681E+16 0.00450 ];
TOT_ABSRATE               (idx, [1:   6]) = [  1.13582E+17 0.00286  9.97136E+16 0.00306  1.38681E+16 0.00450 ];
TOT_SRCRATE               (idx, [1:   6]) = [  1.13782E+17 0.00573  1.13782E+17 0.00573  0.00000E+00 0.0E+00 ];
TOT_FLUX                  (idx, [1:   6]) = [  6.53621E+18 0.00460  1.07797E+18 0.00531  5.45824E+18 0.00460 ];
TOT_PHOTON_PRODRATE       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
TOT_LEAKRATE              (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
ALBEDO_LEAKRATE           (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_LOSSRATE              (idx, [1:   2]) = [  1.13582E+17 0.00286 ];
TOT_CUTRATE               (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
TOT_RR                    (idx, [1:   2]) = [  4.61980E+18 0.00390 ];
INI_FMASS                 (idx, 1)        =  1.30153E-01 ;
TOT_FMASS                 (idx, 1)        =  8.36573E-02 ;
INI_BURN_FMASS            (idx, 1)        =  1.30153E-01 ;
TOT_BURN_FMASS            (idx, 1)        =  8.36573E-02 ;

% Six-factor formula:

SIX_FF_ETA                (idx, [1:   2]) = [  1.01354E+00 0.00755 ];
SIX_FF_F                  (idx, [1:   2]) = [  8.44780E-01 0.00256 ];
SIX_FF_P                  (idx, [1:   2]) = [  6.28666E-01 0.00356 ];
SIX_FF_EPSILON            (idx, [1:   2]) = [  1.13395E+00 0.00398 ];
SIX_FF_LF                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_LT                 (idx, [1:   2]) = [  1.00000E+00 0.0E+00 ];
SIX_FF_KINF               (idx, [1:   2]) = [  6.09733E-01 0.00848 ];
SIX_FF_KEFF               (idx, [1:   2]) = [  6.09733E-01 0.00848 ];

% Fission neutron and energy production:

NUBAR                     (idx, [1:   2]) = [  2.97560E+00 0.00012 ];
FISSE                     (idx, [1:   2]) = [  2.09056E+02 1.1E-05 ];

% Criticality eigenvalues:

ANA_KEFF                  (idx, [1:   6]) = [  6.09355E-01 0.00861  6.07219E-01 0.00857  2.51414E-03 0.16124 ];
IMP_KEFF                  (idx, [1:   2]) = [  6.11996E-01 0.00282 ];
COL_KEFF                  (idx, [1:   2]) = [  6.11670E-01 0.00562 ];
ABS_KEFF                  (idx, [1:   2]) = [  6.11996E-01 0.00282 ];
ABS_KINF                  (idx, [1:   2]) = [  6.11996E-01 0.00282 ];
GEOM_ALBEDO               (idx, [1:   6]) = [  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00  1.00000E+00 0.0E+00 ];

% ALF (Average lethargy of neutrons causing fission):
% Based on E0 = 2.000000E+01 MeV

ANA_ALF                   (idx, [1:   2]) = [  1.77562E+01 0.00271 ];
IMP_ALF                   (idx, [1:   2]) = [  1.76842E+01 0.00079 ];

% EALF (Energy corresponding to average lethargy of neutrons causing fission):

ANA_EALF                  (idx, [1:   2]) = [  4.40414E-07 0.05797 ];
IMP_EALF                  (idx, [1:   2]) = [  4.21840E-07 0.01440 ];

% AFGE (Average energy of neutrons causing fission):

ANA_AFGE                  (idx, [1:   2]) = [  2.06247E-01 0.04779 ];
IMP_AFGE                  (idx, [1:   2]) = [  2.15984E-01 0.01220 ];

% Forward-weighted delayed neutron parameters:

FWD_ANA_BETA_ZERO         (idx, [1:  14]) = [  6.45487E-03 0.07912  8.57508E-05 0.57473  1.45226E-03 0.14050  8.71689E-04 0.19400  2.41012E-03 0.12900  1.05717E-03 0.15961  5.77875E-04 0.22434 ];
FWD_ANA_LAMBDA            (idx, [1:  14]) = [  6.12169E-01 0.16090  3.85743E-04 0.57198  1.14084E-02 0.12838  2.62097E-02 0.18405  1.58515E-01 0.10065  3.19435E-01 0.15853  8.73530E-01 0.27208 ];

% Beta-eff using Meulekamp's method:

ADJ_MEULEKAMP_BETA_EFF    (idx, [1:  14]) = [  3.46507E-03 0.11270  1.19642E-05 0.87634  7.10483E-04 0.21552  5.85040E-04 0.29542  1.26522E-03 0.16595  6.66866E-04 0.25062  2.25487E-04 0.32057 ];
ADJ_MEULEKAMP_LAMBDA      (idx, [1:  14]) = [  8.04456E-01 0.19755  1.28581E-02 0.02881  3.00189E-02 0.00082  1.13755E-01 0.00781  3.16863E-01 0.00591  1.06026E+00 0.03941  5.27189E+00 0.16511 ];

% Adjoint weighted time constants using Nauchi's method:

ADJ_NAUCHI_GEN_TIME       (idx, [1:   6]) = [  8.51678E-05 0.01805  8.51655E-05 0.01795  2.38472E-05 0.32664 ];
ADJ_NAUCHI_LIFETIME       (idx, [1:   6]) = [  5.15276E-05 0.01585  5.15251E-05 0.01571  1.43576E-05 0.32802 ];
ADJ_NAUCHI_BETA_EFF       (idx, [1:  14]) = [  4.23484E-03 0.15986  0.00000E+00 0.0E+00  9.76923E-04 0.32680  4.17276E-04 0.49488  1.65231E-03 0.24334  5.89875E-04 0.40067  5.98464E-04 0.40316 ];
ADJ_NAUCHI_LAMBDA         (idx, [1:  14]) = [  1.06303E+00 0.33966  0.00000E+00 0.0E+00  2.99895E-02 0.00111  1.14336E-01 0.02094  3.18062E-01 0.01040  1.11124E+00 0.09705  5.44690E+00 0.28429 ];

% Adjoint weighted time constants using IFP:

ADJ_IFP_GEN_TIME          (idx, [1:   6]) = [  8.22093E-05 0.04063  8.22631E-05 0.04065  2.86274E-06 0.58442 ];
ADJ_IFP_LIFETIME          (idx, [1:   6]) = [  4.97126E-05 0.03949  4.97465E-05 0.03953  1.71851E-06 0.57706 ];
ADJ_IFP_IMP_BETA_EFF      (idx, [1:  14]) = [  2.25063E-03 0.55862  0.00000E+00 0.0E+00  3.96702E-05 1.00000  0.00000E+00 0.0E+00  5.44708E-04 0.73194  1.01400E-03 1.00000  6.52247E-04 1.00000 ];
ADJ_IFP_IMP_LAMBDA        (idx, [1:  14]) = [  9.12450E-01 0.59168  0.00000E+00 0.0E+00  3.02552E-02 0.0E+00  0.00000E+00 0.0E+00  3.29548E-01 0.03620  8.70100E-01 0.0E+00  3.00280E+00 0.0E+00 ];
ADJ_IFP_ANA_BETA_EFF      (idx, [1:  14]) = [  2.30172E-03 0.52844  0.00000E+00 0.0E+00  1.02669E-04 1.00000  0.00000E+00 0.0E+00  5.97457E-04 0.75811  8.95270E-04 1.00000  7.06320E-04 1.00000 ];
ADJ_IFP_ANA_LAMBDA        (idx, [1:  14]) = [  9.12450E-01 0.59168  0.00000E+00 0.0E+00  3.02552E-02 0.0E+00  0.00000E+00 0.0E+00  3.29548E-01 0.03620  8.70100E-01 0.0E+00  3.00280E+00 0.0E+00 ];
ADJ_IFP_ROSSI_ALPHA       (idx, [1:   2]) = [ -3.41244E+01 0.63245 ];

% Adjoint weighted time constants using perturbation technique:

ADJ_PERT_GEN_TIME         (idx, [1:   2]) = [  8.36245E-05 0.01035 ];
ADJ_PERT_LIFETIME         (idx, [1:   2]) = [  5.05883E-05 0.00578 ];
ADJ_PERT_BETA_EFF         (idx, [1:   2]) = [  3.42949E-03 0.09463 ];
ADJ_PERT_ROSSI_ALPHA      (idx, [1:   2]) = [ -4.08015E+01 0.09255 ];

% Inverse neutron speed :

ANA_INV_SPD               (idx, [1:   2]) = [  6.92802E-07 0.00495 ];

% Analog slowing-down and thermal neutron lifetime (total/prompt/delayed):

ANA_SLOW_TIME             (idx, [1:   6]) = [  2.97198E-06 0.00462  2.97153E-06 0.00463  2.18881E-06 0.09103 ];
ANA_THERM_TIME            (idx, [1:   6]) = [  5.94303E-05 0.00554  5.94524E-05 0.00554  3.83282E-05 0.13385 ];
ANA_THERM_FRAC            (idx, [1:   6]) = [  6.29155E-01 0.00355  6.30693E-01 0.00368  3.98527E-01 0.12361 ];
ANA_DELAYED_EMTIME        (idx, [1:   2]) = [  1.04933E+01 0.18002 ];
ANA_MEAN_NCOL             (idx, [1:   4]) = [  4.06222E+01 0.00313  4.67733E+01 0.00622 ];

% Group constant generation:

GC_UNIVERSE_NAME          (idx, [1:  1])  = '0' ;

% Micro- and macro-group structures:

MICRO_NG                  (idx, 1)        = 70 ;
MICRO_E                   (idx, [1:  71]) = [  1.00000E-11  5.00000E-09  1.00000E-08  1.50000E-08  2.00000E-08  2.50000E-08  3.00000E-08  3.50000E-08  4.20000E-08  5.00000E-08  5.80000E-08  6.70000E-08  8.00000E-08  1.00000E-07  1.40000E-07  1.80000E-07  2.20000E-07  2.50000E-07  2.80000E-07  3.00000E-07  3.20000E-07  3.50000E-07  4.00000E-07  5.00000E-07  6.25000E-07  7.80000E-07  8.50000E-07  9.10000E-07  9.50000E-07  9.72000E-07  9.96000E-07  1.02000E-06  1.04500E-06  1.07100E-06  1.09700E-06  1.12300E-06  1.15000E-06  1.30000E-06  1.50000E-06  1.85500E-06  2.10000E-06  2.60000E-06  3.30000E-06  4.00000E-06  9.87700E-06  1.59680E-05  2.77000E-05  4.80520E-05  7.55014E-05  1.48728E-04  3.67262E-04  9.06898E-04  1.42510E-03  2.23945E-03  3.51910E-03  5.50000E-03  9.11800E-03  1.50300E-02  2.47800E-02  4.08500E-02  6.74300E-02  1.11000E-01  1.83000E-01  3.02500E-01  5.00000E-01  8.21000E-01  1.35300E+00  2.23100E+00  3.67900E+00  6.06550E+00  2.00000E+01 ];

MACRO_NG                  (idx, 1)        = 2 ;
MACRO_E                   (idx, [1:   3]) = [  1.00000E+37  6.25000E-07  0.00000E+00 ];

% Micro-group spectrum:

INF_MICRO_FLX             (idx, [1: 140]) = [  4.08997E+03 0.02608  1.52954E+04 0.01721  3.13167E+04 0.00775  3.82157E+04 0.00901  3.65815E+04 0.00396  3.80622E+04 0.00454  2.60476E+04 0.01314  2.24288E+04 0.00279  1.72807E+04 0.00575  1.40919E+04 0.01017  1.18708E+04 0.00929  1.10672E+04 0.00500  1.01295E+04 0.00989  9.54577E+03 0.00764  9.38738E+03 0.00936  8.11313E+03 0.01150  8.23298E+03 0.00878  7.84552E+03 0.00614  7.84748E+03 0.00494  1.53192E+04 0.00764  1.47921E+04 0.00604  1.06016E+04 0.01176  7.10042E+03 0.00810  8.11144E+03 0.01103  7.86389E+03 0.00733  6.83322E+03 0.01624  1.09106E+04 0.00446  2.49785E+03 0.01606  2.89194E+03 0.01572  2.75777E+03 0.02070  1.63224E+03 0.02578  2.70785E+03 0.02264  1.67187E+03 0.00975  1.50310E+03 0.02147  2.59656E+02 0.04188  2.27730E+02 0.03031  1.85463E+02 0.04655  2.10033E+02 0.04437  1.96802E+02 0.03994  1.98907E+02 0.04951  2.51599E+02 0.02825  2.54864E+02 0.05670  4.99368E+02 0.03358  8.12598E+02 0.01468  1.11346E+03 0.01837  3.07411E+03 0.01198  3.19900E+03 0.02986  3.47977E+03 0.01694  2.46220E+03 0.00894  1.77705E+03 0.00538  1.42441E+03 0.00974  1.72570E+03 0.01883  3.37245E+03 0.02463  4.73564E+03 0.01037  9.57642E+03 0.01709  1.54181E+04 0.01245  2.36578E+04 0.01234  1.53081E+04 0.00861  1.09592E+04 0.00784  7.88973E+03 0.01245  7.13590E+03 0.00961  7.06933E+03 0.00576  5.90771E+03 0.00954  3.97414E+03 0.00876  3.69352E+03 0.01742  3.28155E+03 0.01797  2.79708E+03 0.01490  2.17730E+03 0.02520  1.48753E+03 0.00921  5.10966E+02 0.01629 ];

% Integral parameters:

INF_KINF                  (idx, [1:   2]) = [  6.11670E-01 0.00769 ];

% Flux spectra in infinite geometry:

INF_FLX                   (idx, [1:   4]) = [  4.91459E+18 0.00847  1.62687E+18 0.00540 ];
INF_FISS_FLX              (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

INF_TOT                   (idx, [1:   4]) = [  5.26480E-01 0.00091  1.25278E+00 0.00153 ];
INF_CAPT                  (idx, [1:   4]) = [  7.96288E-03 0.00439  3.15048E-02 0.00325 ];
INF_ABS                   (idx, [1:   4]) = [  8.55525E-03 0.00410  4.40898E-02 0.00366 ];
INF_FISS                  (idx, [1:   4]) = [  5.92368E-04 0.00739  1.25851E-02 0.00507 ];
INF_NSF                   (idx, [1:   4]) = [  1.75476E-03 0.00801  3.74715E-02 0.00501 ];
INF_NUBAR                 (idx, [1:   4]) = [  2.96223E+00 0.00067  2.97745E+00 0.00012 ];
INF_KAPPA                 (idx, [1:   4]) = [  2.07981E+02 1.6E-05  2.09209E+02 1.0E-05 ];
INF_INVV                  (idx, [1:   4]) = [  5.55989E-08 0.00521  2.61867E-06 0.00071 ];

% Total scattering cross sections:

INF_SCATT0                (idx, [1:   4]) = [  5.17862E-01 0.00108  1.20882E+00 0.00154 ];
INF_SCATT1                (idx, [1:   4]) = [  2.23235E-01 0.00126  2.98776E-01 0.00379 ];
INF_SCATT2                (idx, [1:   4]) = [  8.89710E-02 0.00274  6.95804E-02 0.00660 ];
INF_SCATT3                (idx, [1:   4]) = [  6.16858E-03 0.01882  2.03780E-02 0.02050 ];
INF_SCATT4                (idx, [1:   4]) = [ -9.41407E-03 0.00611 -7.57151E-03 0.03915 ];
INF_SCATT5                (idx, [1:   4]) = [ -1.26573E-04 0.57103  4.97294E-03 0.07515 ];
INF_SCATT6                (idx, [1:   4]) = [  4.47045E-03 0.04716 -1.33587E-02 0.02734 ];
INF_SCATT7                (idx, [1:   4]) = [  7.14399E-04 0.35082  4.11108E-05 1.00000 ];

% Total scattering production cross sections:

INF_SCATTP0               (idx, [1:   4]) = [  5.17883E-01 0.00108  1.20882E+00 0.00154 ];
INF_SCATTP1               (idx, [1:   4]) = [  2.23234E-01 0.00127  2.98776E-01 0.00379 ];
INF_SCATTP2               (idx, [1:   4]) = [  8.89711E-02 0.00275  6.95804E-02 0.00660 ];
INF_SCATTP3               (idx, [1:   4]) = [  6.16809E-03 0.01876  2.03780E-02 0.02050 ];
INF_SCATTP4               (idx, [1:   4]) = [ -9.41377E-03 0.00598 -7.57151E-03 0.03915 ];
INF_SCATTP5               (idx, [1:   4]) = [ -1.26228E-04 0.57324  4.97294E-03 0.07515 ];
INF_SCATTP6               (idx, [1:   4]) = [  4.46899E-03 0.04724 -1.33587E-02 0.02734 ];
INF_SCATTP7               (idx, [1:   4]) = [  7.14136E-04 0.35116  4.11108E-05 1.00000 ];

% Diffusion parameters:

INF_TRANSPXS              (idx, [1:   4]) = [  2.29980E-01 0.00260  8.54916E-01 0.00236 ];
INF_DIFFCOEF              (idx, [1:   4]) = [  1.44944E+00 0.00260  3.89911E-01 0.00236 ];

% Reduced absoption and removal:

INF_RABSXS                (idx, [1:   4]) = [  8.53475E-03 0.00427  4.40898E-02 0.00366 ];
INF_REMXS                 (idx, [1:   4]) = [  2.34462E-02 0.00076  4.47874E-02 0.00304 ];

% Poison cross sections:

INF_I135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_YIELD          (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_I135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM147_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM148M_MICRO_ABS      (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_PM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_XE135_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_SM149_MACRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

INF_CHIT                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHIP                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
INF_CHID                  (idx, [1:   4]) = [  1.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

INF_S0                    (idx, [1:   8]) = [  5.03034E-01 0.00093  1.48287E-02 0.00786  8.26855E-04 0.01758  1.20799E+00 0.00153 ];
INF_S1                    (idx, [1:   8]) = [  2.18973E-01 0.00115  4.26234E-03 0.01110  2.93226E-04 0.08052  2.98483E-01 0.00378 ];
INF_S2                    (idx, [1:   8]) = [  9.03277E-02 0.00264 -1.35673E-03 0.01876  1.64768E-04 0.14434  6.94156E-02 0.00675 ];
INF_S3                    (idx, [1:   8]) = [  7.66984E-03 0.01659 -1.50126E-03 0.01706  5.76879E-05 0.32673  2.03204E-02 0.02036 ];
INF_S4                    (idx, [1:   8]) = [ -8.96710E-03 0.00738 -4.46971E-04 0.02909 -9.46804E-06 0.84860 -7.56204E-03 0.03910 ];
INF_S5                    (idx, [1:   8]) = [ -1.82144E-04 0.38185  5.55715E-05 0.23478 -3.87546E-05 0.26430  5.01169E-03 0.07537 ];
INF_S6                    (idx, [1:   8]) = [  4.58362E-03 0.04250 -1.13168E-04 0.17049 -2.78597E-05 0.18451 -1.33308E-02 0.02718 ];
INF_S7                    (idx, [1:   8]) = [  8.63858E-04 0.29356 -1.49459E-04 0.11339 -1.31325E-05 0.22880  5.42433E-05 1.00000 ];

% Scattering production matrixes:

INF_SP0                   (idx, [1:   8]) = [  5.03054E-01 0.00093  1.48287E-02 0.00786  8.26855E-04 0.01758  1.20799E+00 0.00153 ];
INF_SP1                   (idx, [1:   8]) = [  2.18972E-01 0.00115  4.26234E-03 0.01110  2.93226E-04 0.08052  2.98483E-01 0.00378 ];
INF_SP2                   (idx, [1:   8]) = [  9.03278E-02 0.00264 -1.35673E-03 0.01876  1.64768E-04 0.14434  6.94156E-02 0.00675 ];
INF_SP3                   (idx, [1:   8]) = [  7.66935E-03 0.01653 -1.50126E-03 0.01706  5.76879E-05 0.32673  2.03204E-02 0.02036 ];
INF_SP4                   (idx, [1:   8]) = [ -8.96680E-03 0.00725 -4.46971E-04 0.02909 -9.46804E-06 0.84860 -7.56204E-03 0.03910 ];
INF_SP5                   (idx, [1:   8]) = [ -1.81799E-04 0.38233  5.55715E-05 0.23478 -3.87546E-05 0.26430  5.01169E-03 0.07537 ];
INF_SP6                   (idx, [1:   8]) = [  4.58216E-03 0.04258 -1.13168E-04 0.17049 -2.78597E-05 0.18451 -1.33308E-02 0.02718 ];
INF_SP7                   (idx, [1:   8]) = [  8.63595E-04 0.29385 -1.49459E-04 0.11339 -1.31325E-05 0.22880  5.42433E-05 1.00000 ];

% Micro-group spectrum:

B1_MICRO_FLX              (idx, [1: 140]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Integral parameters:

B1_KINF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_KEFF                   (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_B2                     (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];
B1_ERR                    (idx, [1:   2]) = [  0.00000E+00 0.0E+00 ];

% Critical spectra in infinite geometry:

B1_FLX                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS_FLX               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reaction cross sections:

B1_TOT                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CAPT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_ABS                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_FISS                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NSF                    (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_NUBAR                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_KAPPA                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_INVV                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering cross sections:

B1_SCATT0                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT1                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT2                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT3                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT4                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT5                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT6                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATT7                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Total scattering production cross sections:

B1_SCATTP0                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP1                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP2                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP3                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP4                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP5                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP6                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SCATTP7                (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Diffusion parameters:

B1_TRANSPXS               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_DIFFCOEF               (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Reduced absoption and removal:

B1_RABSXS                 (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_REMXS                  (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Poison cross sections:

B1_I135_YIELD             (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_YIELD           (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_YIELD            (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_I135_MICRO_ABS         (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM147_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM148M_MICRO_ABS       (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_PM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MICRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_XE135_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SM149_MACRO_ABS        (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Fission spectra:

B1_CHIT                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHIP                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_CHID                   (idx, [1:   4]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering matrixes:

B1_S0                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S1                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S2                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S3                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S4                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S5                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S6                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_S7                     (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Scattering production matrixes:

B1_SP0                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP1                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP2                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP3                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP4                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP5                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP6                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];
B1_SP7                    (idx, [1:   8]) = [  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00  0.00000E+00 0.0E+00 ];

% Additional diffusion parameters:

CMM_TRANSPXS              (idx, [1:   4]) = [  2.40249E-01 0.00634  7.01343E-01 0.01453 ];
CMM_TRANSPXS_X            (idx, [1:   4]) = [  2.40207E-01 0.00902  7.25270E-01 0.03590 ];
CMM_TRANSPXS_Y            (idx, [1:   4]) = [  2.41595E-01 0.00966  7.17666E-01 0.03143 ];
CMM_TRANSPXS_Z            (idx, [1:   4]) = [  2.39104E-01 0.00992  6.71638E-01 0.03487 ];
CMM_DIFFCOEF              (idx, [1:   4]) = [  1.38767E+00 0.00635  4.75671E-01 0.01419 ];
CMM_DIFFCOEF_X            (idx, [1:   4]) = [  1.38814E+00 0.00897  4.62024E-01 0.03669 ];
CMM_DIFFCOEF_Y            (idx, [1:   4]) = [  1.38023E+00 0.00958  4.66336E-01 0.03192 ];
CMM_DIFFCOEF_Z            (idx, [1:   4]) = [  1.39465E+00 0.01003  4.98652E-01 0.03390 ];

% Delayed neutron parameters (Meulekamp method):

BETA_EFF                  (idx, [1:  14]) = [  3.46507E-03 0.11270  1.19642E-05 0.87634  7.10483E-04 0.21552  5.85040E-04 0.29542  1.26522E-03 0.16595  6.66866E-04 0.25062  2.25487E-04 0.32057 ];
LAMBDA                    (idx, [1:  14]) = [  8.04456E-01 0.19755  1.28581E-02 0.02881  3.00189E-02 0.00082  1.13755E-01 0.00781  3.16863E-01 0.00591  1.06026E+00 0.03941  5.27189E+00 0.16511 ];

